<?php

/**
 * pac_get_inventory_taxonomies
 *
 * @return array
 */
function pac_get_inventory_taxonomies()
{
    $taxonomy_args = array(
       
        array(
            'taxonomy'  => 'deposite',
            'label'     => __('Deposit', 'nets-rental'),
            'post_type' => 'inventory'
        ),
       
      
    );
    return apply_filters('pac_register_inventory_taxonomy', $taxonomy_args);
}

/**
 * pac_term_meta_data_provider
 *
 * @return array
 */
function pac_term_meta_data_provider()
{

    //Deposit Term Meta args
    $args[] = [
        'taxonomy' => 'deposite',
        'args'     => array(
            'title'       => __('Security Deposit Cost', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_sd_cost_termmeta',
            'column_name' => __('S.D.Cost', 'nets-rental'),
            'placeholder' => __('Security Deposit Cost', 'nets-rental'),
            'text_type'   => 'price',
            'required'    => false,
        )
    ];

    $args[] = [
        'taxonomy' => 'deposite',
        'args'     => array(
            'title'       => __('Price Frequency', 'nets-rental'),
            'type'        => 'select',
            'id'          => 'inventory_sd_price_applicable_term_meta',
            'column_name' => __('Applicable', 'nets-rental'),
            'options'     => array(
                '0' => array(
                    'key'   => 'one_time',
                    'value' => 'One Time'
                ),
                '1' => array(
                    'key'   => 'per_day',
                    'value' => 'Per Day'
                ),
            ),
        )
    ];

  

    $args[] = [
        'taxonomy' => 'deposite',
        'args'     => array(
            'title'       => __('Security Deposit Clickable', 'nets-rental'),
            'type'        => 'select',
            'id'          => 'inventory_sd_price_clickable_term_meta',
            'column_name' => __('Clickable', 'nets-rental'),
            'options'     => array(
                '0' => array(
                    'key'   => 'yes',
                    'value' => 'Yes'
                ),
                '1' => array(
                    'key'   => 'no',
                    'value' => 'No'
                ),
            ),
        )
    ];

    //Pickup Location Term Meta args
    $args[] = [
        'taxonomy' => 'pickup_location',
        'args'     => array(
            'title'       => __('Pickup Cost', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_pickup_cost_termmeta',
            'column_name' => __('Cost', 'nets-rental'),
            'placeholder' => __('Pickup Location Cost', 'nets-rental'),
            'text_type'   => 'price',
            'required'    => false,
        )
    ];

    $args[] = [
        'taxonomy' => 'pickup_location',
        'args'     => array(
            'title'       => __('Latitude', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_pickup_location_lat',
            'column_name' => __('Latitude', 'nets-rental'),
            'placeholder' => __('Latitude', 'nets-rental'),
            'required'    => false,
        )
    ];

    $args[] = [
        'taxonomy' => 'pickup_location',
        'args'     => array(
            'title'       => __('Longitude', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_pickup_location_lng',
            'column_name' => __('Longitude', 'nets-rental'),
            'placeholder' => __('Longitude', 'nets-rental'),
            'required'    => false,
        )
    ];


    //Dropoff Location Term Meta args
    $args[] = [
        'taxonomy' => 'dropoff_location',
        'args'     => array(
            'title'       => __('Dropoff Cost', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_dropoff_cost_termmeta',
            'column_name' => __('Cost', 'nets-rental'),
            'placeholder' => __('Dropoff Location Cost', 'nets-rental'),
            'text_type'   => 'price',
            'required'    => false,
        )
    ];

    $args[] = [
        'taxonomy' => 'dropoff_location',
        'args'     => array(
            'title'       => __('Latitude', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_dropoff_location_lat',
            'column_name' => __('Latitude', 'nets-rental'),
            'placeholder' => __('Latitude', 'nets-rental'),
            'required'    => false,
        )
    ];

    $args[] = [
        'taxonomy' => 'dropoff_location',
        'args'     => array(
            'title'       => __('Longitude', 'nets-rental'),
            'type'        => 'text',
            'id'          => 'inventory_dropoff_location_lng',
            'column_name' => __('Longitude', 'nets-rental'),
            'placeholder' => __('Longitude', 'nets-rental'),
            'required'    => false,
        )
    ];

  

    return apply_filters('pac_inventory_term_meta_args', $args);
}

/**
 * pac_format_prices
 *
 * @param mixed $price_breakdown
 *
 * @return void
 */
function pac_format_prices($breakdown, $quantity = 1)
{
    $formatted_prices = [];

    $prices = $breakdown['price_breakdown'];
    $instant_pay = $breakdown['instant_pay'];

    $details_breakdown = pac_rearrange_details_breakdown($prices);

    $duration_total = isset($prices['duration_total']) && $prices['duration_total'] ? $prices['duration_total'] : 0;
    $discount_total = isset($prices['discount_total']) && $prices['discount_total'] ? $prices['discount_total'] : 0;
    $deposit_free_total = isset($prices['deposit_free_total']) && $prices['deposit_free_total'] ? $prices['deposit_free_total'] : 0;
    $deposit_total = isset($prices['deposit_total']) && $prices['deposit_total'] ? $prices['deposit_total'] : 0;
    $total = isset($prices['total']) && $prices['total'] ? $prices['total'] : 0;

    if (isset($details_breakdown['pickup_location_cost']) && $details_breakdown['pickup_location_cost']) {
        $data = array(
            'text' => __('Pickup Location Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['pickup_location_cost'] * $quantity)
        );
        $formatted_prices['pickup_location_cost'] = $data;
    }

    if (isset($details_breakdown['return_location_cost']) && $details_breakdown['return_location_cost']) {
        $data = array(
            'text' => __('Return Location Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['return_location_cost'] * $quantity)
        );
        $formatted_prices['return_location_cost'] = $data;
    }

    if (isset($details_breakdown['kilometer_cost']) && $details_breakdown['kilometer_cost']) {
        $data = array(
            'text' => __('Kilometer Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['kilometer_cost'] * $quantity)
        );
        $formatted_prices['kilometer_cost'] = $data;
    }

    if ($duration_total) {
        $data = array(
            'text' => __('Duration Cost', 'nets-rental'),
            'cost' => wc_price($duration_total * $quantity)
        );
        $formatted_prices['duration_cost'] = $data;
    }

    if ($discount_total) {
        $data = array(
            'text' => __('Discount Cost', 'nets-rental'),
            'cost' => wc_price(-$discount_total * $quantity)
        );
        $formatted_prices['discount_cost'] = $data;
    }

    if (isset($details_breakdown['resource_cost']) && $details_breakdown['resource_cost']) {
        $data = array(
            'text' => __('Resource Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['resource_cost'] * $quantity)
        );
        $formatted_prices['resource_cost'] = $data;
    }

    if (isset($details_breakdown['category_cost']) && $details_breakdown['category_cost']) {
        $data = array(
            'text' => __('Category Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['category_cost'] * $quantity)
        );
        $formatted_prices['category_cost'] = $data;
    }

    if (isset($details_breakdown['adult_cost']) && $details_breakdown['adult_cost']) {
        $data = array(
            'text' => __('Adult Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['adult_cost'] * $quantity)
        );
        $formatted_prices['adult_cost'] = $data;
    }

    if (isset($details_breakdown['child_cost']) && $details_breakdown['child_cost']) {
        $data = array(
            'text' => __('Child Cost', 'nets-rental'),
            'cost' => wc_price($details_breakdown['child_cost'] * $quantity)
        );
        $formatted_prices['child_cost'] = $data;
    }

    if ($deposit_free_total) {
        $data = array(
            'text' => __('Sub Total', 'nets-rental'),
            'cost' => wc_price($deposit_free_total * $quantity)
        );
        $formatted_prices['deposit_free_total'] = $data;
    }

    if ($instant_pay === 100) {
        if ($deposit_total) {
            $data = array(
                'text' => __('Deposit', 'nets-rental'),
                'cost' => wc_price($deposit_total * $quantity),
            );
            $formatted_prices['deposit'] = $data;
        }

        if ($total) {
            $data = array(
                'text' => __('Grand Total', 'nets-rental'),
                'cost' => wc_price($total * $quantity)
            );
            $formatted_prices['grand_total'] = $data;
        }
    }


    if ($instant_pay !== 100) {
        $data = array(
            'text' => __('Instant Pay', 'nets-rental'),
            'cost' => $instant_pay . '%'
        );
        $formatted_prices['instant_pay'] = $data;

        $data = array(
            'text' => __('Initial Value', 'nets-rental'),
            'cost' => wc_price($breakdown['cost'] * $quantity),
        );
        $formatted_prices['pay_during_booking'] = $data;

        if ($deposit_total) {
            $data = array(
                'text' => __('Deposit', 'nets-rental'),
                'cost' => wc_price($deposit_total * $quantity),
            );
            $formatted_prices['deposit'] = $data;
        }

        $data = array(
            'text' => __('Total Instant Pay', 'nets-rental'),
            'cost' => wc_price(($breakdown['cost'] + $deposit_total) * $quantity),
        );
        $formatted_prices['total_instant_pay'] = $data;

        $data = array(
            'text' => __('Payment Due', 'nets-rental'),
            'cost' => wc_price($breakdown['due_payment'] * $quantity),
        );
        $formatted_prices['due_payment'] = $data;
    }

    if ($total) {
        $data = array(
            'text' => __('Quote Total', 'nets-rental'),
            'cost' => $total * $quantity
        );
        $formatted_prices['quote_total'] = $data;
    }

    return $formatted_prices;
}


/**
 * pac_rearrange_details_breakdown
 *
 * @param array $prices
 *
 * @return array
 */
function pac_rearrange_details_breakdown($prices)
{
    $breakdown = [];

    $day_based_breakdown = isset($prices['extras_breakdown']['details_breakdown']) ? $prices['extras_breakdown']['details_breakdown'] : [];
    $hour_based_breakdown = isset($prices['extras_hour_breakdown']['details_breakdown']) ? $prices['extras_hour_breakdown']['details_breakdown'] : [];

    if (!empty($day_based_breakdown) && !empty($hour_based_breakdown)) {
        foreach ($day_based_breakdown as $key => $value) {
            $breakdown[$key] = $value + $hour_based_breakdown[$key];
        }
    }

    if (!empty($day_based_breakdown) && empty($hour_based_breakdown)) {
        $breakdown = $day_based_breakdown;
    }

    if (empty($day_based_breakdown) && !empty($hour_based_breakdown)) {
        $breakdown = $hour_based_breakdown;
    }

    return $breakdown;
}


/**
 * get_pickup_location_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_pickup_location_data($term_id, $taxonomy)
{
    if (!$term_id) return;

    $term = get_term_by('id', $term_id, $taxonomy);

    $cost = get_term_meta($term_id, 'inventory_pickup_cost_termmeta', true);
    $cost = $cost ? (float) $cost : 0;

    $result = [
        $term->name,
        $term->description ? $term->description : $term->name,
        $cost
    ];

    return implode('|', $result);
}

/**
 * get_dropoff_location_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_dropoff_location_data($term_id, $taxonomy)
{
    if (!$term_id) return;

    $term = get_term_by('id', $term_id, $taxonomy);

    $cost = get_term_meta($term_id, 'inventory_dropoff_cost_termmeta', true);
    $cost = $cost ? (float) $cost : 0;

    $result = [
        $term->name,
        $term->description ? $term->description : $term->name,
        $cost
    ];

    return implode('|', $result);
}

/**
 * get_resource_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_resource_data($term_ids, $taxonomy)
{
    $results = [];

    if (!count($term_ids)) return $results;

    foreach ($term_ids as $key => $term_id) {
        $term = get_term_by('id', $term_id, $taxonomy);

        $cost = get_term_meta($term_id, 'inventory_resource_cost_termmeta', true);
        $applicable = get_term_meta($term_id, 'inventory_price_applicable_term_meta', true);
        $hourly_cost = get_term_meta($term_id, 'inventory_hourly_cost_termmeta', true);

        $cost = $cost ? (float) $cost : 0;
        $hourly_cost = $hourly_cost ? (float) $hourly_cost : 0;

        $data = [
            $term->name,
            $cost,
            $applicable,
            $hourly_cost
        ];

        $results[] = implode('|', $data);
    }

    return $results;
}


/**
 * get_category_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_category_data($term_ids, $quantity, $taxonomy)
{
    $results = [];

    if (!count($term_ids)) return $results;

    foreach ($term_ids as $key => $term_id) {
        $term = get_term_by('id', $term_id, $taxonomy);

        $cost = get_term_meta($term_id, 'inventory_pac_cat_cost_termmeta', true);
        $applicable = get_term_meta($term_id, 'inventory_pac_cat_price_applicable_term_meta', true);
        $qty = $quantity[$key];
        $hourly_cost = get_term_meta($term_id, 'inventory_pac_cat_hourly_cost_termmeta', true);

        $cost = $cost ? (float) $cost : 0;
        $hourly_cost = $hourly_cost ? (float) $hourly_cost : 0;
        $qty = $qty ? (int) $qty : 1;

        $data = [
            $term->name,
            $cost,
            $applicable,
            $hourly_cost,
            $qty
        ];

        $results[] = implode('|', $data);
    }

    return $results;
}


/**
 * get_person_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_person_data($term_id, $taxonomy)
{
    if (!$term_id) return;

    $term = get_term_by('id', $term_id, $taxonomy);

    $cost = get_term_meta($term_id, 'inventory_person_cost_termmeta', true);
    $applicable = get_term_meta($term_id, 'inventory_person_price_applicable_term_meta', true);
    $hourly_cost = get_term_meta($term_id, 'inventory_peroson_hourly_cost_termmeta', true);
    $cost = $cost ? (float) $cost : 0;
    $hourly_cost = $hourly_cost ? (float) $hourly_cost : 0;

    $result = [
        $term->name,
        $cost,
        $applicable,
        $hourly_cost
    ];

    return implode('|', $result);
}

/**
 * get_deposit_data
 *
 * @param int $term_id
 * @param string $taxonomy
 * @return string
 */
function get_deposit_data($term_ids, $taxonomy)
{
    $results = [];

    if (!count($term_ids)) return $results;

    foreach ($term_ids as $key => $term_id) {
        $term = get_term_by('id', $term_id, $taxonomy);

        $cost = get_term_meta($term_id, 'inventory_sd_cost_termmeta', true);
        $applicable = get_term_meta($term_id, 'inventory_sd_price_applicable_term_meta', true);
        $hourly_cost = get_term_meta($term_id, 'inventory_sd_hourly_cost_termmeta', true);

        $cost = $cost ? (float) $cost : 0;
        $hourly_cost = $hourly_cost ? (float) $hourly_cost : 0;

        $data = [
            $term->name,
            $cost,
            $applicable,
            $hourly_cost
        ];

        $results[] = implode('|', $data);
    }

    return $results;
}