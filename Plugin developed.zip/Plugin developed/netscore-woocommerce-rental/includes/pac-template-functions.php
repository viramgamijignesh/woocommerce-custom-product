<?php

/**
 * PAC Template
 *
 * Functions for the templating system.
 *
 * @author   NetSteam
 * @category Core
 * @package  PaC/Functions
 * @version  2.5.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


if (!function_exists('pac_price_flip_box')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_price_flip_box()
    {
        pac_get_template('pac/global/price-flip-box.php');
    }
}

if (!function_exists('pac_validation_notice')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_validation_notice()
    {
        pac_get_template('pac/global/pac-notice.php');
    }
}


if (!function_exists('pac_select_inventory')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_select_inventory()
    {
        pac_get_template('pac/booking-content/select-inventory.php');
    }
}


if (!function_exists('pac_pickup_locations')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_pickup_locations()
    {
        pac_get_template('pac/booking-content/pickup-locations.php');
    }
}


if (!function_exists('pac_return_locations')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_return_locations()
    {
        pac_get_template('pac/booking-content/return-locations.php');
    }
}


if (!function_exists('pac_pickup_datetimes')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_pickup_datetimes()
    {
        pac_get_template('pac/booking-content/pickup-datetimes.php');
    }
}


if (!function_exists('pac_return_datetimes')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_return_datetimes()
    {
        pac_get_template('pac/booking-content/return-datetimes.php');
    }
}


if (!function_exists('pac_quantity')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_quantity()
    {
        pac_get_template('pac/booking-content/quantity.php');
    }
}


if (!function_exists('pac_payable_categories')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_payable_categories()
    {
        pac_get_template('pac/booking-content/pac-categories.php');
    }
}


if (!function_exists('pac_payable_resources')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_payable_resources()
    {
        pac_get_template('pac/booking-content/payable-resources.php');
    }
}


if (!function_exists('pac_payable_persons')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_payable_persons()
    {
        pac_get_template('pac/booking-content/payable-persons.php');
    }
}

if (!function_exists('pac_payable_deposits')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_payable_deposits()
    {
        pac_get_template('pac/booking-content/payable-deposits.php');
    }
}


if (!function_exists('pac_booking_summary')) {
    function pac_booking_summary()
    {
        pac_get_template('pac/booking-content/booking-summary.php');
    }
}

if (!function_exists('pac_booking_summary_two')) {
    function pac_booking_summary_two()
    {
        pac_get_template('pac/booking-content/booking-summary-two.php');
    }
}


if (!function_exists('pac_direct_booking')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_direct_booking()
    {
        pac_get_template('pac/booking-content/direct-booking.php');
    }
}


if (!function_exists('pac_request_quote')) {

    /**
     * Output the start of the page wrapper.
     *
     */
    function pac_request_quote()
    {
        pac_get_template('pac/booking-content/request-quote.php');
    }
}


/**
 * Display meta data belonging to an item.
 * @param array $item
 */
function display_item_meta($item)
{


    $product = $this->get_product_from_item($item);


    $item_meta = new WC_Order_Item_Meta($item, $product);
    $item_meta->display();
}


if (!function_exists('pac_modal_booking_func')) {

    /**
     * Output of the modal
     *
     */
    function pac_modal_booking_func()
    {
        pac_get_template('pac/booking-content/booking-modal.php');
    }
}