<?php

class Pac_Color_Control
{
    public function __construct()
    {
        add_action('wp_head', array($this, 'pac_base_colors_css_wrap'));
    }

    public function pac_base_colors_css_wrap()
    {
        $pac_color_value = nets_rental_global_color_control();
        if ($pac_color_value !== '#b07aa4') {
            list($sr, $sg, $sb) = sscanf($pac_color_value, "#%02x%02x%02x");

            echo '<style>
      .custom-block input[type="checkbox"]:checked + span:after {
        background: ' . $pac_color_value . ';
        border-color: ' . $pac_color_value . ';
      }

      .xdsoft_datetimepicker
      .xdsoft_timepicker
      .xdsoft_time_box
      > div
      > div.xdsoft_current {
        background: ' . $pac_color_value . ' !important;
      }      
      
      #quote-content-confirm {
        color: #fff;
        background-color: ' . $pac_color_value . ' !important;
        height: 40px;
        font-size: 14px;
        margin: 0;
        font-weight: 600;
        font-family: Lato, sans-serif;
      }

      #animatedModal.pac-animated-modal .modal-content-body .modal-header {
        padding: 20px 25px;
        background-color: ' . $pac_color_value . ' ;
        border-radius: 3px 3px 0 0;
      }      

      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      .steps
      ul
      li.current
      a,
      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      .steps
      ul
      li.current:hover
      a {
        font-weight: 600;
        color: #fff !important;
        background-color: ' . $pac_color_value . ' !important;
      }

      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      .steps
      ul
      li:hover
      a {
        color: ' . $pac_color_value . ' !important;
      }

      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      > .actions
      > ul
      > li
      > a,
      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      > .actions
      > ul
      > li
      > button {
        border: 1px solid ' . $pac_color_value . ';
      }      

      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      > .actions
      > ul
      > li
      > a:focus,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li
        > button:focus,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li
        > a:visited,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li
        > button:visited,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li
        > button:hover,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li
        > a:hover {
          background-color: ' . $pac_color_value . ';
      }

      #animatedModal.pac-animated-modal
      .pac-step-content-wrapper
      header.section-title {
        background-color: rgba(' . $sr . ', ' . $sg . ', ' . $sb . ', 0.25);
        border-left: 4px solid ' . $pac_color_value . ';
      }

      #cal-submit-btn {
        background: ' . $pac_color_value . ';
      }
      #drop-cal-submit-btn {
        background: ' . $pac_color_value . ';
      }

      #animatedModal.pac-animated-modal
      .modal-content-body
      .modal-content
      #pacSmartwizard
      > .actions
      > ul
      > li.disabled
      > a,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li.disabled
        > a:hover,
      #animatedModal.pac-animated-modal
        .modal-content-body
        .modal-content
        #pacSmartwizard
        > .actions
        > ul
        > li.disabled
        > a:focus {
        background-color: rgba(' . $sr . ', ' . $sg . ', ' . $sb . ', 0.3);
        border: 1px solid rgba(' . $sr . ', ' . $sg . ', ' . $sb . ', 0.22);
      }

      #animatedModal.pac-animated-modal .pac-control.pac-control-checkbox.checked,
      #animatedModal.pac-animated-modal .pac-control.pac-control-radio.checked {
        background-color: rgba(' . $sr . ', ' . $sg . ', ' . $sb . ', 0.61);
        border: 1px solid rgba(' . $sr . ', ' . $sg . ', ' . $sb . ', 1);
      }


      </style>';
        }
    }
}

new Pac_Color_Control();