<div class="wrap">
    <div id="nets-rental-calendar"></div>
</div>

<div id="eventContent" class="popup-modal white-popup-block mfp-hide">
    <div class="white-popup">
        <h2><a id="eventProduct" href="" target="_blank"></a></h2>
        <strong><?php esc_html_e('Start:', 'nets-rental') ?></strong> <span id="startTime"></span><br>
        <strong><?php esc_html_e('End:', 'nets-rental') ?></strong> <span id="endTime"></span><br><br>
        <div id="eventInfo"></div>
        <p><strong><a id="eventLink" href=""
                      target="_blank"><?php esc_html_e('View Order', 'nets-rental') ?></a></strong></p>
    </div>
</div>