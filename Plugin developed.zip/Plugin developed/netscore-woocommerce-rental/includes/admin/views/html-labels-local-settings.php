<div class="pac-setting-fields pac-label-fields">
    <?php
    $inventory_title = get_post_meta($post_id, 'pac_inventory_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_inventory_title',
            'name'        => 'pac_inventory_title',
            'label'       => __('Choose Inventory', 'nets-rental'),
            'placeholder' => __('Choose Inventory', 'nets-rental'),
            'type'        => 'text',
            'value'       => $inventory_title,
        )
    );

    $flip_pricing_plan_text = get_post_meta($post_id, 'nets_flip_pricing_plan_text', true);

    woocommerce_wp_text_input(
        array(
            'id'          => 'flip_pricing_plan_text',
            'name'        => 'nets_flip_pricing_plan_text',
            'label'       => __('Show Pricing Info Heading Text', 'nets-rental'),
            'placeholder' => __('Show Pricing Info Heading Text', 'nets-rental'),
            'type'        => 'text',
            'value'       => $flip_pricing_plan_text,
        )
    );

    $unit_price = get_post_meta($post_id, 'pac_unit_price', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_unit_price',
            'name'        => 'pac_unit_price',
            'label'       => __('Unit Price Text', 'nets-rental'),
            'placeholder' => __('Per Day', 'nets-rental'),
            'type'        => 'text',
            'value'       => $unit_price,
        )
    );

    $pickup_date_heading_title = get_post_meta($post_id, 'nets_pickup_date_heading_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pickup_date_heading_title',
            'name'        => 'nets_pickup_date_heading_title',
            'label'       => __('Pickup Date Heading Title', 'nets-rental'),
            'placeholder' => __('Pickup date title', 'nets-rental'),
            'type'        => 'text',
            'value'       => $pickup_date_heading_title,
        )
    );


    $pickup_date_placeholder = get_post_meta($post_id, 'nets_pickup_date_placeholder', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pickup_date_placeholder',
            'name'        => 'nets_pickup_date_placeholder',
            'label'       => __('Pickup Date Placeholder', 'nets-rental'),
            'placeholder' => __('Pickup date placeholder', 'nets-rental'),
            'type'        => 'text',
            'value'       => $pickup_date_placeholder,
        )
    );


    $dropoff_date_heading_title = get_post_meta($post_id, 'nets_dropoff_date_heading_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'dropoff_date_heading_title',
            'name'        => 'nets_dropoff_date_heading_title',
            'label'       => __('Dropoff Date Heading Title', 'nets-rental'),
            'placeholder' => __('Dropoff date title', 'nets-rental'),
            'type'        => 'text',
            'value'       => $dropoff_date_heading_title,
        )
    );


    $dropoff_date_placeholder = get_post_meta($post_id, 'nets_dropoff_date_placeholder', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'dropoff_date_placeholder',
            'name'        => 'nets_dropoff_date_placeholder',
            'label'       => __('Drop-off Date Placeholder', 'nets-rental'),
            'placeholder' => __('Drop-off date placeholder', 'nets-rental'),
            'type'        => 'text',
            'value'       => $dropoff_date_placeholder,
        )
    );


    $pac_quantity_title = get_post_meta($post_id, 'pac_quantity_label', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_quantity_title',
            'name'        => 'pac_quantity_label',
            'label'       => __('Quantity Heading Title', 'nets-rental'),
            'placeholder' => __('Quantity title', 'nets-rental'),
            'type'        => 'text',
            'value'       => $pac_quantity_title,
        )
    );


    $security_deposite_heading_title = get_post_meta($post_id, 'nets_security_deposite_heading_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'security_deposite_heading_title',
            'name'        => 'nets_security_deposite_heading_title',
            'label'       => __('Security Deposite Heading Title', 'nets-rental'),
            'placeholder' => __('Security deposite title', 'nets-rental'),
            'type'        => 'text',
            'value'       => $security_deposite_heading_title,
        )
    );


    $discount_text_title = get_post_meta($post_id, 'nets_discount_text_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'discount_text_title',
            'name'        => 'nets_discount_text_title',
            'label'       => __('Discount Text', 'nets-rental'),
            'placeholder' => __('Discount Text', 'nets-rental'),
            'type'        => 'text',
            'value'       => $discount_text_title,
        )
    );

    $total_cost_text_title = get_post_meta($post_id, 'nets_total_cost_text_title', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'total_cost_text_title',
            'name'        => 'nets_total_cost_text_title',
            'label'       => __('Total Cost Text', 'nets-rental'),
            'placeholder' => __('Total Cost Text', 'nets-rental'),
            'type'        => 'text',
            'value'       => $total_cost_text_title,
        )
    );

    $invalid_date_range_notice = get_post_meta($post_id, 'pac_invalid_date_range_notice', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_invalid_date_range_notice',
            'name'        => 'pac_invalid_date_range_notice',
            'label'       => __('Invalid Date Range Notice', 'nets-rental'),
            'placeholder' => __('Invalid Date Range Notice', 'nets-rental'),
            'type'        => 'text',
            'value'       => $invalid_date_range_notice,
        )
    );
    $max_day_notice = get_post_meta($post_id, 'pac_max_day_notice', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_max_day_notice',
            'name'        => 'pac_max_day_notice',
            'label'       => __('Max Day Notice', 'nets-rental'),
            'placeholder' => __('Max Day Notice', 'nets-rental'),
            'type'        => 'text',
            'value'       => $max_day_notice,
        )
    );
    $min_day_notice = get_post_meta($post_id, 'pac_min_day_notice', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_min_day_notice',
            'name'        => 'pac_min_day_notice',
            'label'       => __('Min Day Notice', 'nets-rental'),
            'placeholder' => __('Min Day Notice', 'nets-rental'),
            'type'        => 'text',
            'value'       => $min_day_notice,
        )
    );
    $quantity_notice = get_post_meta($post_id, 'pac_quantity_notice', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'pac_quantity_notice',
            'name'        => 'pac_quantity_notice',
            'label'       => __('Invalid Quantity', 'nets-rental'),
            'placeholder' => __('Invalid Quantity', 'nets-rental'),
            'type'        => 'text',
            'value'       => $quantity_notice,
        )
    );


    $book_now_button_text = get_post_meta($post_id, 'nets_book_now_button_text', true);
    woocommerce_wp_text_input(
        array(
            'id'          => 'book_now_button_text',
            'name'        => 'nets_book_now_button_text',
            'label'       => __('Book Now Button Text', 'nets-rental'),
            'placeholder' => __('Book now button text', 'nets-rental'),
            'type'        => 'text',
            'value'       => $book_now_button_text,
        )
    );

    ?>
</div>