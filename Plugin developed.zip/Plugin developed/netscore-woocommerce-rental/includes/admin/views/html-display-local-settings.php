<div class="pac-setting-fields pac-display-fields">
    <?php
    $show_pickup_date = get_post_meta($post_id, 'nets_rental_local_show_pickup_date', true);
    if (empty($show_pickup_date)) {
        $pickupdate = get_option('pac_show_pickup_date');
        if (empty($pickupdate)) {
            $show_pickup_date = 'open';
        } else {
            if (get_option('pac_show_pickup_date') === 'yes') {
                $show_pickup_date = 'open';
            } else {
                $show_pickup_date = 'closed';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'nets_rental_local_show_pickup_date',
            'label'   => __('Show Pickup Date', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($show_pickup_date),
        )
    );

    $show_dropoff_date = get_post_meta($post_id, 'nets_rental_local_show_dropoff_date', true);
    if (empty($show_dropoff_date)) {
        $dropoffdate = get_option('pac_show_dropoff_date');
        if (empty($dropoffdate)) {
            $show_dropoff_date = 'open';
        } else {
            if (get_option('pac_show_dropoff_date') === 'yes') {
                $show_dropoff_date = 'open';
            } else {
                $show_dropoff_date = 'closed';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'nets_rental_local_show_dropoff_date',
            'label'   => __('Show Dropoff Date', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($show_dropoff_date),
        )
    );


    $enable_quantity = get_post_meta($post_id, 'pac_enable_quantity', true);
    if (empty($enable_quantity)) {
        $qty = get_option('pac_enable_quantity');
        if (empty($qty)) {
            $enable_quantity = 'open';
        } else {
            if (get_option('pac_enable_quantity') === 'yes') {
                $enable_quantity = 'open';
            } else {
                $enable_quantity = 'closed';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'pac_enable_quantity',
            'label'   => __('Enable Quantity', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($enable_quantity),
        )
    );


    $show_pricing_flip_box = get_post_meta($post_id, 'nets_rental_local_show_pricing_flip_box', true);
    if (empty($show_pricing_flip_box)) {
        $flipbox = get_option('pac_enable_price_flipbox');
        if (empty($flipbox)) {
            $show_pricing_flip_box = 'open';
        } else {
            if (get_option('pac_enable_price_flipbox') === 'yes') {
                $show_pricing_flip_box = 'open';
            } else {
                $show_pricing_flip_box = 'closed';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'nets_rental_local_show_pricing_flip_box',
            'label'   => __('Show pricing flip box', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($show_pricing_flip_box),
        )
    );

    $show_price_discount_on_days = get_post_meta($post_id, 'nets_rental_local_show_price_discount_on_days', true);
    if (empty($show_price_discount_on_days)) {
        $discount = get_option('pac_enable_price_discount');
        if (empty($discount)) {
            $show_price_discount_on_days = 'open';
        } else {
            if (get_option('pac_enable_price_discount') === 'yes') {
                $show_price_discount_on_days = 'open';
            } else {
                $show_price_discount_on_days = 'closed';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'nets_rental_local_show_price_discount_on_days',
            'label'   => __('Show price discount', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($show_price_discount_on_days),
        )
    );

    $show_book_now = get_post_meta($post_id, 'nets_rental_local_show_book_now', true);
    if (empty($show_book_now)) {
        $disable_book_now = get_option('pac_enable_book_now_btn');
        if (empty($disable_book_now)) {
            $show_book_now = 'open';
        } else {
            if (get_option('pac_enable_book_now_btn') === 'yes') {
                $show_book_now = 'closed';
            } else {
                $show_book_now = 'open';
            }
        }
    }

    woocommerce_wp_checkbox(
        array(
            'id'      => 'nets_rental_local_show_book_now',
            'label'   => __('Show Book Now', 'nets-rental'),
            'cbvalue' => 'open',
            'value'   => esc_attr($show_book_now),
        )
    );
    ?>
</div>