<div class="pac-setting-fields pac-condition-fields">
    <?php

    $date_format = get_post_meta($post_id, 'nets_calendar_date_format', true);
    woocommerce_wp_select(
        array(
            'id'          => 'choose_date_format',
            'label'       => __('Date Format', 'nets-rental'),
            'description' => __('Date will display in this format all place in rental product', 'nets-rental'),
            'desc_tip'    => true,
            'options'     => array(
                'm/d/Y' => __('m/d/Y', 'nets-rental'),
                'd/m/Y' => __('d/m/Y', 'nets-rental'),
                'Y/m/d' => __('Y/m/d', 'nets-rental'),
            ),
            'value'       => $date_format
        )
    );

    $time_format = get_post_meta($post_id, 'nets_calendar_time_format', true);
    woocommerce_wp_select(
        array(
            'id'          => 'choose_time_format',
            'label'       => __('Time Format', 'nets-rental'),
            'description' => __('This will be applicable in the time picker field in product page', 'nets-rental'),
            'options'     => array(
                '24-hours' => __('24 Hours', 'nets-rental'),
                '12-hours' => __('12 Hours', 'nets-rental'),
            ),
            'value'       => $time_format
        )
    );

 

    $enable_single_day_time_based_booking = get_post_meta($post_id, 'nets_rental_local_enable_single_day_time_based_booking', true);
    if (isset($enable_single_day_time_based_booking) && empty($enable_single_day_time_based_booking)) {
        $enable_single_day_time_based_booking = 'open';
    }
    woocommerce_wp_checkbox(
        array(
            'id'          => 'nets_rental_local_enable_single_day_time_based_booking',
            'label'       => __('Single Day Booking', 'nets-rental'),
            'desc_tip'    => true,
            'description' => sprintf(__('Checked : If pickup and return date are same then it counts as 1-day. Also select this for single date. FYI : Set max time late as at least 0 for this. UnChecked : If pickup and return date are same then it counts as 0-day. Also select this for single date. ', 'nets-rental')),
            'cbvalue'     => 'open',
            'value'       => esc_attr($enable_single_day_time_based_booking),
        )
    );

    $max_rental_days = get_post_meta($post_id, 'nets_max_rental_days', true);
    woocommerce_wp_text_input(
        array(
            'id'                => 'max_rental_days',
            'name'              => 'nets_max_rental_days',
            'label'             => __('Maximum Booking Days', 'nets-rental'),
            'placeholder'       => __('E.g. - 5', 'nets-rental'),
            'description'       => __('No. of days that customer must have to select during placing an order otherwise he will not be allowed to place an order', 'nets-rental'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min'  => '0'
            ),
            'value'             => $max_rental_days,
        )
    );


    $min_rental_days = get_post_meta($post_id, 'nets_min_rental_days', true);
    woocommerce_wp_text_input(
        array(
            'id'                => 'min_rental_days',
            'name'              => 'nets_min_rental_days',
            'label'             => __('Minimum Booking Days', 'nets-rental'),
            'placeholder'       => __('E.g. - 1', 'nets-rental'),
            'description'       => __('No. of days that customer must have to select during placing an order otherwise he will not be allowed to place an order', 'nets-rental'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min'  => '0'
            ),
            'value'             => $min_rental_days,
        )
    );

    $starting_block_days = get_post_meta($post_id, 'nets_rental_starting_block_dates', true);
    woocommerce_wp_text_input(
        array(
            'id'                => 'starting_block_days',
            'name'              => 'nets_rental_starting_block_dates',
            'label'             => __('Initially blocked dates in calendar', 'nets-rental'),
            'placeholder'       => __('E.g. - 2', 'nets-rental'),
            'description'       => __('If you set the value as 2, When someone open the calendar in product page if today is 10/10/2020 then customer will see the initially bookable date as 12/10/2020', 'nets-rental'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min'  => '0'
            ),
            'value'             => $starting_block_days,
        )
    );

    $pre_booking_block_days = get_post_meta($post_id, 'nets_rental_before_booking_block_dates', true);
    woocommerce_wp_text_input(
        array(
            'id'                => 'pre_booking_block_days',
            'name'              => 'nets_rental_before_booking_block_dates',
            'label'             => __('Pre Booking Block Days', 'nets-rental'),
            'placeholder'       => __('E.g. - 2', 'nets-rental'),
            'description'       => __('Selected no. of days will be blocked automatically after a booking order and customer will not be charged for extra these days. Suppose you set the value 2. Now if any customer books date from 10/10/18 to 12/10/18 then after completing the order 08/10/18 to 10/10/18 date will be disabled in calendar for this order. Although customer will not be charged for these extra 2 days', 'nets-rental'),
            'desc_tip'          => true,
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min'  => '0'
            ),
            'value'             => $pre_booking_block_days,
        )
    );


    $post_booking_block_days = get_post_meta($post_id, 'nets_rental_post_booking_block_dates', true);
    woocommerce_wp_text_input(
        array(
            'id'                => 'post_booking_block_days',
            'name'              => 'nets_rental_post_booking_block_dates',
            'label'             => __('Post Booking Block Days', 'nets-rental'),
            'placeholder'       => __('E.g. - 2', 'nets-rental'),
            'description'       => __('Selected no. of days will be blocked automatically after a booking and customer will not be charged for extra these days. Suppose you set the value 2. Now if any customer books date from 10/10/18 to 12/10/18 then after completing the order 10/10/18 to 14/10/18 date will be disabled in calendar for this order. Although customer will not be charged for these extra 2 days', 'nets-rental'),
            'type'              => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min'  => '0'
            ),
            'desc_tip'          => true,
            'value'             => $post_booking_block_days,
        )
    );

   
    woocommerce_wp_select(
        array(
            'id'          => 'pac_show_price_type',
            'name'        => 'pac_show_price_type',
            'label'       => __('Show Product Pricing', 'nets-rental'),
            'description' => __('If you set the value as yes then date or range of dates will be blocked after placing an order depending on no. of inventories. If you set the value as no then date will not be blocked after placing the order', 'nets-rental'),
            'desc_tip'    => true,
            'options'     => array(
                'daily'  => __('Daily Pricing', 'nets-rental'),
                'hourly' => __('Hourly Pricing', 'nets-rental'),
            ),
            'value'       => get_post_meta($post_id, 'pac_show_price_type', true)
        )
    );



    $booking_layout = get_post_meta($post_id, 'pac_booking_layout', true);
    woocommerce_wp_select(
        array(
            'id'          => 'pac_booking_layout',
            'label'       => __('Choose Booking Layout', 'nets-rental'),
            'description' => __('Choose your booking page layout. Either it will be normal view or modal view', 'nets-rental'),
            'options'     => array(
                'layout_one' => __('Normal Layout', 'nets-rental'),
                'layout_two' => __('Modal Layout', 'nets-rental'),
            ),
            'desc_tip'    => true,
            'value'       => $booking_layout
        )
    );

    $days = array(
        0 => esc_html__('Sunday', 'nets-rental'),
        1 => esc_html__('Monday', 'nets-rental'),
        2 => esc_html__('Tuesday', 'nets-rental'),
        3 => esc_html__('Wednesday', 'nets-rental'),
        4 => esc_html__('Thursday', 'nets-rental'),
        5 => esc_html__('Friday', 'nets-rental'),
        6 => esc_html__('Saturday', 'nets-rental'),
    );

    $rental_off_days = get_post_meta($post_id, 'nets_rental_off_days', true);

    if (isset($rental_off_days) && empty($rental_off_days)) {
        $rental_off_days = array();
    }

    ?>

    <p class="form-field">
        <label for="weekend"><?php esc_attr_e('Select Weekends', 'nets-rental'); ?></label>
        <select multiple="multiple" class="inventory-resources" style="width:350px" name="nets_rental_off_days[]" data-placeholder="<?php esc_attr_e('Choose off days', 'woocommerce'); ?>" title="<?php esc_attr_e('Weekends', 'woocommerce') ?>" class="wc-enhanced-select">
            <?php if (is_array($days) && !empty($days)) : ?>
                <?php foreach ($days as $key => $value) { ?>
                    <option value="<?php echo esc_attr($key); ?>" <?php if (in_array($key, $rental_off_days)) { ?> selected <?php
                                                                                                                                    } ?>><?php echo esc_attr($value); ?></option>
                <?php
                    } ?>
            <?php endif; ?>
        </select>
    </p>
</div>