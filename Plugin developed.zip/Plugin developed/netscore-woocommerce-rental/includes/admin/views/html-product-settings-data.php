<?php
$admin_url = get_admin_url();
$post_id = get_the_id();
?>
<div id="pac_setting_tabs">

    <ul>
        <li><a href="#showorhide"><?php esc_attr_e('Display', 'nets-rental'); ?></a></li>
        <li><a href="#physical_appearence"><?php esc_attr_e('Labels', 'nets-rental'); ?></a></li>
        <li><a href="#logical_appearence"><?php esc_attr_e('Conditions', 'nets-rental'); ?></a></li>
        <li><a href="#validation"><?php esc_attr_e('Validations', 'nets-rental'); ?></a></li>
    </ul>

    <div id="showorhide">
        <?php
        $display_url = esc_url($admin_url) . 'admin.php?page=wc-settings&tab=pac_settings&section=display';
        $value = get_post_meta($post_id, 'pac_settings_for_display', true);
        woocommerce_wp_select(
            array(
                'id'          => 'pac_settings_for_display',
                'label'       => __('Choose Settings For Display Tab', 'nets-rental'),
                'description' => sprintf(__('Please configure the display settings from <strong> ' . '<a href="%1$s" target="_blank"> ' . __('Global Settings', 'nets-rental') . '</a>' . ' </strong>panel.', 'nets-rental'), $display_url),
                'options'     => array(
                    'global' => __('Global Settings', 'nets-rental'),
                    'local'  => __('Local Settings', 'nets-rental'),
                ),
                //'desc_tip' => true,
                'value'       => $value
            )
        );
        include_once 'html-display-local-settings.php';
        ?>
    </div>

    <div id="physical_appearence">
        <?php
        $labels_url = esc_url($admin_url) . 'admin.php?page=wc-settings&tab=pac_settings&section=labels';
        $value = get_post_meta($post_id, 'pac_settings_for_labels', true);
        woocommerce_wp_select(
            array(
                'id'          => 'pac_settings_for_labels',
                'label'       => __('Choose Settings For Labels Tab', 'nets-rental'),
                'description' => sprintf(__('Please configure labels the settings from <strong> ' . '<a href="%1$s" target="_blank"> ' . __('Global Settings', 'nets-rental') . '</a>' . ' </strong>panel.', 'nets-rental'), $labels_url),
                'options'     => array(
                    'global' => __('Global Settings', 'nets-rental'),
                    'local'  => __('Local Settings', 'nets-rental'),
                ),
                'value'       => $value
            )
        );
        include_once 'html-labels-local-settings.php';
        ?>
    </div>

    <div id="logical_appearence">
        <?php
        do_action('pac_before_logical_apearence');

        $conditions_url = esc_url($admin_url) . 'admin.php?page=wc-settings&tab=pac_settings&section=conditions';
        $value = get_post_meta($post_id, 'pac_settings_for_conditions', true);
        woocommerce_wp_select(
            array(
                'id'          => 'pac_settings_for_conditions',
                'label'       => __('Choose Settings For Conditions Tab', 'nets-rental'),
                'description' => sprintf(__('Please configure the conditions settings from <strong> ' . '<a href="%1$s" target="_blank"> ' . __('Global Settings', 'nets-rental') . '</a>' . ' </strong>panel.', 'nets-rental'), $conditions_url),
                'options'     => array(
                    'global' => __('Global Settings', 'nets-rental'),
                    'local'  => __('Local Settings', 'nets-rental'),
                ),
                //'desc_tip' => true,
                'value'       => $value
            )
        );
        include_once 'html-condition-local-settings.php';
        do_action('pac_after_logical_appearence');
        ?>
    </div>

    <div id="validation">
        <?php
        $validations_url = esc_url($admin_url) . 'admin.php?page=wc-settings&tab=pac_settings&section=validations';
        $value = get_post_meta($post_id, 'pac_settings_for_validations', true);
        woocommerce_wp_select(
            array(
                'id'          => 'pac_settings_for_validations',
                'label'       => __('Choose Settings For Validations Tab', 'nets-rental'),
                'description' => sprintf(__('Please configure the validation settings from <strong> ' . '<a href="%1$s" target="_blank"> ' . __('Global Settings', 'nets-rental') . '</a>' . ' </strong>panel.', 'nets-rental'), $validations_url),
                'options'     => array(
                    'global' => __('Global Settings', 'nets-rental'),
                    'local'  => __('Local Settings', 'nets-rental'),
                ),
                //'desc_tip' => true,
                'value'       => $value
            )
        );
        include_once 'html-validation-local-settings.php';
        ?>
    </div>

</div>