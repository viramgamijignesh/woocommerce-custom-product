<?php

/**
 * WooCommerce Product Settings
 *
 * @author   Netsteam
 * @category Admin
 * @package  WooCommerce/Admin
 * @version  2.4.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('WC_Settings_Pac', false)) :

    /**
     * WC_Settings_Pac.
     */
    class WC_Settings_Pac extends WC_Settings_Page
    {

        /**
         * Constructor.
         */
        public function __construct()
        {
            $this->id    = 'pac_settings';
          //  $this->label = __('PaC Settings', 'nets-rental');
            $this->label = __('NetScore Rental Avalability Settings', 'nets-rental');

            add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
            add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
            add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
            add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
        }

        /**
         * Get sections.
         *
         * @return array
         */
        public function get_sections()
        {
            $sections = array(
                ''              => __('General', 'nets-rental'),
                'display'       => __('Display', 'nets-rental'),
                'labels'     => __('Labels', 'nets-rental'),
                'conditions'  => __('Conditions', 'nets-rental'),
                'validations'  => __('Validations', 'nets-rental'),
                'layout_two'  => __('Layout 2 (Extra Settings)', 'nets-rental'),
            );

            return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
        }

        /**
         * Output the settings.
         */
        public function output()
        {
            global $current_section;

            $settings = $this->get_settings($current_section);

            WC_Admin_Settings::output_fields($settings);
        }

        /**
         * Save settings.
         */
        public function save()
        {
            global $current_section;

            $settings = $this->get_settings($current_section);
            WC_Admin_Settings::save_fields($settings);
        }

        /**
         * Get settings array.
         *
         * @param string $current_section
         *
         * @return array
         */
        public function get_settings($current_section = '')
        {
            if ('display' == $current_section) {
                $settings = apply_filters('woocommerce_display_settings', array(

                    array(
                        'title' => __('Show or Hide DateTime Fields', 'nets-rental'),
                        'type'  => 'title',
                        'desc'  => '',
                        'id'    => 'pac_datetime_options',
                    ),

                    array(
                        'title'           => __('Enable DateTime Fields', 'nets-rental'),
                        'desc'            => __('Enable DateTime Fields', 'nets-rental'),
                        'id'              => 'pac_enable_datetime_fields',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => 'start',
                        'show_if_checked' => 'option',
                    ),

                    array(
                        'desc'            => __('Show Pickup Date', 'nets-rental'),
                        'id'              => 'pac_show_pickup_date',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                    array(
                        'desc'            => __('Show Pickup Time', 'nets-rental'),
                        'id'              => 'pac_show_pickup_time',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                    array(
                        'desc'            => __('Show Drop-off Date', 'nets-rental'),
                        'id'              => 'pac_show_dropoff_date',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                    array(
                        'desc'            => __('Show Drop-off Time', 'nets-rental'),
                        'id'              => 'pac_show_dropoff_time',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                    array(
                        'title'           => __('Enable Quantity', 'nets-rental'),
                        'desc'            => __('Enable Quantity Field', 'nets-rental'),
                        'id'              => 'pac_enable_quantity',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'image_options',
                    ),

                    array(
                        'title' => __('Display Button Options', 'nets-rental'),
                        'type'  => 'title',
                        'desc'  => '',
                        'id'    => 'pac_button_options',
                    ),

                    array(
                        'title'           => __('Button Options', 'nets-rental'),
                        'desc'            => __('Show Book Now Button', 'nets-rental'),
                        'id'              => 'pac_enable_book_now_btn',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                    ),

                  

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'image_options',
                    ),

                    array(
                        'title' => __('Others Options', 'nets-rental'),
                        'type'  => 'title',
                        'desc'  => '',
                        'id'    => 'pac_others_options',
                    ),

                    array(
                        'title'           => __('Show Price FlipBox', 'nets-rental'),
                        'desc'            => __('Show Price FlipBox', 'nets-rental'),
                        'id'              => 'pac_enable_price_flipbox',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                    ),

                    array(
                        'title'           => __('Show Price Discount', 'nets-rental'),
                        'desc'            => __('Show Price Discount', 'nets-rental'),
                        'id'              => 'pac_enable_price_discount',
                        'default'         => 'no',
                        'type'            => 'checkbox',
                    ),

                    array(
                        'title'           => __('Show Instance Payment', 'nets-rental'),
                        'desc'            => __('Show Instance Payment', 'nets-rental'),
                        'id'              => 'pac_enable_instance_payment',
                        'default'         => 'no',
                        'type'            => 'checkbox',
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'image_options',
                    ),

                ));
            } elseif ('labels' == $current_section) {
                $settings = apply_filters('woocommerce_labels_settings', array(

                    array(
                        'title' => __('Labels In Product Single Page', 'nets-rental'),
                        'type'  => 'title',
                        'desc'  => '',
                        'id'    => 'product_labels_options',
                    ),
                  
                    array(
                        'title' => __('Pricing Info Title', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as pricing title in front-end', 'nets-rental'),
                        'id'   => 'pac_pricing_flipbox_info_title',
                        'placeholder' => __('Pricing Info', 'nets-rental'),
                        'default'  => __('Pricing Info', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    array(
                        'title' => __('Unit Price Title', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_unit_price',
                        'placeholder' => __('Per Day', 'nets-rental'),
                        'default'  => __('Unit Price', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    array(
                        'title' => __('Pickup Date', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Pickup Date title in front-end', 'nets-rental'),
                        'id'   => 'pac_pickup_datetime_title',
                        'placeholder' => __('Pickup Date ', 'nets-rental'),
                        'default'  => __('Pickup Date ', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                  
                    array(
                        'title' => __('Pickup Date Placeholder', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Pickup Date Placeholder in front-end', 'nets-rental'),
                        'id'   => 'pac_pickup_date_placeholder',
                        'placeholder' => __('Pickup Date', 'nets-rental'),
                        'default'  => __('Pickup Date', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                     array(
                        'title' => __('Dropoff Date Title', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Dropoff Date title in front-end', 'nets-rental'),
                        'id'   => 'pac_dropoff_datetime_title',
                        'placeholder' => __('Dropoff Date ', 'nets-rental'),
                        'default'  => __('Dropoff Date ', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                   
                    array(
                        'title' => __('Drop-off Date Placeholder', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Drop-off Date Placeholder in front-end', 'nets-rental'),
                        'id'   => 'pac_dropoff_date_placeholder',
                        'placeholder' => __('Drop-off Date', 'nets-rental'),
                        'default'  => __('Drop-off Date', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                  
                    array(
                        'title' => __('Quantity Title', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_quantity_title',
                        'placeholder' => __('Quantity', 'nets-rental'),
                        'default'  => __('Quantity', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'title' => __('Deposit Title', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Deposit title in front-end', 'nets-rental'),
                        'id'   => 'pac_deposit_title',
                        'placeholder' => __('Deposit', 'nets-rental'),
                        'default'  => __('Deposit', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                   

                    array(
                        'name' => __('Invalid Date Range Notice', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_invalid_date_range_notice',
                        'placeholder' => __('Invalid date range', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    array(
                        'name' => __('Max Day Notice', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_max_day_notice',
                        'placeholder' => __('Enter max day exceed notice', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    array(
                        'name' => __('Min Day Notice', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_min_day_notice',
                        'placeholder' => __('Enter min day notice', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                  
                    array(
                        'title' => __('Discount Text', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as discount text in front-end', 'nets-rental'),
                        'id'   => 'pac_discount_text',
                        'placeholder' => __('Total Discount', 'nets-rental'),
                        'default'  => __('Total Discount', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    
                    array(
                        'title' => __('Total Cost Text', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Total Cost text in front-end', 'nets-rental'),
                        'id'   => 'pac_total_cost_text',
                        'placeholder' => __('Total Cost', 'nets-rental'),
                        'default'  => __('Total Cost', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    array(
                        'title' => __('Book Now Button Text', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('This text will show as Book Now text in front-end', 'nets-rental'),
                        'id'   => 'pac_book_now_text',
                        'placeholder' => __('Book Now', 'nets-rental'),
                        'default'  => __('Book Now', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'product_inventory_options',
                    ),

                ));
            } elseif ('conditions' == $current_section) {
                $settings = apply_filters('woocommerce_conditions_settings', array(
                    array(
                        'title' => __('Choose Different Conditions Logic For Products', 'nets-rental'),
                        'type'  => 'title',
                        'id'    => 'pac_conditionals_options',
                    ),

                    array(
                        'title'    => __('Date Format', 'nets-rental'),
                        'desc'     => __('Date will display in this format all place in rental product', 'nets-rental'),
                        'id'       => 'pac_choose_date_format',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:150px;',
                        'desc_tip' => true,
                        'options' => array(
                            'm/d/Y' => __('m/d/Y', 'nets-rental'),
                            'd/m/Y' => __('d/m/Y', 'nets-rental'),
                            'Y/m/d' => __('Y/m/d', 'nets-rental'),
                        ),
                        'autoload' => false,
                        'default'  => 'm/d/Y',
                    ),

                    array(
                        'title'    => __('Time Format', 'nets-rental'),
                        'desc'     => __('This will be applicable in the time picker field in product page', 'nets-rental'),
                        'id'       => 'pac_choose_time_format',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:150px;',
                        'desc_tip' => true,
                        'options' => array(
                            '24-hours' => __('24 Hours', 'nets-rental'),
                            '12-hours' => __('12 Hours', 'nets-rental'),
                        ),
                        'autoload' => true,
                        'default'  => '24-hours',
                    ),

                  
                    array(
                        'title'           => __('Single Day Booking', 'nets-rental'),
                        'desc'            => __('Checked : If pickup and return date are same then it counts as 1-day. Also select this for single date. FYI : Set max time late as at least 0 for this. UnChecked : If pickup and return date are same then it counts as 0-day. Also select this for single date. ', 'nets-rental'),
                        'id'              => 'pac_single_day_booking',
                        'desc_tip' => true,
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                    ),
                    array(
                        'title' => __('Max Booking Days', 'nets-rental'),
                        'desc' => __('No. of days that customer must have to select during placing an order otherwise he will not be allowed to place an order', 'nets-rental'),
                        'placeholder' => __('E.g. - 6', 'nets-rental'),
                        'type' => 'number',
                        'id'   => 'pac_max_book_day',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0'
                        ),
                    ),
                    array(
                        'title' => __('Min Booking Days', 'nets-rental'),
                        'desc' => __('No. of days that customer must have to select during placing an order otherwise he will not be allowed to place an order', 'nets-rental'),
                        'placeholder' => __('E.g. - 2', 'nets-rental'),
                        'type' => 'number',
                        'id'   => 'pac_min_book_day',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0'
                        ),
                    ),
                    array(
                        'title' => __('Initially blocked dates in calendar', 'nets-rental'),
                        'desc' => __('If you set the value as 2, When someone open the calendar in product page if today is 10/10/2018 then customer will see the initially bookable date as 12/10/2018', 'nets-rental'),
                        'placeholder' => __('E.g. - 2', 'nets-rental'),
                        'type' => 'number',
                        'id'   => 'pac_staring_block_days',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0'
                        ),
                    ),

                    array(
                        'title' => __('Pre Booking Block Days', 'nets-rental'),
                        'desc' => __('Selected no. of days will be blocked automatically after a booking order and customer will not be charged for extra these days. Suppose you set the value 2. Now if any customer books date from 10/10/18 to 12/10/18 then after completing the order 08/10/18 to 10/10/18 date will be disabled in calendar for this order. Although customer will not be charged for these extra 2 days', 'nets-rental'),
                        'placeholder' => __('E.g. - 2', 'nets-rental'),
                        'type' => 'number',
                        'id'   => 'pac_before_block_days',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0'
                        ),
                    ),

                    array(
                        'title' => __('Post Booking Block Days', 'nets-rental'),
                        'desc' => __('Selected no. of days will be blocked automatically after a booking and customer will not be charged for extra these days. Suppose you set the value 2. Now if any customer books date from 10/10/18 to 12/10/18 then after completing the order 10/10/18 to 14/10/18 date will be disabled in calendar for this order. Although customer will not be charged for these extra 2 days', 'nets-rental'),
                        'placeholder' => __('E.g. - 2', 'nets-rental'),
                        'type' => 'number',
                        'id'   => 'pac_post_block_days',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0'
                        ),
                    ),
                  
                    array(
                        'title'    => __('Show Product Price', 'nets-rental'),
                        'desc'     => __('If you set daily pricing then per day price will show as product price, if you set hourly pricing then hour price will show as product price', 'nets-rental'),
                        'id'       => 'pac_show_price_type',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:150px;',
                        'desc_tip' => true,
                        'options'  => array(
                            'daily'  => __('Daily Pricing', 'nets-rental'),
                            'hourly' => __('Hourly Pricing', 'nets-rental'),
                        ),
                        'autoload' => false,
                    ),

                    array(
                        'title'    => __('Select Weekends', 'nets-rental'),
                        'desc'     => __('Choose Weekends', 'nets-rental'),
                        'id'       => 'pac_weekends',
                        'type'     => 'multiselect',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:300px;',
                        'desc_tip' => true,
                        'options' => array(
                            1 => esc_html__('Sunday', 'nets-rental'),
                            2 => esc_html__('Monday', 'nets-rental'),
                            3 => esc_html__('Tuesday', 'nets-rental'),
                            4 => esc_html__('Wednesday', 'nets-rental'),
                            5 => esc_html__('Thursday', 'nets-rental'),
                            6 => esc_html__('Friday', 'nets-rental'),
                            7 => esc_html__('Saturday', 'nets-rental'),
                        ),
                    ),

                    array(
                        'title'    => __('Choose Layout', 'nets-rental'),
                        'desc'     => __('Choose your booking page layout. Either it will be normal view or modal view', 'nets-rental'),
                        'id'       => 'pac_booking_layout',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:150px;',
                        'desc_tip' => true,
                        'options'  => array(
                            'layout_one'    => __('Normal Layout', 'nets-rental'),
                            'layout_two'    => __('Modal Layout', 'nets-rental'),
                        ),
                        'autoload' => false,
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'digital_download_options',
                    ),






                ));
            } elseif ('validations' == $current_section) {
                $settings = apply_filters('woocommerce_validations_settings', array(

                    array(
                        'title' => __('Enable or Disable Required Fields', 'nets-rental'),
                        'type'  => 'title',
                        'desc'  => '',
                        'id'    => 'pac_datetime_options',
                    ),

                    array(
                        'title'           => __('Required Fields', 'nets-rental'),
                        'desc'            => __('Choose Value Must Required Fields', 'nets-rental'),
                        'id'              => 'pac_required_fields',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => 'start',
                        'show_if_checked' => 'option',
                    ),

           

                    array(
                        'desc'            => __('Required Pickup Time', 'nets-rental'),
                        'id'              => 'pac_required_pickup_time',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                    array(
                        'desc'            => __('Required Drop-off Time', 'nets-rental'),
                        'id'              => 'pac_required_dropoff_time',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                        'checkboxgroup'   => '',
                        'show_if_checked' => 'yes',
                        'autoload'        => false,
                    ),

                   
                    array(
                        'type'  => 'sectionend',
                        'id'    => 'digital_download_options',
                    ),

                ));
            } elseif ('layout_two' == $current_section) {
                $settings = apply_filters('woocommerce_validations_settings', array(

                    array(
                        'title'     => __('Extra Fields For Layout Two', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_layout_two_fields',
                    ),

                    array(
                        'title'    => __('PaC background color', 'nets-rental'),
                        'desc'     => sprintf(__('The main PaC background color. Default %s.', 'nets-rental'), '<code>#b07aa4</code>'),
                        'id'       => 'pac_overall_color_display_option',
                        'type'     => 'color',
                        'css'      => 'width:6em;',
                        'default'  => '#b07aa4',
                        'autoload' => false,
                        'desc_tip' => true,
                    ),

                    array(
                        'name' => __('Inventory Top Heading', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_inventory_top_heading',
                        'placeholder' => __('Inventory Top Heading', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                   
                    array(
                        'name' => __('Date Top Heading', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_date_top_heading',
                        'placeholder' => __('Date Top Heading', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                   

                    array(
                        'name' => __('Deposit Top Heading', 'nets-rental'),
                        'type' => 'text',
                        'id'   => 'pac_deposit_top_heading',
                        'placeholder' => __('Deposit Top Heading', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),
                    
                    array(
                        'type'  => 'sectionend',
                        'id'    => 'digital_download_options',
                    ),

                ));
            } else {
                $settings = apply_filters('woocommerce_products_general_settings', array(

                    array(
                        'title'     => __('Make Product Calendar In Your Language', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_product_calendar_personalize',
                    ),

                    array(
                        'name' => __('Language Domain', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('Enter your language domain. E.g. - de', 'nets-rental'),
                        'id'   => 'pac_lang_domain',
                        'placeholder' => __('Lanuage Domain E.g - fr', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                  

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_instastant_payment_options',
                    ),

                    array(
                        'title'     => __('Configure Instance Payments', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_instastant_payment_section_title',
                    ),

                    array(
                        'title' => __('Pay During Booking', 'nets-rental'),
                        'type' => 'number',
                        'desc' => __('You must have to pay this percentage (%) amount during booking. default pay amount value is 100%', 'nets-rental'),
                        'placeholder' => __('E.g. - 2', 'nets-rental'),
                        'id'   => 'pac_instance_payment',
                        'css'      => 'width: 80px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'step'  => '1',
                            'min'   => '0',
                            'max'   => '100'
                        ),
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_rfq_options',
                    ),


                    array(
                        'title'     => __('Miscellaneous Sections', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_miscellaneous_section',
                    ),

                    // array(
                    //     'title'           => __('Show Price Info At Top in Price Flip box', 'nets-rental'),
                    //     'desc'            => __('Show Price Info At Top in Price Flip box', 'nets-rental'),
                    //     'id'              => 'pac_flipbox_price_top_info',
                    //     'default'         => 'yes',
                    //     'type'            => 'checkbox',
                    // ),

                    array(
                        'name' => __('Shop Page Button Label', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('Enter Your Shop Page Button Label. E.g. - Read More', 'nets-rental'),
                        'id'   => 'pac_shop_page_button',
                        'placeholder' => __('Read More', 'nets-rental'),
                        'default' => __('Read More', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'name' => __('Holidays', 'nets-rental'),
                        'type' => 'textarea',
                        'desc' => __('Enter holidays in this format E.g.: 2018-07-18 to 2018-07-26,2018-08-18 to 2018-08-20', 'nets-rental'),
                        'id'   => 'pac_holidays',
                        'placeholder' => __('Enter holidays in this format E.g.: 2018-07-18 to 2018-07-26, 2018-08-18 to 2018-08-20', 'nets-rental'),
                        'css'      => 'width: 550px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                        'custom_attributes' => array(
                            'rows'  => '5',
                        ),
                    ),

                    array(
                        'title'    => __('Select day of week start', 'nets-rental'),
                        'desc'     => __('Choose day of week start', 'nets-rental'),
                        'id'       => 'pac_day_of_week_start',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:250px;',
                        'desc_tip' => true,
                        'options' => array(
                            1 => esc_html__('Sunday', 'nets-rental'),
                            2 => esc_html__('Monday', 'nets-rental'),
                            3 => esc_html__('Tuesday', 'nets-rental'),
                            4 => esc_html__('Wednesday', 'nets-rental'),
                            5 => esc_html__('Thursday', 'nets-rental'),
                            6 => esc_html__('Friday', 'nets-rental'),
                            7 => esc_html__('Saturday', 'nets-rental'),
                        ),
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_miscellaneous_section',
                    ),

                  

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_general_section_end',
                    ),


                    array(
                        'title'     => __('Google Map Configuration', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_gmap_section',
                    ),

                    array(
                        'title'           => __('Enable Google Map For Location', 'nets-rental'),
                        'id'              => 'pac_enable_gmap',
                        'default'         => 'yes',
                        'type'            => 'checkbox',
                    ),

                    array(
                        'name'          => __('Google Map Api Key', 'nets-rental'),
                        'type'          => 'text',
                        'desc'          => __('Enter google map API Key', 'nets-rental'),
                        'id'            => 'pac_gmap_api_key',
                        'placeholder'   => __('Google map api key', 'nets-rental'),
                        'css'           => 'width: 550px;',
                        'autoload'      => false,
                        'desc_tip'      => true,
                        'class'         => 'manage_stock_field',
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_general_section_end',
                    ),







                    array(
                        'title'     => __('Universal Labels', 'nets-rental'),
                        'type'      => 'title',
                        'id'        => 'pac_universal_label',
                    ),

                 

                    array(
                        'name' => __('Total Days Label (cart,checkout,order pages)', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('Enter the text label E.g. - Total Days', 'nets-rental'),
                        'id'   => 'pac_total_days_label',
                        'default'       => __('Total Days', 'nets-rental'),
                        'placeholder' => __('Total Days', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'name' => __('Total Hours Label (cart,checkout,order pages)', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('Enter the text label E.g. - Total Hours', 'nets-rental'),
                        'id'   => 'pac_total_hours_label',
                        'default'       => __('Total Hours', 'nets-rental'),
                        'placeholder' => __('Total Hours', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'name' => __('Payment Due Label (cart,checkout,order pages)', 'nets-rental'),
                        'type' => 'text',
                        'desc' => __('Enter the text label E.g. - Payment Due', 'nets-rental'),
                        'id'   => 'pac_payment_due_label',
                        'default'  => __('Payment Due', 'nets-rental'),
                        'placeholder' => __('Payment Due', 'nets-rental'),
                        'css'      => 'width: 250px;',
                        'autoload' => false,
                        'desc_tip' => true,
                        'class'    => 'manage_stock_field',
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'pac_universal_label_end',
                    ),


                ));
            }

            return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
        }
    }

endif;

return new WC_Settings_Pac();
