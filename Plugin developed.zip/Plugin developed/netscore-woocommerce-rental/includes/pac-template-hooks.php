<?php
/**
 * PaC Template Hooks
 *
 * Action/filter hooks used for PaC functions/templates.
 *
 * @author        NetSTeam
 * @category    Core
 * @package    PaC/Templates
 * @version     2.1.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


/**
 * Content Wrappers.
 *
 * @see woocommerce_output_content_wrapper()
 */
add_action('pac_before_add_to_cart_form', 'pac_price_flip_box', 10);
add_action('pac_before_add_to_cart_form', 'pac_validation_notice', 15);


/**
 * Content Wrappers.
 *
 * @see woocommerce_output_content_wrapper()
 */
add_action('pac_main_rental_content', 'pac_pickup_locations', 10);

add_action('pac_main_rental_content', 'pac_return_locations', 15);
add_action('pac_main_rental_content', 'pac_pickup_datetimes', 20);
add_action('pac_main_rental_content', 'pac_return_datetimes', 25);
add_action('pac_main_rental_content', 'pac_quantity', 28);
add_action('pac_main_rental_content', 'pac_payable_resources', 30);
add_action('pac_main_rental_content', 'pac_payable_categories', 40);
add_action('pac_main_rental_content', 'pac_payable_persons', 50);
add_action('pac_main_rental_content', 'pac_payable_deposits', 60);
add_action('pac_main_rental_content', 'pac_select_inventory', 5);


/**
 * Content Wrappers.
 *
 * @see pac_modal_booking_func()
 */
add_action('pac_modal_booking', 'pac_modal_booking_func', 10);


/**
 * Content Wrappers.
 *
 * @see woocommerce_output_content_wrapper()
 */

$pac_booking_layout = get_post_meta(get_the_ID(), 'pac_booking_layout', true);
if ($pac_booking_layout === 'layout_two') {
    add_action('woocommerce_before_add_to_cart_button', 'pac_booking_summary_two', 10);
} else {
    add_action('woocommerce_before_add_to_cart_button', 'pac_booking_summary', 10);
}


/**
 * Content Wrappers.
 *
 * @see woocommerce_output_content_wrapper()
 */
add_action('pac_plain_booking_button', 'pac_direct_booking', 10);
add_action('pac_plain_booking_button', 'pac_request_quote', 20);