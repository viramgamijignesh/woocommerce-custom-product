<?php

class Pac_Enqueue_Files
{
    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'frontend_styles_and_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_styles_and_scripts'));
        add_filter('woocommerce_screen_ids', array($this, 'pac_screen_ids'));

        add_action('wp_ajax_pac_get_inventory_data', array($this, 'get_inventory_data'));
        add_action('wp_ajax_nopriv_pac_get_inventory_data', array($this, 'get_inventory_data'));
    }

    public function get_inventory_data()
    {
        $inventory_id = $_POST['inventory_id'];
        $product_id = $_POST['post_id'];

        $availability = pac_inventory_availability_check($product_id, $inventory_id);
        $allowed_datetime = pac_inventory_availability_check($product_id, $inventory_id, 'ALLOWED_DATETIMES_ONLY');

        $cart_dates = rental_product_in_cart($product_id);
        $starting_block_days = nets_rental_staring_block_days($product_id);

        $holidays = nets_rental_handle_holidays($product_id);

        $buffer_dates = array_merge($starting_block_days, $cart_dates, $holidays);

        $pac_data = pac_get_combined_settings_data($product_id);

        $pricing_data = nets_rental_get_pricing_data($inventory_id, $product_id);
        $pac_data['pricings'] = $pricing_data;

        $price_unit = pac_get_product_price($product_id, $inventory_id);
        $price_unit_markup = $price_unit['prefix'] . '&nbsp;' . wc_price($price_unit['price']) . '&nbsp;' . $price_unit['suffix'];

        $woocommerce_info = pac_get_woocommerce_currency_info();
        $translated_strings = pac_get_translated_strings();
        $localize_info = pac_get_localize_info($product_id);

        $booking_data = array(
            'pac_data'           => $pac_data,
            'block_dates'        => $availability,
            'woocommerce_info'   => $woocommerce_info,
            'translated_strings' => $translated_strings,
            'availability'       => $availability,
            'buffer_days'        => $buffer_dates,
            'quantity'           => get_post_meta($inventory_id, 'quantity', true),
            'unit_price'         => $price_unit_markup,
            'product_id'         => $product_id
        );

        $calendar_data = array(
            'availability'       => $availability,
            'calendar_props'     => $pac_data,
            'block_dates'        => $availability,
            'allowed_datetime'   => $allowed_datetime,
            'localize_info'      => $localize_info,
            'translated_strings' => $translated_strings,
            'buffer_days'        => $buffer_dates,
        );

        $conditions = nets_rental_get_settings($product_id, 'conditions');
        $conditional_data = $conditions['conditions'];


        $pick_up_locations = pac_arrange_pickup_location_data($product_id, $inventory_id, $conditional_data);
        $return_locations = pac_arrange_return_location_data($product_id, $inventory_id, $conditional_data);
        $deposits = pac_arrange_security_deposit_data($product_id, $inventory_id, $conditional_data);
        $adult_data = pac_arrange_adult_data($product_id, $inventory_id, $conditional_data);
        $child_data = pac_arrange_child_data($product_id, $inventory_id, $conditional_data);
        $resources = pac_arrange_resource_data($product_id, $inventory_id, $conditional_data);
        $categories = pac_arrange_category_data($product_id, $inventory_id, $conditional_data);

        echo json_encode(array(
            'booking_data'      => $booking_data,
            'calendar_data'     => $calendar_data,
            'pick_up_locations' => $pick_up_locations,
            'return_locations'  => $return_locations,
            'deposits'          => $deposits,
            'adults'           => $adult_data,
            'childs'           => $child_data,
            'resources'         => $resources,
            'categories'        => $categories,
        ));


        wp_die();
    }


    /**
     * Frontend enqueued front-end stylesheet and scripts
     *
     * @return null
     * @since 1.0.0
     */
    public function frontend_styles_and_scripts()
    {

        $post_id = get_the_ID();
        $nets_product_inventory = pac_get_product_inventory_id($post_id);

        $inventory_id = '';
        if (!empty($nets_product_inventory)) {
            $inventory_id = $nets_product_inventory[0];
        }

        wp_enqueue_script('underscore');



        wp_register_script('pac-calendar', NETS_ROOT_URL . '/assets/js/pac-calendar.js', array('jquery'), false, true);
        wp_enqueue_script('pac-calendar');

        wp_register_script('pac-template', NETS_ROOT_URL . '/assets/js/pac-template.js', array('jquery'), false, true);
        wp_enqueue_script('pac-template');

        wp_register_script('pac-init', NETS_ROOT_URL . '/assets/js/pac-init.js', array('jquery'), false, true);
        wp_enqueue_script('pac-init');

        wp_register_script('quote-handle', NETS_ROOT_URL . '/assets/js/quote.js', array('jquery'), false, true);
        wp_enqueue_script('quote-handle');

        wp_register_style('rental-quote', NETS_ROOT_URL . '/assets/css/quote-front.css', array(), $ver = false, $media = 'all');
        wp_enqueue_style('rental-quote');

        wp_register_script('chosen.jquery', NETS_ROOT_URL . '/assets/js/chosen.jquery.js', array('jquery'), true);
        wp_enqueue_script('chosen.jquery');

        wp_register_style('chosen', NETS_ROOT_URL . '/assets/css/chosen.css', array(), $ver = false, $media = 'all');
        wp_enqueue_style('chosen');

        wp_localize_script('quote-handle', 'NETS_MYACCOUNT_API', array(
            'ajax_url' => admin_url('admin-ajax.php'),
        ));

        if (is_rental_product($post_id)) {

            $check_ssl = is_ssl() ? 'https' : 'http';

            wp_register_style('rental-global', NETS_ROOT_URL . '/assets/css/rental-global.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('rental-global');

            wp_register_script('clone', NETS_ROOT_URL . '/assets/js/clone.js', array('jquery'), true);
            wp_enqueue_script('clone');

            wp_register_script('jquery.datetimepicker.full', NETS_ROOT_URL . '/assets/js/jquery.datetimepicker.full.js', array('jquery'), true);
            wp_enqueue_script('jquery.datetimepicker.full');

            wp_register_style('jquery.datetimepicker', NETS_ROOT_URL . '/assets/css/jquery.datetimepicker.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('jquery.datetimepicker');

            wp_register_script('sweetalert.min', NETS_ROOT_URL . '/assets/js/sweetalert.min.js', array('jquery'), true);
            wp_enqueue_script('sweetalert.min');

            wp_register_style('sweetalert', NETS_ROOT_URL . '/assets/css/sweetalert.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('sweetalert');

            wp_enqueue_style('font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
            wp_enqueue_style('ion-icon', '' . $check_ssl . '://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css');

            wp_register_script('jquery.steps', NETS_ROOT_URL . '/assets/js/jquery.steps.js', array('jquery'), true);
            wp_enqueue_script('jquery.steps');

            wp_register_style('jquery.steps', NETS_ROOT_URL . '/assets/css/jquery.steps.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('jquery.steps');



            wp_register_style('rental-style', NETS_ROOT_URL . '/assets/css/rental-style.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('rental-style');

            wp_register_style('magnific-popup', NETS_ROOT_URL . '/assets/css/magnific-popup.css', array(), $ver = false, $media = 'all');
            wp_enqueue_style('magnific-popup');

            wp_register_script('date', NETS_ROOT_URL . '/assets/js/date.js', array('jquery'), true);
            wp_enqueue_script('date');

            wp_register_script('accounting', NETS_ROOT_URL . '/assets/js/accounting.js', array('jquery'), true);
            wp_enqueue_script('accounting');

            wp_register_script('jquery.flip', NETS_ROOT_URL . '/assets/js/jquery.flip.js', array('jquery'), true);
            wp_enqueue_script('jquery.flip');

            wp_register_script('magnific-popup', NETS_ROOT_URL . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), true);
            wp_enqueue_script('magnific-popup');

            //Enable or Disable google map
            $this->pac_handle_google_map($post_id);

            wp_register_script('front-end-scripts', NETS_ROOT_URL . '/assets/js/main-script.js', array('jquery', 'underscore', 'chosen.jquery', 'pac-calendar', 'pac-template', 'pac-init'), true);
            wp_enqueue_script('front-end-scripts');

            wp_register_script('pac-rfq', NETS_ROOT_URL . '/assets/js/pac-rfq.js', array('jquery', 'underscore', 'chosen.jquery', 'pac-calendar', 'pac-template', 'pac-init'), true);
            wp_enqueue_script('pac-rfq');

            wp_register_script('pac-validation', NETS_ROOT_URL . '/assets/js/pac-validation.js', array('jquery'), true);
            wp_enqueue_script('pac-validation');

            $cart_dates = rental_product_in_cart($post_id);
            $starting_block_days = nets_rental_staring_block_days($post_id);
            $holidays = nets_rental_handle_holidays($post_id);
            $buffer_dates = array_merge($starting_block_days, $cart_dates, $holidays);
            $availability = pac_inventory_availability_check($post_id, $inventory_id);

            $settings_data = pac_get_combined_settings_data($post_id);
            $woocommerce_info = pac_get_woocommerce_currency_info();
            $translated_strings = pac_get_translated_strings();
            $localize_info = pac_get_localize_info($post_id);


            $conditions = nets_rental_get_settings($post_id, 'conditions');
            $conditional_data = $conditions['conditions'];

            $pickup_locations = pac_arrange_pickup_location_data($post_id, $inventory_id, $conditional_data);
            $return_locations = pac_arrange_return_location_data($post_id, $inventory_id, $conditional_data);
            $deposits = pac_arrange_security_deposit_data($post_id, $inventory_id, $conditional_data);
            $adult_data = pac_arrange_adult_data($post_id, $inventory_id, $conditional_data);
            $child_data = pac_arrange_child_data($post_id, $inventory_id, $conditional_data);
            $resources = pac_arrange_resource_data($post_id, $inventory_id, $conditional_data);
            $categories = pac_arrange_category_data($post_id, $inventory_id, $conditional_data);


            wp_localize_script('front-end-scripts', 'CALENDAR_DATA', array(
                'availability'       => $availability,
                'calendar_props'     => $settings_data,
                'block_dates'        => $availability,
                'woocommerce_info'   => $woocommerce_info,
                'allowed_datetime'   => pac_inventory_availability_check($post_id, $inventory_id, 'ALLOWED_DATETIMES_ONLY'),
                'localize_info'      => $localize_info,
                'translated_strings' => $translated_strings,
                'buffer_days'        => $buffer_dates,
                'quantity'           => get_post_meta($inventory_id, 'quantity', true),
                'ajax_url'           => pac_get_ajax_url(),
                'pick_up_locations' => $pickup_locations,
                'return_locations' => $return_locations,
                'resources' => $resources,
                'categories' => $categories,
                'adults' => $adult_data,
                'childs' => $child_data,
                'deposits' => $deposits,
            ));

            wp_localize_script('pac-rfq', 'RFQ_DATA', array(
                'ajax_url'           => pac_get_ajax_url(),
                'translated_strings' => $translated_strings,
            ));
        }
    }


    public function pac_handle_google_map($product_id)
    {
        $gmap_enable = get_option('pac_enable_gmap');
        $map_key = get_option('pac_gmap_api_key');
        $conditions = nets_rental_get_settings($product_id, 'conditions');
        if ($gmap_enable === 'yes' && $map_key && isset($conditions['conditions']['booking_layout']) && $conditions['conditions']['booking_layout'] !== 'layout_one') {

            $markers = array(
                'pickup'      => NETS_ROOT_URL . '/assets/img/marker-pickup.png',
                'destination' => NETS_ROOT_URL . '/assets/img/marker-destination.png'
            );

            wp_register_script('google-map-api', '//maps.googleapis.com/maps/api/js?key=' . $map_key . '&libraries=places,geometry&language=en-US', true, false);
            wp_enqueue_script('google-map-api');

            wp_register_script('pac-map', NETS_ROOT_URL . '/assets/js/pac-map.js', array('jquery'), true);
            wp_enqueue_script('pac-map');

            wp_localize_script('pac-map', 'PAC_MAP', array(
                'markers'       => $markers,
                'pickup_title'  => esc_html__('Pickup Point', 'nets-rental'),
                'dropoff_title' => esc_html__('DropOff Point', 'nets-rental'),
            ));
        }
    }


    public function pac_screen_ids($screen_ids)
    {

        $screen_ids[] = 'toplevel_page_pac_admin';
        $screen_ids[] = 'toplevel_page_pac_addons';
        $screen_ids[] = 'edit-request_quote';
        $screen_ids[] = 'edit-inventory';
        $screen_ids[] = 'inventory';
        $screen_ids[] = 'edit-resource';
        $screen_ids[] = 'edit-pac_categories';
        $screen_ids[] = 'edit-resource';
        $screen_ids[] = 'edit-person';
        $screen_ids[] = 'edit-deposite';
        $screen_ids[] = 'edit-attributes';
        $screen_ids[] = 'edit-features';
        $screen_ids[] = 'edit-pickup_location';
        $screen_ids[] = 'edit-dropoff_location';

        return $screen_ids;
    }


    /**
     * Plugin enqueues admin stylesheet and scripts
     *
     * @since 1.0.0
     */
    public function admin_styles_and_scripts($hook)
    {
        global $woocommerce, $wpdb;
        $screen = get_current_screen();
        $screen_id = $screen ? $screen->id : '';

        wp_register_script('jquery-ui-js', NETS_ROOT_URL . '/assets/js/jquery-ui.js', array('jquery'), $ver = true, true);
        wp_register_style('jquery-ui-css', NETS_ROOT_URL . '/assets/css/jquery-ui.css', array(), $ver = false, $media = 'all');
        wp_register_script('select2.min', NETS_ROOT_URL . '/assets/js/select2.min.js', array('jquery'), $ver = true, true);

        wp_register_script('jquery.datetimepicker.full', NETS_ROOT_URL . '/assets/js/jquery.datetimepicker.full.js', array('jquery'), true);
        wp_enqueue_script('jquery.datetimepicker.full');

        wp_register_style('jquery.datetimepicker', NETS_ROOT_URL . '/assets/css/jquery.datetimepicker.css', array(), $ver = false, $media = 'all');
        wp_enqueue_style('jquery.datetimepicker');


        wp_register_style('nets-admin', NETS_ROOT_URL . '/assets/css/nets-admin.css', array(), $ver = false, $media = 'all');
        wp_register_style('nets-quote', NETS_ROOT_URL . '/assets/css/nets-quote.css', array(), $ver = false, $media = 'all');
        wp_register_script('icon-picker', NETS_ROOT_URL . '/assets/js/icon-picker.js', array('jquery'), $ver = true, true);
        wp_register_script('nets_rental_writepanel_js', NETS_ROOT_URL . '/assets/js/writepanel.js', array('jquery', 'jquery-ui-datepicker'), true);

        // Admin styles for WC , Inventory & RFQ pages only
        if (in_array($screen_id, wc_get_screen_ids(), true) && $screen_id !== 'shop_coupon') {

            $postid = get_the_ID();

            $params = array(
                'plugin_url'     => $woocommerce->plugin_url(),
                'ajax_url'       => admin_url('admin-ajax.php'),
                'calendar_image' => $woocommerce->plugin_url() . '/assets/images/calendar.png',
            );

            $products_by_inventory = $wpdb->get_results($wpdb->prepare("SELECT product FROM {$wpdb->prefix}pac_inventory_product WHERE inventory = %d", $postid));

            if (isset($postid) && !empty($postid)) {
                $post_type = get_post_type($postid);
                $post_id = isset($post_type) && $post_type === 'inventory' && count($products_by_inventory) ? $products_by_inventory[0]->product : '';
                $conditions = nets_rental_get_settings($post_id, 'conditions');
                $admin_data = $conditions['conditions'];
                $params['calendar_data'] = $admin_data;
            }

            wp_enqueue_script('jquery-ui-js');
            wp_enqueue_style('jquery-ui-css');
            wp_enqueue_script('select2.min');
            wp_enqueue_style('nets-admin');
            wp_enqueue_style('nets-quote');
            wp_enqueue_script('icon-picker');
            wp_enqueue_script('jquery-ui-datepicker');
            wp_enqueue_script('jquery-ui-tabs');
            wp_enqueue_media();
            wp_enqueue_style('font-awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
            wp_enqueue_script('nets_rental_writepanel_js');
            wp_localize_script('nets_rental_writepanel_js', 'PAC_ADMIN_DATA', $params);
        }
    }
}


new Pac_Enqueue_Files();