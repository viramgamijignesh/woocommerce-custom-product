<?php

/**
 * Plugin Name: NetScore Rental Products 
 * Description: The NetScore Product Rental plugin can be used to create a rental store along  with custom security deposit feature for every individual product.
 * Version: 1.0
 * Author:NetScore
 * WC requires at least: 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * NetS_Rental_And_Bookings
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    class NetS_Rental_And_Bookings
    {
        /**
         * Plugin data from get_plugins()
         *
         * @since 1.0
         * @var object
         */
        public $plugin_data;

        /**
         * Includes to load
         *
         * @since 1.0
         * @var array
         */
        public $includes;

        /**
         * Plugin Action and Filter Hooks
         *
         * @return null
         * @since 1.0.0
         */
        public function __construct()
        {
            register_activation_hook(__FILE__, array(&$this, 'pac_init_custom_db_table'));
            add_action('after_setup_theme', array($this, 'pac_include_template_functions'), 11);
            add_action('plugins_loaded', array($this, 'nets_rental_set_plugins_data'), 1);
            add_action('plugins_loaded', array($this, 'nets_rental_define_constants'), 1);
            add_action('plugins_loaded', array($this, 'nets_rental_set_includes'), 1);
            add_action('plugins_loaded', array($this, 'nets_rental_load_includes'), 1);
            add_action('woocommerce_nets_rental_add_to_cart', array($this, 'nets_add_to_cart'), 30);
            add_filter('woocommerce_integrations', array($this, 'nets_rental_include_integration'));
            add_filter('woocommerce_get_settings_pages', array($this, 'nets_rental_get_settings_pages'));
            add_action('plugins_loaded', array($this, 'nets_support_multilanguages'));

            $quote_menu = get_option('pac_enable_rft_endpoint', 'yes');

            if ($quote_menu == 'yes') {
                add_action('init', array($this, 'request_quote_endpoints'));
            }
            add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'nets_more_plugins_links'), 1);
        }

        /**
         * pac_init_custom_db_table
         *
         * @return void
         */
        public function pac_init_custom_db_table()
        {
            global $wpdb;

            $wpdb->hide_errors();

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';

            $collate = '';

            if ($wpdb->has_cap('collation')) {
                $collate = $wpdb->get_charset_collate();
            }

            $schema = "CREATE TABLE {$wpdb->prefix}pac_availability (
                id BIGINT UNSIGNED NOT NULL auto_increment,
                pickup_datetime timestamp NULL,
                return_datetime timestamp NULL,
                rental_duration varchar(200) NULL,
                product_id BIGINT UNSIGNED NULL,
                inventory_id BIGINT UNSIGNED NULL,
                order_id BIGINT UNSIGNED NULL,
                item_id BIGINT UNSIGNED NULL,
                lang varchar(200) NOT NULL DEFAULT 'en',
                created_at timestamp NOT NULL DEFAULT 0,
                updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                block_by ENUM('FRONTEND_ORDER', 'BACKEND_ORDER', 'CUSTOM') NOT NULL DEFAULT 'CUSTOM',
                delete_status boolean DEFAULT 0 NOT NULL,
                PRIMARY KEY (id)
                        ) $collate;
                CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pac_inventory_product (
                    inventory BIGINT UNSIGNED NOT NULL,
                    product BIGINT UNSIGNED NOT NULL,
                    KEY inventory (inventory),
                    KEY product (product)) $collate;";

            dbDelta($schema);
        }

        /**
         * nets_more_plugins_links
         *
         * @param array $links
         *
         * @return array
         */
        public function nets_more_plugins_links($links)
        {
         
           return $links;
        }


        public function nets_rental_set_plugins_data()
        {
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $plugin_dir = plugin_basename(dirname(__FILE__));
            $plugin_data = current(get_plugins('/' . $plugin_dir));
            $this->plugin_data = apply_filters('nets_plugin_data', $plugin_data);
        }


        /**
         * Plugin constant define
         *
         * @return null
         * @since 1.0.0
         */
        public function nets_rental_define_constants()
        {
            define('NETS_RENTAL_VERSION', $this->plugin_data['Version']);                    // plugin version
            define('NETS_RENTAL_FILE', __FILE__);                                            // plugin's main file path
            define('NETS_RENTAL_DIR', dirname(plugin_basename(NETS_RENTAL_FILE)));            // plugin's directory
            define('NETS_RENTAL_PATH', untrailingslashit(plugin_dir_path(NETS_RENTAL_FILE)));    // plugin's directory path
            define('NETS_RENTAL_URL', untrailingslashit(plugin_dir_url(NETS_RENTAL_FILE)));    // plugin's directory URL

            define('NETS_RENTAL_INC_DIR', 'includes');    // includes directory
            define('NETS_RENTAL_ASSETS_DIR', 'assets');        // assets directory
            define('NETS_RENTAL_LANG_DIR', 'languages');    // languages directory
            define('NETS_ROOT_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
            define('NETS_PACKAGE_TEMPLATE_PATH', untrailingslashit(plugin_dir_path(__FILE__)) . '/templates/');
        }


        /**
         * Plugin includes files
         *
         * @return null
         * @since 1.0.0
         */
        public function nets_rental_set_includes()
        {
            $this->includes = apply_filters('nets_rental', array(
                'admin' => array(
                    NETS_RENTAL_INC_DIR . '/admin/class-nets-rental-meta-boxes.php',
                    NETS_RENTAL_INC_DIR . '/admin/class-nets-rental-admin-page.php',
                    NETS_RENTAL_INC_DIR . '/integrations/class-full-calendar-integration.php',
                ),
                'frontends' => array(
                    NETS_RENTAL_INC_DIR . '/class-nets-product-nets_rental.php',
                    NETS_RENTAL_INC_DIR . '/class-nets-product-cart.php',
                    NETS_RENTAL_INC_DIR . '/class-nets-product-tabs.php',
                )
            ));
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/class-nets-plugin-color-control.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-nets-rental-post-types.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-pac-term-meta-text.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-pac-term-meta-icon.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-pac-term-meta-image.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-pac-term-meta-select.php';

            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/admin/class-save-meta.php';

            include_once('includes/pac-data-provider.php');
            include_once('includes/pac-arrange-data.php');
            include_once('includes/pac-template-hooks.php');
            include_once('includes/pac-core-functions.php');
            include_once('includes/class-nets-rental-orders.php');

            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/nets-quote-functions.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/class-nets-request-for-a-quote.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/class-nets-email.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/class-nets-enqueue-files.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/nets-rental-global-functions.php';
            require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/integrations/class-google-calendar-integration.php';


            if (in_array('reactive/reactive.php', apply_filters('active_plugins', get_option('active_plugins')))) {
                require_once trailingslashit(NETS_RENTAL_PATH) . NETS_RENTAL_INC_DIR . '/class-reactive-support.php';
            }
        }


        /**
         * Function used to Init WooCommerce Template Functions - This makes them pluggable by plugins and themes.
         */
        public function pac_include_template_functions()
        {
            include_once('includes/pac-template-functions.php');
        }


        /**
         * Plugin includes files
         *
         * @return null
         * @since 1.0.0
         */
        public function nets_rental_load_includes()
        {
            $includes = $this->includes;

            foreach ($includes as $condition => $files) {
                $do_includes = false;
                switch ($condition) {
                    case 'admin':
                        if (is_admin()) {
                            $do_includes = true;
                        }
                        break;
                    case 'frontend':
                        if (!is_admin()) {
                            $do_includes = true;
                        }
                        break;
                    default:
                        $do_includes = true;
                        break;
                }

                if ($do_includes) {
                    foreach ($files as $file) {
                        require_once trailingslashit(NETS_RENTAL_PATH) . $file;
                    }
                }
            }
        }


        /**
         * Manage all Block Times
         *
         * @return object
         * @since 1.0.0
         */
        public function manage_all_times($date, $start_time, $end_time, $step = 5)
        {
            $times = array();
            $block_times = array();

            $start_exp = explode(':', $start_time);
            $end_exp = explode(':', $end_time);

            $start_hour = $start_exp[0];
            $start_min = $start_exp[1];
            $end_hour = $end_exp[0];
            $end_min = $end_exp[1];


            for ($hour = $start_hour; $hour <= $end_hour; $hour++) {
                for ($minute = $start_min; $minute <= 60; $minute = $minute + 5) {
                    $com = $hour . ':' . $minute;
                    array_push($times, $com);
                }
            }

            $block_times[$date] = $times;

            return $block_times;
        }


        /**
         * Add to cart page show in fornt-end
         *
         * @return null
         * @since 1.0.0
         */
        public function nets_add_to_cart()
        {
            wc_get_template('single-product/add-to-cart/nets_rental.php', $args = array(), $template_path = '', NETS_PACKAGE_TEMPLATE_PATH);
        }


        /**
         * Support lagnuages for inventory
         *
         * @return null
         * @since 1.0.0
         */
        public function nets_support_multilanguages()
        {
            load_plugin_textdomain('nets-rental', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }

        /**
         * RFQ Endpoint
         *
         * @return null
         * @since 3.0.0
         */
        public static function request_quote_endpoints()
        {
            add_rewrite_endpoint('request-quote', EP_ROOT | EP_PAGES);
            add_rewrite_endpoint('view-quote', EP_ALL);
        }

        /**
         * RFQ Status
         *
         * @return null
         * @since 3.0.0
         */
        public static function register_post_status()
        {
            $quote_statuses = apply_filters(
                'nets_register_request_quote_post_statuses',
                array(
                    'quote-pending' => array(
                        'label' => _x('Pending', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('Pending <span class="count">(%s)</span>', 'Pending <span class="count">(%s)</span>', 'nets-rental')
                    ),
                    'quote-processing' => array(
                        'label' => _x('Processing', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('Processing <span class="count">(%s)</span>', 'Processing <span class="count">(%s)</span>', 'nets-rental')
                    ),
                    'quote-on-hold' => array(
                        'label' => _x('On Hold', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('On Hold <span class="count">(%s)</span>', 'On Hold <span class="count">(%s)</span>', 'nets-rental')
                    ),
                    'quote-accepted' => array(
                        'label' => _x('Accepted', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('Accepted <span class="count">(%s)</span>', 'Accepted <span class="count">(%s)</span>', 'nets-rental')
                    ),
                    'quote-completed' => array(
                        'label' => _x('Completed', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('Completed <span class="count">(%s)</span>', 'Completed <span class="count">(%s)</span>', 'nets-rental')
                    ),
                    'quote-cancelled' => array(
                        'label' => _x('Cancelled', 'Quote status', 'nets-rental'),
                        'public' => false,
                        'protected' => true,
                        'exclude_from_search' => false,
                        'show_in_admin_all_list' => true,
                        'show_in_admin_status_list' => true,
                        'label_count' => _n_noop('Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', 'nets-rental')
                    ),
                )
            );

            foreach ($quote_statuses as $quote_status => $values) {
                register_post_status($quote_status, $values);
            }
        }

        /**
         * Add integrations
         * This add the Google Calendar integration
         */
        public function nets_rental_include_integration($integrations)
        {
            $integrations[] = 'Nets_Rental_Google_Calendar_Integration';

            return $integrations;
        }

        /**
         * Add integrations
         * This add the Google Calendar integration
         */
        public function nets_rental_get_settings_pages($settings)
        {
            $settings[] = include('includes/admin/class-nets-rental-settings-pac.php');
            return $settings;
        }
    }

    new NetS_Rental_And_Bookings();

    register_deactivation_hook(__FILE__, 'flush_rewrite_rules');
    register_activation_hook(__FILE__, 'nets_rental_flush_rewrites');

    function nets_rental_flush_rewrites()
    {
        NetS_Rental_And_Bookings::request_quote_endpoints();
        NetS_Rental_And_Bookings::register_post_status();
        flush_rewrite_rules();
    }
} else {
    function nets_admin_notice()
    {
?>
        <div class="error">
            <p><?php _e('Please Install WooCommerce First before activating this Plugin. You can download WooCommerce from <a href="http://wordpress.org/plugins/woocommerce/">here</a>.', 'nets-rental'); ?></p>
        </div>
<?php
    }

    add_action('admin_notices', 'nets_admin_notice');
}


 function catalogue_page_display_calendar() {
  global $product;
     $idproduct=$product->id;
     $producttype=$product->get_type();
     $producturl = $product->get_permalink();
   
      $labels = nets_rental_get_settings(get_the_ID(), 'labels', array('pickup_date'));
    $displays = nets_rental_get_settings(get_the_ID(), 'display');
    $labels = $labels['labels'];
    $displays = $displays['display'];

    if($producttype == "nets_rental") {

?>
        <span class="pick-up-date-picker">
            <i class="fa fa-calendar"></i>
     
           <a href="<?=$producturl; ?>" id="pickup_date" class="inlineDatepicker" style="color:#0E8EAB;">Availability Calendar</a>   
        </span>
  
 <?php }
  
    echo '<br>';
}


add_action( 'woocommerce_after_shop_loop_item_title', 'catalogue_page_display_calendar', 9 );
