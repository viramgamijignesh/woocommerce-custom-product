<?php

/**
 * Nets rental product add to cart
 *
 * @author      netsteam
 * @package     NetsTeam/Templates
 * @version     1.0.0
 * @since       1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

global $product;
$product_id = $product->get_id();

$nets_product_inventory = pac_get_product_inventory_id($product_id);

if (empty($nets_product_inventory)) {
    return;
}

$inventories = get_posts(array(
    'post_type'      => 'inventory',
    'post__in'       => $nets_product_inventory,
    'posts_per_page' => -1,
    'orderby' => 'post__in',
));

foreach ($inventories as $index => $inventory) {
    $inventories[$index]->quantity = get_post_meta($inventory->ID, 'quantity', true);
}

$labels = nets_rental_get_settings(get_the_ID(), 'labels', array('inventory'));
$labels = $labels['labels'];
?>

<div class="payable-inventory pac-component-wrapper pac-select-wrapper" <?php echo (count($inventories) < 2) ? 'style="display:none"' : ''; ?>>
    <h5><?php echo esc_attr($labels['inventory']); ?></h5>
    <select class="nets-select-boxes pac-select-box" id="booking_inventory" name="booking_inventory" data-post-id="<?php echo $product_id ?>">
        <?php foreach ($inventories as $inventory) : ?>
            <option value="<?php echo $inventory->ID ?>"><?php echo $inventory->post_title ?></option>
        <?php endforeach; ?>
    </select>
</div>