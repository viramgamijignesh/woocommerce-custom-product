<div id="pickupLocationPreview" class="nets-pick-up-location pac-select-wrapper pac-component-wrapper"></div>

<script type="text/html" id="pickupLocationBuilder">
    <% if(items.length){ %>
    <div class="nets-pick-up-location pac-select-wrapper pac-component-wrapper">
        <h5><%= title %></h5>
        <select class="nets-select-boxes pickup_location pac-select-box" name="pickup_location">
            <option value=""><%= placeholder %></option>
            <% _.each(items, function(item, index) { %>
            <option value="<%= item.id %>"><%= item.title %></option>
            <% }) %>
        </select>
    </div>
    <% } %>
</script>