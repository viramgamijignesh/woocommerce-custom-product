<div id="resourcePreview"></div>

<script type="text/html" id="resourceBuilder">
    <% if(items.length){ %>
    <div class="payable-extras pac-component-wrapper">
        <h5><%= title %></h5>
        <% _.each(items, function(item, index) { %>
        <div class="attributes">
            <label class="custom-block">
                <input type="checkbox" name="extras[]" value="<%= item.id %>" class="carrental_extras">
                <%= item.resource_name %> <%= item.extra_meta %>
            </label>
        </div>
        <% }) %>
    </div>
    <% } %>
</script>