<div id="dropoffLocationPreview"></div>

<script type="text/html" id="dropoffLocationBuilder">
    <% if(items.length){ %>
    <div class="nets-pick-up-location pac-select-wrapper pac-component-wrapper">
        <h5><%= title %></h5>
        <select class="nets-select-boxes dropoff_location pac-select-box" name="dropoff_location">
            <option value=""><%= placeholder %></option>
            <% _.each(items, function(item, index) { %>
            <option value="<%= item.id %>"><%= item.title %></option>
            <% }) %>
        </select>
    </div>
    <% } %>
</script>