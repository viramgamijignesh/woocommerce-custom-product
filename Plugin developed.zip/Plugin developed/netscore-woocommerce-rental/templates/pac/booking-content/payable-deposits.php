<div id="depositPreview"></div>

<script type="text/html" id="depositBuilder">
    <% if(items.length){ %>
    <div class="payable-security_deposites pac-component-wrapper">
        <h5><%= title %></h5>
        <% _.each(items, function(item, index) { %>
        <div class="attributes">
            <label class="custom-block">
                <input type="checkbox" name="security_deposites[]" value="<%= item.id %>" class="carrental_extras" <% if(item.security_deposite_clickable === 'no'){ %> checked readonly onclick="return false" <% } %> />
                <%= item.security_deposite_name %> <%= item.extra_meta %>
            </label>
        </div> <% }) %>
    </div> <% } %>
</script>