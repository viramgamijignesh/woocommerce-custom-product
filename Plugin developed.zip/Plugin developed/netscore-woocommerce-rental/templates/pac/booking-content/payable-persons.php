<div id="adultPreview"></div>

<script type="text/html" id="adultBuilder">
    <% if(items.length){ %>
    <div class="additional-person additional-person-adult pac-select-wrapper pac-component-wrapper">
        <h5><%= title %></h5>
        <select class="additional_adults_info nets-select-boxes pac-select-box" name="additional_adults_info">
            <option value=""><%= placeholder %></option>
            <% _.each(items, function(item, index) { %>
            <option value="<%= item.id %>"><%= item.person_count %> - <%= item.person_cost %> (<%= item.person_cost_applicable %>) </option>
            <% }) %>
        </select>
    </div>
    <% } %>
</script>

<div id="childPreview"></div>

<script type="text/html" id="childBuilder">
    <% if(items.length){ %>
    <div class="additional-person additional-person-child pac-select-wrapper pac-component-wrapper">
        <h5><%= title %></h5>
        <select class="additional_childs_info nets-select-boxes pac-select-box" name="additional_childs_info">
            <option value=""><%= placeholder %></option>
            <% _.each(items, function(item, index) { %>
            <option value="<%= item.id %>"><%= item.person_count %> - <%= item.person_cost %> (<%= item.person_cost_applicable %>) </option>
            <% }) %>
        </select>
    </div>
    <% } %>
</script>