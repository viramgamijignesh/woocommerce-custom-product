<table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" valign="top">
        <center style="display:inline-block;">

          <table width="100%" style="background:#FFFFFF;">
            <tr>
              <td align="center">
                <center style="padding:0 0 50px 0;">

                  <table>
                    <tr>
                      <td>

                        <table>
                          
                          <tr>
                            <td style="text-align:center;color:#777777;">
                              PaC Quote Request - Powered by NetS Team
                              <?php
                                // $footer_text = str_ireplace('{site_title}', get_bloginfo( 'name' ), $email_settings['emailFooterText']);

                                // echo $footer_text;
                              ?>
                            </td>
                          </tr>
                        </table>

                      </td>
                    </tr>
                  </table>

                </center>
              </td>
            </tr>
          </table>

        </center>
      </td>
    </tr>
  </table>
</body>
</html>