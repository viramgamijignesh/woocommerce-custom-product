<?php
global $product;
$product_id = $product->get_id();
$nets_product_inventory = pac_get_product_inventory_id($product_id);

$displays = nets_rental_get_settings($product_id, 'display');
$displays = $displays['display'];
$labels = nets_rental_get_settings($product_id, 'labels', array('price_info'));
$labels = $labels['labels'];

?>

<?php if (isset($displays['flip_box']) && $displays['flip_box'] !== 'closed') : ?>
    <div class="pac-pricing-plan-button">
        <span class="pac-pricing-plan">
            <a href="#" class="pac-pricing-plan-link">
                <i class="fa fa-hand-pointer-o"></i> &nbsp;
                <?php echo esc_attr($labels['flipbox_info']); ?>
            </a>
        </span>
    </div>
<?php endif; ?>
<?php
foreach ($nets_product_inventory as $inventory) :
    $pricing_type = get_post_meta($inventory, 'pricing_type', true);
    if (isset($displays['flip_box']) && $displays['flip_box'] !== 'closed') :
        global $product;

        $pricing_data = nets_rental_get_pricing_data($inventory);
        $price_info_top = get_option('pac_flipbox_price_top_info', 'yes');
        $flip_box = $price_info_top && $price_info_top === 'yes' ? ['back', 'front'] : ['front', 'back'];
?>
        <div class="price-showing">
            <div class="<?php echo esc_attr($flip_box[1]); ?>">
                <div class="item-pricing">
                    
                    <?php if ($pricing_data['pricing_type'] === 'general_pricing') : ?>
                        <h5> <?php echo esc_html__('General pricing : ', 'nets-rental'); ?><?php echo get_the_title($inventory); ?></h5>
                        <?php $general_price = $pricing_data['general_pricing']; ?>
                        <div class="pac-pricing-wrap">
                            <div class="day-ranges-pricing-plan">
                                <span class="range-days"> <?php echo wc_price($general_price); ?><?php _e(' / day :', 'nets-rental'); ?> </span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($pricing_data['pricing_type'] === 'days_range') : ?>
                        <?php $pricing_plans = $pricing_data['days_range']; ?>
                        <div class="pac-pricing-wrap">
                            <?php if (is_array($pricing_plans) && !empty($pricing_plans)) { ?>
                                <?php foreach ($pricing_plans as $key => $value) { ?>
                                    <?php $rate = $value['cost_applicable'] === 'fixed' ? esc_html__('Fixed', 'nets-rental') : esc_html__('/ Day', 'nets-rental'); ?>
                                    <div class="day-ranges-pricing-plan">
                                        <span class="range-days"><?php echo esc_attr($value['min_days']); ?> - <?php echo esc_attr($value['max_days']); ?> <?php _e('days :', 'nets-rental'); ?> </span>
                                        <span class="range-price"><strong><?php echo wc_price($value['range_cost']); ?></strong> <?php echo esc_attr($rate); ?></span>
                                    </div>
                            <?php }
                            } ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($pricing_data['pricing_type'] === 'daily_pricing') : ?>
                        <?php
                        $daily_pricing = $pricing_data['daily_pricing'];
                        $day_names = nets_rental_day_names();
                        ?>
                        <div class="pac-pricing-wrap">
                            <?php if (is_array($daily_pricing) && !empty($daily_pricing)) { ?>
                                <?php foreach ($daily_pricing as $key => $value) { ?>
                                    <div class="day-ranges-pricing-plan">
                                        <span class="day"><?php echo esc_attr(ucfirst($day_names[$key])); ?> </span>
                                        <span class="day-price"><strong> - <?php echo wc_price($value); ?></strong></span>
                                    </div>
                            <?php }
                            } ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($pricing_data['pricing_type'] === 'monthly_pricing') : ?>
                        <?php
                        $monthly_pricing = $pricing_data['monthly_pricing'];
                        $month_names = nets_rental_month_names();
                        ?>
                        <div class="pac-pricing-wrap">
                            <?php if (is_array($monthly_pricing) && !empty($monthly_pricing)) { ?>
                                <?php foreach ($monthly_pricing as $key => $value) { ?>
                                    <div class="day-ranges-pricing-plan">
                                        <span class="month"><?php echo ucfirst($month_names[$key]); ?> </span>
                                        <span class="month-price"><strong> - <?php echo wc_price($value); ?></strong></span>
                                    </div>
                            <?php }
                            } ?>
                        </div>
                    <?php endif; ?>

                    <?php
                    if ($pricing_data['hourly_pricing_type'] === 'hourly_range') :
                        $pricing_plans = $pricing_data['hourly_range'];
                        if (is_array($pricing_plans) && !empty($pricing_plans)) : ?>
                            <h5><?php echo esc_html__('Hourly based pricing', 'nets-rental'); ?></h5>
                            <div class="pac-pricing-wrap">
                                <?php foreach ($pricing_plans as $key => $value) : ?>
                                    <?php $rate = $value['cost_applicable'] === 'fixed' ? esc_html__('Fixed', 'nets-rental') : esc_html__('/ Hour', 'nets-rental'); ?>
                                    <div class="day-ranges-pricing-plan">
                                        <span class="range-days"><?php echo esc_attr($value['min_hours']); ?> - <?php echo esc_attr($value['max_hours']); ?> <?php _e('Hours :', 'nets-rental'); ?> </span>
                                        <span class="range-price"><strong><?php echo wc_price($value['range_cost']); ?></strong> <?php echo esc_attr($rate); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                    <?php
                        endif;
                    endif;
                    ?>

                    <?php if ($pricing_data['hourly_pricing_type'] === 'hourly_general') : ?>
                        <?php $general_hourly_price = $pricing_data['hourly_general']; ?>
                        <?php if (!empty($general_hourly_price)) : ?>
                            <h5><?php echo esc_html__('Hourly based pricing', 'nets-rental'); ?></h5>
                            <p class="hourly-general"><?php echo wc_price($general_hourly_price); ?>
                                / <?php echo esc_html__('per hour', 'nets-rental'); ?>
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <?php if (isset($displays['discount']) && $displays['discount'] !== 'closed') : ?>
                    <div class="pac-discount-wrap">
                        <div class="discount-portion">
                            <?php $price_discounts = $pricing_data['price_discount']; ?>
                            <?php if (isset($price_discounts) && !empty($price_discounts)) : ?>
                                <h5><?php echo esc_html__('Discount Rates', 'nets-rental'); ?></h5>
                                <?php foreach ($price_discounts as $key => $value) { ?>
                                    <?php
                                    if ($value['discount_type'] === 'percentage') {
                                        $rate = esc_html__('%', 'nets-rental');
                                        $amount = $value['discount_amount'];
                                    } else {
                                        $rate = esc_html__('Fixed', 'nets-rental');
                                        $amount = wc_price($value['discount_amount']);
                                    }
                                    ?>
                                    <div class="discount-plan">
                                        <span class="range-days"><?php echo esc_attr($value['min_days']); ?> - <?php echo esc_attr($value['max_days']); ?> <?php _e('days :', 'nets-rental'); ?> </span>
                                        <span class="range-price"><strong><?php echo $amount; ?></strong> <?php echo esc_attr($rate); ?></span>
                                    </div>
                                <?php } ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
<?php endif;
endforeach;
