<?php
/**
 * Nets rental product add to cart
 *
 * @author      netsteam
 * @package     NetsTeam/Templates
 * @version     1.0.0
 * @since       1.0.0
 */

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $product;
$product_id = $product->get_ID();

$displays = nets_rental_get_settings($product_id, 'display');
$conditional_data = nets_rental_get_settings($product_id, 'conditions');
$conditional_data = $conditional_data['conditions'];
$displays = $displays['display'];

/**
 * pac_before_add_to_cart_form hook.
 *
 * @hooked pac_price_flip_box - 10
 */
do_action('pac_before_add_to_cart_form');

?>
<form class="cart pac-cart" method="post" enctype='multipart/form-data' novalidate>
    <?php

        if ($conditional_data['booking_layout'] === 'layout_one') :
            /**
             * pac_before_add_to_cart_form hook.
             *
             * @hooked pac_price_flip_box - 10
             * @hooked pac_pickup_locations - 10
             * @hooked pac_return_locations - 10
             * @hooked pac_pickup_datetimes - 10
             * @hooked pac_payable_resources - 10
             * @hooked pac_payable_persons - 10
             * @hooked pac_payable_deposits - 10
             */
            do_action('pac_main_rental_content');
        endif;

        /**
         * woocommerce_before_add_to_cart_button hook.
         *
         */
        do_action('woocommerce_before_add_to_cart_button');
    ?>

    <input type="hidden" name="currency-symbol" class="currency-symbol" value="<?php echo get_woocommerce_currency_symbol(); ?>">
    <input type="hidden" class="product_id" name="add-to-cart" value="<?php echo esc_attr($product_id); ?>" />
    <input type="hidden" class="quote_price" name="quote_price" value="" />

    <?php
        if ($conditional_data['booking_layout'] === 'layout_one') :
            /**
             * pac_plain_booking_button hook.
             *
             * @hooked pac_direct_booking - 10
             * @hooked pac_request_quote - 20
             */
            do_action('pac_plain_booking_button');
        else :
            /**
             * pac_modal_booking hook.
             *
             * @hooked pac_modal_booking - 10
             */
            do_action('pac_modal_booking');
        endif;

        /**
         * woocommerce_after_add_to_cart_button hook.
         *
         */
        do_action('woocommerce_after_add_to_cart_button');
    ?>
</form>

<?php do_action('woocommerce_after_add_to_cart_form'); ?>
