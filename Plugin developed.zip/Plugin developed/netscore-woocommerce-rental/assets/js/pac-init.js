var PAC_HELPER = {};
jQuery(document).ready(function($) {
  const bookNowButtonSelector = $('.nets_add_to_cart_button');
  const rfqButtonSelector = $('.nets_request_for_a_quote');
  loadingEffect = selector => {
    $(selector).block({
      message: null,
      overlayCSS: {
        background: '#fff',
        opacity: 0.8,
      },
    });
  };

  unLoadingEffect = selector => {
    $(selector).unblock();
  };

  shouldFireAjax = dataObj => {
    const ajaxPreload = [];
    let fireAjax = false;

    if ($('#pickup-date').length > 0) {
      ajaxPreload.push('pickup_date');
    }
    if ($('#dropoff-date').length > 0) {
      ajaxPreload.push('dropoff_date');
    }

    if ($('#pickup-time').length > 0) {
      ajaxPreload.push('pickup_time');
    }
    if ($('#dropoff-time').length > 0) {
      ajaxPreload.push('dropoff_time');
    }

    const checkPreload = ajaxPreload.map(value => {
      return dataObj[value] !== '';
    });

    fireAjax = checkPreload.includes(false);

    return !fireAjax;
  };

  resetFields = () => {
    $('.pac-error-message').remove();

    $('.inventory-qty').val(1);
    $('#pickup-date').val('');
    $('#pickup-time').val('');
    $('#dropoff-date').val('');
    $('#dropoff-time').val('');
    $('.booking-pricing-info').hide();
  };

  pacProcessFormData = self => {
    const formData = self.serializeArray();
    const dataObj = {};
    $(formData).each(function(i, field) {
      if (field.name.endsWith('[]')) {
        const name = field.name.substring(0, field.name.length - 2);
        if (!(name in dataObj)) {
          dataObj[name] = [];
        }
        if ($.inArray(field.value, dataObj[name]) === -1) {
          dataObj[name].push(field.value);
        }
      } else {
        dataObj[field.name] = field.value;
      }
    });
    return dataObj;
  };

  pacHandleErrorAction = () => {
    $('.date-error-message').show();
    $('.nets_add_to_cart_button').attr('disabled', 'disabled');
    $('.nets_request_for_a_quote').attr('disabled', 'disabled');
    // $('#pacSmartwizard .actions ul li')
    //   .addClass('disabled disabledNextOnModal')
    //   .attr('aria-disabled', 'true');
  };

  pacHandleError = response => {
    $('.pac-error-message').remove();
    pacHandleSuccessAction();
    if (response.error && response.error.length) {
      $('.booking-pricing-info').hide();
      const errors = response.error
        .map(err => {
          return '<li>' + err + '</li>';
        })
        .join('');
      const errorMessage = `<ul class="pac-error-message">${errors}</ul>`;

      if (bookNowButtonSelector.length) {
        bookNowButtonSelector.before(errorMessage);
      } else {
        rfqButtonSelector.before(errorMessage);
      }

      $('html, body').animate(
        {
          scrollTop: $('.pac-cart').offset().top,
        },
        'slow'
      );

      PAC_HELPER.pacHandleErrorAction();
    }
  };

  pacHandleSuccessAction = () => {
    $('.date-error-message').hide();
    $('.nets_add_to_cart_button').removeAttr('disabled', 'disabled');
    $('.nets_request_for_a_quote').removeAttr('disabled', 'disabled');
    $('#pacSmartwizard .actions ul li')
      .removeClass('disabled disabledNextOnModal')
      .addClass('proceedOnModal')
      .attr('aria-disabled', 'false');
  };

  handleProductUnitPrice = data => {
    $(`.pac_price_unit_${data.product_id}`).html(data.unit_price);
  };

  PAC_HELPER = {
    loadingEffect,
    unLoadingEffect,
    shouldFireAjax,
    resetFields,
    pacProcessFormData,
    pacHandleErrorAction,
    pacHandleError,
    pacHandleSuccessAction,
    handleProductUnitPrice,
  };
});
