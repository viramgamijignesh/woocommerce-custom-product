var PAC_TEMPLATES = {};
jQuery(document).ready(function($) {
  initChosen = () => {
    $('.nets-select-boxes').chosen();
  };

  /**
   * pickupLocation
   *
   * @param location
   */
  pickupLocation = location => {
    const builderTemplate = _.template($('#pickupLocationBuilder').html())({
      items: location.data,
      title: location.title,
      placeholder: location.placeholder,
    });
    $('#pickupLocationPreview').html(builderTemplate);
    $('.nets-select-boxes').chosen();
  };

  /**
   * dropoffLocation
   *
   * @param location
   */
  dropoffLocation = location => {
    const builderTemplate = _.template($('#dropoffLocationBuilder').html())({
      items: location.data,
      title: location.title,
      placeholder: location.placeholder,
    });
    $('#dropoffLocationPreview').html(builderTemplate);
    $('.nets-select-boxes').chosen();
  };

  /**
   * Resource
   *
   * @param resource
   * @param resourceContainerClass
   */
  resource = resource => {
    const builderTemplate = _.template($('#resourceBuilder').html())({
      items: resource.data,
      title: resource.title,
    });
    $('#resourcePreview').html(builderTemplate);
  };

  /**
   * resourceModal
   *
   * @param resource
   */
  resourceModal = resource => {
    if (!resource.data.length) return;
    const builderTemplate = _.template($('#resourceModalBuilder').html())({
      items: resource.data,
      title: resource.title,
    });
    $('#resourceModalPreview').html(builderTemplate);
  };

  /**
   * category
   *
   * @param category
   * @param containerClass
   */
  category = category => {
    const builderTemplate = _.template($('#categoryBuilder').html())({
      items: category.data,
      title: category.title,
    });
    $('#categoryPreview').html(builderTemplate);
  };

  /**
   * adults
   *
   * @param person
   */
  adults = adult => {
    const builderTemplate = _.template($('#adultBuilder').html())({
      items: adult.data,
      title: adult.title,
      placeholder: adult.placeholder,
    });
    $('#adultPreview').html(builderTemplate);
    $('.nets-select-boxes').chosen();
  };

  /**
   * adultModal
   *
   * @param adult
   */
  adultModal = adult => {
    if (!adult.data.length) return;
    const builderTemplate = _.template($('#adultModalBuilder').html())({
      items: adult.data,
      title: adult.title,
      placeholder: adult.placeholder,
    });
    $('#adultModalPreview').html(builderTemplate);
  };

  /**
   * childs
   *
   * @param person
   */
  childs = child => {
    const builderTemplate = _.template($('#childBuilder').html())({
      items: child.data,
      title: child.title,
      placeholder: child.placeholder,
    });
    $('#childPreview').html(builderTemplate);
    $('.nets-select-boxes').chosen();
  };

  /**
   * childModal
   *
   * @param child
   */
  childModal = child => {
    if (!child.data.length) return;
    const builderTemplate = _.template($('#childModalBuilder').html())({
      items: child.data,
      title: child.title,
      placeholder: child.placeholder,
    });
    $('#childModalPreview').html(builderTemplate);
  };

  /**
   * displayDeposit
   *
   * @param deposit
   */
  deposit = deposit => {
    const builderTemplate = _.template($('#depositBuilder').html())({
      items: deposit.data,
      title: deposit.title,
    });
    $('#depositPreview').html(builderTemplate);
  };

  /**
   * depositModal
   *
   * @param deposits
   */
  depositModal = deposit => {
    if (!deposit.data.length) return;

    const builderTemplate = _.template($('#depositModalBuilder').html())({
      items: deposit.data,
      title: deposit.title,
    });
    $('#depositModalPreview').html(builderTemplate);
  };

  PAC_TEMPLATES = {
    initChosen,
    pickupLocation,
    dropoffLocation,
    resource,
    resourceModal,
    category,
    adults,
    childs,
    adultModal,
    childModal,
    deposit,
    depositModal,
  };
});
