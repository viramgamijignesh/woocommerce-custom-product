jQuery(document).ready(function($) {
  const bookNowButtonSelector = $('.nets_add_to_cart_button');
  const rfqButtonSelector = $('.nets_request_for_a_quote');

  bookNowButtonSelector.attr('disabled', 'disabled');
  rfqButtonSelector.attr('disabled', 'disabled');

  const productSettings = CALENDAR_DATA.calendar_props.settings;
  const validation_data = CALENDAR_DATA.calendar_props.settings.validations;

  const ajaxUrl = CALENDAR_DATA.ajax_url;
  let layout_two_labels = productSettings.layout_two_labels;

  if (productSettings.conditions.booking_layout === 'layout_one') {
    handleNormalLayoutTemplates(CALENDAR_DATA);
  } else {
    handleModalLayoutTemplates(CALENDAR_DATA);
  }

  function handleNormalLayoutTemplates(response) {
    PAC_TEMPLATES.pickupLocation(response.pick_up_locations);
    PAC_TEMPLATES.dropoffLocation(response.return_locations);
    PAC_TEMPLATES.resource(response.resources);
    PAC_TEMPLATES.category(response.categories);
    PAC_TEMPLATES.adults(response.adults);
    PAC_TEMPLATES.childs(response.childs);
    PAC_TEMPLATES.deposit(response.deposits);
  }

  function handleModalLayoutTemplates(response) {
    PAC_TEMPLATES.resourceModal(response.resources);
    PAC_TEMPLATES.adultModal(response.adults);
    PAC_TEMPLATES.childModal(response.childs);
    PAC_TEMPLATES.depositModal(response.deposits);
  }

  /**
   *inventorySwitching
   *
   * Fire when inventory changes
   */
  function inventorySwitching() {
    $('#booking_inventory').change(function() {
      const inventoryID = $(this).val();
      const postID = $(this).data('post-id');

      PAC_HELPER.loadingEffect('form.pac-cart');

      $.ajax({
        type: 'post',
        dataType: 'json',
        url: ajaxUrl,
        data: {
          action: 'pac_get_inventory_data',
          inventory_id: inventoryID,
          post_id: postID,
        },
        success: function(response) {
          PAC_HELPER.resetFields();
          PAC_HELPER.pacHandleErrorAction();

          BOOKING_DATA = response.booking_data;
          CALENDAR_DATA = response.calendar_data;

          PAC_HELPER.handleProductUnitPrice(BOOKING_DATA);

          PAC_CALENDER_ACTION.init(CALENDAR_DATA);
          pacCostHandle();

          const bookingLayout =
            BOOKING_DATA.pac_data.settings.conditions.booking_layout;

          if (bookingLayout !== 'layout_two') {
            handleNormalLayoutTemplates(response);
          }

          if (bookingLayout === 'layout_two') {
            handleModalLayoutTemplates(response);
          }

          PAC_HELPER.unLoadingEffect('form.pac-cart');
        },
      });
    });
  }

  /**
   * ModalLayout
   *
   * @type {jQuery|undefined}
   */
  function initModal() {
    const wizard = $('#pacSmartwizard').steps({
      stepsOrientation: 'vertical',
      headerTag: 'h3',
      bodyTag: 'section',
      transitionEffect: 'fade',
      enableFinishButton: true,
      autoFocus: true,
      onFinished: function(event, currentIndex) {
        event.preventDefault();
        PAC_HELPER.pacHandleSuccessAction();
        $('li.book-now').show();
      },
      onStepChanging: function(event, currentIndex, newIndex) {
        const pickupLocWrapper = $('.pac-pickup-location');
        const dropoffLocWrapper = $('.pac-dropoff-location');
        const pickupLocInput = $('input.pac-pickup-location');
        const dropoffLocInput = $('input.pac-dropoff-location');

        const tabName = $('li.current')
          .children('a')
          .children('span.tab-identifier')
          .data('id');

        switch (tabName) {
          case 'location':
            if (newIndex < currentIndex) {
              return true;
            }

            const pickupLoc = pickupLocWrapper.val();
            const dropoffLoc = dropoffLocWrapper.val();
            const pickupLatLng = pickupLocWrapper.attr('data-latlng');
            const dropoffLatLng = dropoffLocWrapper.attr('data-latlng');

            if (pickupLoc === '' || pickupLatLng === 'notset') {
              pickupLocInput.css('border', '1px solid red');
              return false;
            } else {
              pickupLocInput.css('border', 'none');
            }

            if (dropoffLoc === '' || dropoffLatLng === 'notset') {
              dropoffLocInput.css('border', '1px solid red');
              return false;
            } else {
              dropoffLocInput.css('border', 'none');
            }

            pickupLocInput.css('border', '1px solid #eee');
            dropoffLocInput.css('border', '1px solid #eee');

            return true;

          case 'person':
            if (newIndex < currentIndex) {
              return true;
            }

            if (validation_data.person !== 'open') {
              return true;
            }

            const isAdultSelected = $('.pac-adult-area').find('label.checked');
            const isChildSelected = $('.pac-child-area').find('label.checked');

            if (!isAdultSelected.length) {
              $('span.adultWarning').show();
              return false;
            } else {
              $('span.adultWarning').hide();
            }

            if (!isChildSelected.length) {
              $('span.childWarning').show();
              return false;
            } else {
              $('span.childWarning').hide();
            }

            return true;
          default:
            return true;
        }
      },

      onStepChanged: function(event, currentIndex, priorIndex) {
        const wrapperH3 = $('.title-wrapper h3');
        const wrapperP = $('.title-wrapper p');
        const wrapperBookNow = $('li.book-now');
        const nextBtnClass = $('#pacSmartwizard .actions ul li:nth-child(2)');

        const tabName = $('li.current')
          .children('a')
          .children('span.tab-identifier')
          .data('id');

        switch (tabName) {
          case 'inventory':
            wrapperH3.html(layout_two_labels.inventory.inventory_top_heading);
            wrapperP.html(layout_two_labels.inventory.inventory_top_desc);
            nextBtnClass.removeClass('disabledNextOnModal');
            wrapperBookNow.hide();
            return true;
          case 'location':
            wrapperH3.html(layout_two_labels.location.location_top_heading);
            wrapperP.html(layout_two_labels.location.location_top_desc);
            nextBtnClass.removeClass('disabledNextOnModal');
            wrapperBookNow.hide();
            return true;
          case 'duration':
            wrapperH3.html(layout_two_labels.datetime.date_top_heading);
            wrapperP.html(layout_two_labels.datetime.date_top_desc);
            nextBtnClass
              .addClass('disabled disabledNextOnModal')
              .attr('aria-disabled', 'true');
            $('.date-error-message').hide();

            wrapperBookNow.hide();
            return true;
          case 'resource':
            wrapperH3.html(layout_two_labels.resource.resource_top_heading);
            wrapperP.html(layout_two_labels.resource.resource_top_desc);
            wrapperBookNow.hide();
            return true;

          case 'person':
            wrapperH3.html(layout_two_labels.person.person_top_heading);
            wrapperP.html(layout_two_labels.person.person_top_desc);
            wrapperBookNow.hide();
            return true;
          case 'deposit':
            wrapperH3.html(layout_two_labels.deposit.deposit_top_heading);
            wrapperP.html(layout_two_labels.deposit.deposit_top_desc);
            wrapperBookNow.hide();
            return true;
          case 'summary':
            wrapperH3.html('Summary');
            wrapperP.html('Summary Desc');
            return true;
          default:
            return true;
        }
      },
      onInit: function(event, currentIndex) {
        PAC_CALENDER_ACTION.init(CALENDAR_DATA);

        const tabName = $('li.current')
          .children('a')
          .children('span.tab-identifier')
          .data('id');

        if (tabName === 'inventory') {
          const wrapperH3 = $('.title-wrapper h3');
          const wrapperP = $('.title-wrapper p');
          wrapperH3.html(layout_two_labels.inventory.inventory_top_heading);
          wrapperP.html(layout_two_labels.inventory.inventory_top_desc);
        }

        return true;
      },
      labels: {
        cancel: 'Cancel',
        current: 'current step:',
        pagination: 'Pagination',
        finish: 'Finish Process',
        next: 'Next',
        previous: 'Previous',
        loading: 'Loading ...',
      },
    });
  }

  function pacCostHandle() {
    $('.show_if_time').hide();
    $('.nets-quantity').hide();

    $('form.cart').on('change', function(event) {
      $('.nets_add_to_cart_button').attr('disabled', 'disabled');
      rfqButtonSelector.attr('disabled', 'disabled');

      const self = $(this);
      const dataObj = PAC_HELPER.pacProcessFormData(self);
      const fire_ajax = PAC_HELPER.shouldFireAjax(dataObj);

      if (fire_ajax) {
        PAC_HELPER.loadingEffect('.pac-loader');
        $.ajax({
          type: 'post',
          dataType: 'json',
          url: ajaxUrl,
          data: {
            action: 'pac_calculate_inventory_data',
            form: dataObj,
          },
          success: function(response) {
            PAC_HELPER.pacHandleError(response);
            PAC_HELPER.unLoadingEffect('.pac-loader');

            if (parseInt(response.available_quantity) > 0) {
              $('input.inventory-qty').attr({
                max: response.available_quantity,
                min: 1,
              });

              if ($('.nets-quantity').length > 0) {
                $('.nets-quantity').show();
              }

              const priceBreakdown = response.price_breakdown;
              let priceBreakdownMarkupContent = '<ul>';

              const quote_total =
                priceBreakdown &&
                priceBreakdown['quote_total'] &&
                priceBreakdown['quote_total'].cost
                  ? priceBreakdown['quote_total'].cost
                  : '0';
              $('.quote_price').val(quote_total);

              for (const key in priceBreakdown) {
                if (priceBreakdown.hasOwnProperty(key)) {
                  if (key === 'quote_total') continue;
                  priceBreakdownMarkupContent += `<li class="${key}"><span class="name">${priceBreakdown[key]['text']}</span> <span class="price">${priceBreakdown[key]['cost']}</span></li>`;
                }
              }

              priceBreakdownMarkupContent += '</ul>';

              $('.booking_cost').html(priceBreakdownMarkupContent);
              $('.booking-pricing-info').fadeIn();
              //End

              if (response.date_multiply === 'per_hour') {
                $('body .show_if_day')
                  .children('span')
                  .hide();
                $('body .show_if_time').show();
              } else {
                $('body .show_if_time').hide();
                $('body .show_if_day')
                  .children('span')
                  .show();
              }
              $('.inventory-qty').focus();
              $('.inventory-qty-next').focus();
            }
          },
        });
      } else {
        $('.nets-quantity').hide();
      }
    });
  }

  // PaC modal
  $('#showBooking').on('click', function() {
    $('#animatedModal').toggleClass('zoomIn');
    $('body').addClass('pacOverflow');
    inventorySwitching();
  });

  /**
   * Initialize calendar
   *
   * @since 1.0.0
   * @version 5.9.0
   * @return null
   */
  PAC_CALENDER_ACTION.init(CALENDAR_DATA);
  inventorySwitching();
  pacCostHandle();
  initModal();
});
