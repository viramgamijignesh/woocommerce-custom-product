jQuery(document).ready(function($) {
  var admin_data = PAC_ADMIN_DATA;

  /**
   * Add new row
   *
   * @since 2.0.0
   * @return null
   */
  $('.add_nets_row').click(function() {
    $(this)
      .closest('table')
      .find('tbody')
      .append($(this).data('row'));
    $('body').trigger('row_added');
    return false;
  });

  /**
   * Cotnrol date format
   *
   * @since 2.0.0
   * @return null
   */
  var date_format;
  if (typeof admin_data.calendar_data != 'undefined') {
    if (admin_data.calendar_data.date_format.toLowerCase() === 'd/m/y') {
      date_format = 'd/m/yy';
    }

    if (admin_data.calendar_data.date_format.toLowerCase() === 'm/d/y') {
      date_format = 'm/d/yy';
    }

    if (admin_data.calendar_data.date_format.toLowerCase() === 'y/m/d') {
      date_format = 'yy/m/d';
    }
  }

  $('body').on('row_added', function() {
    $('.pac-date-picker').datetimepicker({
      format: 'Y-m-d H:i:s',
      minDate: 0,
      step: admin_data.calendar_data
        ? admin_data.calendar_data.time_interval
        : 5,
    });
  });

  $('.pac-date-picker').datetimepicker({
    format: 'Y-m-d H:i:s',
    minDate: 0,
    step: admin_data.calendar_data ? admin_data.calendar_data.time_interval : 5,
  });

  $('body').on('.add_nets_row', function() {
    $('.pac-date-picker').datetimepicker({
      format: 'Y-m-d H:i:s',
      minDate: 0,
      step: admin_data.calendar_data
        ? admin_data.calendar_data.time_interval
        : 5,
    });
  });

  /**
   * Remove row
   *
   * @since 1.0.0
   * @version 2.0.0
   * @return null
   */
  $('body').on('click', 'button.remove_row', function() {
    $(this)
      .closest('.nets-remove-rows')
      .remove();
    return false;
  });

  $('body').on('click', 'td.remove', function() {
    $(this)
      .closest('tr')
      .remove();
    return false;
  });

  $('body').on('click', 'td.inventory-remove', function() {
    var ids = JSON.parse($('.nets_availability_remove_id').val());

    var newId = $(this)
      .closest('tr')
      .data('id');
    ids.push(newId);

    $('.nets_availability_remove_id').val(JSON.stringify(ids));

    $(this)
      .closest('tr')
      .remove();
    return false;
  });

  /**
   * Show or hide row
   *
   * @since 2.0.0
   * @return null
   */
  $('.nets-hide-row').hide();

  $('body').on('click', '.show-or-hide', function(e) {
    $(this)
      .closest('div.nets-show-bar')
      .next('div.nets-hide-row')
      .slideToggle();
    return false;
  });

  $('.sortable').sortable({
    cursor: 'move',
  });

  /**
   * Control pricing types
   *
   * @since 2.0.0
   * @return null
   */
  $('.daily-pricing-panel').hide();
  $('.monthly-pricing-panel').hide();

  var pricingType = $('#pricing_type').val();

  if (pricingType == 'daily_pricing') {
    $('.daily-pricing-panel').show();
    $('.general-pricing-panel').hide();
    $('.monthly-pricing-panel').hide();
    $('.nets-days-range-panel').hide();
  } else if (pricingType == 'monthly_pricing') {
    $('.daily-pricing-panel').hide();
    $('.general-pricing-panel').hide();
    $('.monthly-pricing-panel').show();
    $('.nets-days-range-panel').hide();
  } else if (pricingType == 'days_range') {
    $('.daily-pricing-panel').hide();
    $('.general-pricing-panel').hide();
    $('.monthly-pricing-panel').hide();
    $('.nets-days-range-panel').show();
  } else if (pricingType == 'flat_hours') {
    $('.daily-pricing-panel').hide();
    $('.general-pricing-panel').hide();
    $('.monthly-pricing-panel').hide();
    $('.nets-days-range-panel').hide();
  } else {
    $('.daily-pricing-panel').hide();
    $('.general-pricing-panel').show();
    $('.monthly-pricing-panel').hide();
    $('.nets-days-range-panel').hide();
  }

  $('#pricing_type').change(function() {
    var pricingType = this.value;

    if (pricingType == 'daily_pricing') {
      $('.daily-pricing-panel').show();
      $('.general-pricing-panel').hide();
      $('.monthly-pricing-panel').hide();
      $('.nets-days-range-panel').hide();
    } else if (pricingType == 'monthly_pricing') {
      $('.daily-pricing-panel').hide();
      $('.general-pricing-panel').hide();
      $('.monthly-pricing-panel').show();
      $('.nets-days-range-panel').hide();
    } else if (pricingType == 'days_range') {
      $('.daily-pricing-panel').hide();
      $('.general-pricing-panel').hide();
      $('.monthly-pricing-panel').hide();
      $('.nets-days-range-panel').show();
    } else if (pricingType == 'flat_hours') {
      $('.daily-pricing-panel').hide();
      $('.general-pricing-panel').hide();
      $('.monthly-pricing-panel').hide();
      $('.nets-days-range-panel').hide();
    } else {
      $('.daily-pricing-panel').hide();
      $('.general-pricing-panel').show();
      $('.monthly-pricing-panel').hide();
      $('.nets-days-range-panel').hide();
    }
  });

  /**
   * Control hourly pricing types
   *
   * @since 4.0.7
   * @return null
   */
  var hourlyPricingType = $('#hourly_pricing_type').val();

  if (hourlyPricingType == 'hourly_general') {
    $('.nets-hourly-general-panel').show();
    $('.nets-hourly-range-panel').hide();
  } else {
    $('.nets-hourly-general-panel').hide();
    $('.nets-hourly-range-panel').show();
  }

  $('#hourly_pricing_type').change(function() {
    var hourlyPricingType = this.value;
    if (hourlyPricingType == 'hourly_general') {
      $('.nets-hourly-general-panel').show();
      $('.nets-hourly-range-panel').hide();
    } else {
      $('.nets-hourly-general-panel').hide();
      $('.nets-hourly-range-panel').show();
    }
  });

  /**
   * Control payable terms
   *
   * @since 2.0.0
   * @return null
   */
  var showHidePanels = [
    {
      panel: 'PaC_Category',
      selector: 'select#inventory_pac_cat_payable_or_not',
      selectorValue: { show: 'yes', hide: 'no' },
      ids: [
        'input#inventory_pac_cat_cost_termmeta',
        'input#inventory_pac_cat_price_applicable_term_meta',
        'select#inventory_pac_cat_price_applicable_term_meta',
        'input#inventory_pac_cat_hourly_cost_termmeta',
      ],
    },
    {
      panel: 'PaC_Category',
      selector: 'select#inventory_pac_cat_price_applicable_term_meta',
      selectorValue: { show: 'per_day', hide: 'one_time' },
      ids: ['input#inventory_pac_cat_hourly_cost_termmeta'],
    },
    {
      panel: 'Resource',
      selector: 'select#inventory_price_applicable_term_meta',
      selectorValue: { show: 'per_day', hide: 'one_time' },
      ids: ['input#inventory_hourly_cost_termmeta'],
    },
    {
      panel: 'Person',
      selector: 'select#inventory_person_payable_or_not',
      selectorValue: { show: 'yes', hide: 'no' },
      ids: [
        'input#inventory_person_cost_termmeta',
        'select#inventory_person_price_applicable_term_meta',
        'input#inventory_peroson_hourly_cost_termmeta',
      ],
    },
    {
      panel: 'Person',
      selector: 'select#inventory_person_price_applicable_term_meta',
      selectorValue: { show: 'per_day', hide: 'one_time' },
      ids: ['input#inventory_peroson_hourly_cost_termmeta'],
    },
    {
      panel: 'Resource',
      selector: 'select#inventory_sd_price_applicable_term_meta',
      selectorValue: { show: 'per_day', hide: 'one_time' },
      ids: ['input#inventory_sd_hourly_cost_termmeta'],
    },
  ];

  //For preselector
  showHidePanels.forEach(showHidePanel => {
    var currentValue = $(showHidePanel.selector).val();
    $ids = showHidePanel.ids;

    if (currentValue === showHidePanel.selectorValue.hide) {
      $ids.forEach(id => {
        $(id)
          .parents('.form-field')
          .hide();
      });
    }

    if (currentValue === showHidePanel.selectorValue.show) {
      $ids.forEach(id => {
        $(id)
          .parents('.form-field')
          .show();
      });
    }
  });

  // For change event
  $('body').on('change', 'select', function(e) {
    var currentSelector = $(this).attr('id');

    showHidePanels.forEach(showHidePanel => {
      if (`select#${currentSelector}` === showHidePanel.selector) {
        var currentSelectorValue = $(showHidePanel.selector).val();
        $ids = showHidePanel.ids;

        if (currentSelectorValue === showHidePanel.selectorValue.hide) {
          $ids.forEach(id => {
            $(id)
              .parents('.form-field')
              .hide();
          });
        }

        if (currentSelectorValue === showHidePanel.selectorValue.show) {
          $ids.forEach(id => {
            $(id)
              .parents('.form-field')
              .show();
          });
        }
      }
    });
  });

  /**
   * Control settings tabs
   *
   * @since 2.0.0
   * @return null
   */
  $('#pac_setting_tabs').tabs();

  $('.inventory-resources').select2({
    placeholder: 'Select resources',
    tags: true,
  });
  $('select').on('select2:select', function(evt) {
    var element = evt.params.data.element;
    var $element = $(element);

    $element.detach();
    $(this).append($element);
    $(this).trigger('change');
  });

  /**
   * Control settings tabs
   *
   * @since 2.0.0
   * @return null
   */
  //Display options
  var displayOption = $('#pac_settings_for_display').val();
  if (displayOption === 'global') {
    $('.pac-display-fields').hide();
    $('#pac_settings_for_display')
      .next('span.description')
      .show();
  } else {
    $('.pac-display-fields').show();
    $('#pac_settings_for_display')
      .next('span.description')
      .hide();
  }

  $('#pac_settings_for_display').on('change', function() {
    var option = $(this).val();
    if (option === 'global') {
      $('.pac-display-fields').hide();
      $('#pac_settings_for_display')
        .next('span.description')
        .show();
    } else {
      $('.pac-display-fields').show();
      $('#pac_settings_for_display')
        .next('span.description')
        .hide();
    }
  });

  //Label options
  var labelOption = $('#pac_settings_for_labels').val();
  if (labelOption === 'global') {
    $('.pac-label-fields').hide();
    $('#pac_settings_for_labels')
      .next('span.description')
      .show();
  } else {
    $('.pac-label-fields').show();
    $('#pac_settings_for_labels')
      .next('span.description')
      .hide();
  }

  $('#pac_settings_for_labels').on('change', function() {
    var option = $(this).val();
    if (option === 'global') {
      $('.pac-label-fields').hide();
      $('#pac_settings_for_labels')
        .next('span.description')
        .show();
    } else {
      $('.pac-label-fields').show();
      $('#pac_settings_for_labels')
        .next('span.description')
        .hide();
    }
  });

  //Condition options
  var conditionOption = $('#pac_settings_for_conditions').val();
  if (conditionOption === 'global') {
    $('.pac-condition-fields').hide();
    $('#pac_settings_for_conditions')
      .next('span.description')
      .show();
  } else {
    $('.pac-condition-fields').show();
    $('#pac_settings_for_conditions')
      .next('span.description')
      .hide();
  }

  $('#pac_settings_for_conditions').on('change', function() {
    var option = $(this).val();
    if (option === 'global') {
      $('.pac-condition-fields').hide();
      $('#pac_settings_for_conditions')
        .next('span.description')
        .show();
    } else {
      $('.pac-condition-fields').show();
      $('#pac_settings_for_conditions')
        .next('span.description')
        .hide();
    }
  });

  //Validation options
  var conditionOption = $('#pac_settings_for_validations').val();
  if (conditionOption === 'global') {
    $('.pac-validation-fields').hide();
    $('#pac_settings_for_validations')
      .next('span.description')
      .show();
  } else {
    $('.pac-validation-fields').show();
    $('#pac_settings_for_validations')
      .next('span.description')
      .hide();
  }

  $('#pac_settings_for_validations').on('change', function() {
    var option = $(this).val();
    if (option === 'global') {
      $('.pac-validation-fields').hide();
      $('#pac_settings_for_validations')
        .next('span.description')
        .show();
    } else {
      $('.pac-validation-fields').show();
      $('#pac_settings_for_validations')
        .next('span.description')
        .hide();
    }
  });
});
