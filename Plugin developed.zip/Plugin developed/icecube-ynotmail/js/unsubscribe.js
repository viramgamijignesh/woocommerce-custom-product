// simple-ajax-example.js--------------

jQuery( document ).ready( function($) {    
    
    $('.unsubscribe').click(function(){
        if($(this).prop("checked") == true){
            alert("checked");
            console.log("Checkbox is checked.");
        }
        else if($(this).prop("checked") == false){
            //alert('unchecked');
            var unsubscribe = $(".unsubscribe").val();    
            $(".unsubscribe-loader").show();
            //alert(unsubscribe);
            $.ajax({
                url: unsubscribe_ajax_obj.ajaxurl, // or example_ajax_obj.ajaxurl if using on frontend
                type : "post",            
                data: {
                    'action': 'unsubscribe_ajax_request',
                    'unsubscribe' : unsubscribe 
                },
                success:function(data) {
                    //alert("success"+data);
                    $(".unsubscribe-loader").hide();    
                    $(".unsubscribe_text").after('<br><span class="success">Your email is ubsubscribed successfully</span>');
                    console.log(data);
                },
                error: function(errorThrown){
                    alert("errorThrown"+errorThrown);
                    $(".unsubscribe-loader").hide();    
                    //$(".unsubscribe_text").after('<span class="success">Your email successfully Subcribe</span>');
                    console.log(errorThrown);
                }
            });  
        }
    });


});