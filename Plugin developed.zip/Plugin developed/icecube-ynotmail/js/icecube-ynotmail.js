// simple-ajax-example.js--------------

jQuery( document ).ready( function($) {    
    $(document).on( 'click', '.ynotmail-form-submit', function() {       
        
        var tnpemail = $(".tnp-email").val();    
        //alert(tnpemail);
        $(".error").hide();
        $(".success").hide();
        $(".footer-news-letter-loader").show();
        $(".ynotmail-form-submit").text('');       
        
        
        var hasError = false;
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        

        var emailaddressVal = $(".tnp-email").val();
        if(tnpemail == '') {            
            //$(".tnp-email").attr("placeholder", "Please enter your email address.");
            $(".tnp-email").after('<span class="error">Please enter your email address.</span>');
            hasError = true;
            $(".footer-news-letter-loader").hide();  
            $(".ynotmail-form-submit").text('Subscribe');    
        }
 
        else if(!emailReg.test(tnpemail)) {
            //$(".tnp-email").attr("placeholder", "Enter a valid email address.");
            $(".tnp-email").after('<span class="error">Enter a valid email address.</span>');
            hasError = true;
            $(".footer-news-letter-loader").hide(); 
            $(".ynotmail-form-submit").text('Subscribe');           
        }
 
        if(hasError == true) { return false; }else{

            $.ajax({
                url: ynotmail_ajax_obj.ajaxurl, // or example_ajax_obj.ajaxurl if using on frontend
                type : "post",            
                data: {
                    'action': 'ynotmail_ajax_request',
                    'tnpemail' : tnpemail 
                },
                success:function(data) {
                    //$(".tnp-email").after('<span class="success">Your email successfully Subcribe</span>');
                    $('.tnp-email').after(data);    
                    $(".footer-news-letter-loader").hide();    
                    $(".ynotmail-form-submit").text('Subscribe');      

                    var str1      = window.location.href;
                    var str2 = "https://stompersgloves.com/my-account/newsletter-subscription/";
                    if(str1 === str2){                        
                        location.reload();   
                    }

                                               
                    console.log(data);
                    
                },
                error: function(errorThrown){
                    //alert("error"+errorThrown);                    
                    $(".success").hide();
                    $(".footer-news-letter-loader").hide();                                                        
                    $(".ynotmail-form-submit").text('Subscribe');       
                    console.log(errorThrown);
                }
            });  

        }
    });       
});