<?php
/**
 *
 * @link              https://wordpress.org/
 * @since             1.0.0
 * @package           Team_Info
 *
 * @wordpress-plugin
 * Plugin Name:       Team Info
 * Plugin URI:        https://wordpress.org/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Jignesh Viramgami
 * Author URI:        https://wordpress.org/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       team-info
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 */
define( 'TEAM_INFO_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-team-info-activator.php
 */
function activate_team_info() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-team-info-activator.php';
	Team_Info_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-team-info-deactivator.php
 */
function deactivate_team_info() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-team-info-deactivator.php';
	Team_Info_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_team_info' );
register_deactivation_hook( __FILE__, 'deactivate_team_info' );


/**
 * Begins execution of the plugin.
 * 
 * Enqueue style and script
 */
function wpse_enqueue_datepicker() {

	if( is_admin() ) :
    wp_register_script( 'jquery-ui-date-tmf', 'https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.9/datepicker.min.js' );
    wp_enqueue_script( 'jquery-ui-date-tmf' ); 
    wp_register_style( 'jquery-ui-tmf', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css' );
    wp_enqueue_style( 'jquery-ui-tmf' );  
    wp_enqueue_style( 'tmf-style-admin', plugin_dir_url(__FILE__) . 'admin/css/team-info-admin.css', array(),  false, 'all' );
	else :
    wp_enqueue_style( 'tmf-style', plugin_dir_url(__FILE__) . 'public/css/team-info-public.css', array(),  false, 'all' );    
	endif;

}
add_action( 'init', 'wpse_enqueue_datepicker' );


 /**
 * Creating team as custom post type.
 * @since    1.0.0
 */
function team_create_posttype() {
	register_post_type( 'teams',
		// CPT Options
		array(
		  'labels' => array(
		   'name' => __( 'teams' ),
		   'singular_name' => __( 'Team' )
		  ),
		  'public' => true,
		  'has_archive' => false,
		  'rewrite' => array('slug' => 'teams'),
		  'supports' => array( 'title', 'custom-fields' )
		)
	);
}
add_action( 'init', 'team_create_posttype' );


/**
 * Creating basic custom field.
 * @since    1.0.0
 */
function tmf_teams_metaboxes( ) {
   global $wp_meta_boxes;
   add_meta_box('teamcustomfield', __('Team Info'), 'tmf_teams_metaboxes_html', 'teams', 'normal', 'high');
}
add_action( 'add_meta_boxes_teams', 'tmf_teams_metaboxes' );

function tmf_teams_metaboxes_html()
{
    global $post;
    $custom = get_post_custom($post->ID);
    //echo '<pre>';print_r($custom); echo '</pre>';
    $tmf_team_title = isset($custom["tmf_team_title"][0]) ? $custom["tmf_team_title"][0] : '';
    $tmf_team_logo	= isset($custom["tmf_team_logo"][0]) ? unserialize($custom["tmf_team_logo"][0]) : '';
    $tmf_team_bio  = isset($custom["tmf_team_bio"][0]) ? $custom["tmf_team_bio"][0] : '';
    
	?>
		<input type="hidden" name="tmf_team_nonce" value="<?php echo wp_create_nonce( basename(__FILE__) ); ?>">
    	<p>
    		<label for="tmf_team_title">Team Name</label><br>
    		<input name="tmf_team_title" id="tmf_team_title" value="<?php echo $tmf_team_title; ?>" style="width:100%">
    	</p>
    	<p>
			<label for="tmf_team_logo[image]">Team Logo</label><br>
			<input type="text" name="tmf_team_logo[image]" id="tmf_team_logo[image]" class="meta-image regular-text" value="<?php if(is_array($tmf_team_logo)) echo $tmf_team_logo['image']; ?>">
			<input type="button" class="button image-upload" value="Browse">
			<script>
			  jQuery(document).ready(function ($) {
			    // Instantiates the variable that holds the media library frame.
			    var meta_image_frame
			    // Runs when the image button is clicked.
			    $('.image-upload').click(function (e) {
			      // Get preview pane
			      var meta_image_preview = $(this)
			        .parent()
			        .parent()
			        .children('.image-preview')
			      // Prevents the default action from occuring.
			      e.preventDefault()
			      var meta_image = $(this).parent().children('.meta-image')
			      // If the frame already exists, re-open it.
			      if (meta_image_frame) {
			        meta_image_frame.open()
			        return
			      }
			      // Sets up the media library frame
			      meta_image_frame = wp.media.frames.meta_image_frame = wp.media({
			        title: meta_image.title,
			        button: {
			          text: meta_image.button,
			        },
			      })
			      // Runs when an image is selected.
			      meta_image_frame.on('select', function () {
			        // Grabs the attachment selection and creates a JSON representation of the model.
			        var media_attachment = meta_image_frame
			          .state()
			          .get('selection')
			          .first()
			          .toJSON()
			        // Sends the attachment URL to our custom image input field.
			        meta_image.val(media_attachment.url)
			        meta_image_preview.children('img').attr('src', media_attachment.url)
			      })
			      // Opens the media library frame.
			      meta_image_frame.open()
			    })
			  })
			</script>
		</p>

		<div class="image-preview"><?php if(is_array($tmf_team_logo)) { ?><img src="<?php echo $tmf_team_logo['image']; ?>" style="max-width: 100px;"><?php } ?></div>
		<p>
			<label for="tmf_team_bio[textarea]">Team's Bio</label><br>
	    	<textarea name="tmf_team_bio" id="tmf_team_bio" rows="5" cols="30" maxlength="120" style="width:500px;"><?php echo $tmf_team_bio; ?></textarea>
		</p>

		<p class="tmf-title"><strong>Team Players</strong></p>

		<?php 
		global $post;
	    $tmf_customdata_group = get_post_meta($post->ID, 'customdata_group', true);
    	?>

	    <script type="text/javascript">
	    jQuery(document).ready(function( $ ){
	        $( '#add-row' ).on('click', function() {
	            var row = $( '.empty-row.screen-reader-text' ).clone(true);
	            row.find('.dob').removeClass('hid');
	            row.find('.dob').addClass('vis');
	            row.removeClass( 'empty-row screen-reader-text' );
	            row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );

	            dateinit();
	            return false;
	        });

	        $( '.remove-row' ).on('click', function() {
	            $(this).parents('tr').remove();
	            return false;
	        });

	        dateinit();
	        function dateinit(myelement) { 
		        $('.dob.vis').datepicker({
				  	onSelect: function(value, ui) {
				    var today = new Date(),
				     dob = new Date(value),
				    age = new Date(today - dob).getFullYear() - 1970;

				    console.log('call'+age);
				    console.log(this);
				    var id = $(this).attr('id');
				    $('#'+id).parents('tr').find('.age').append(age);
				    //$('"#'+id+'"').parents('tr').find('.age').append(age);
				    $(this).parents('tr').find('.age').val(age);
				},
				  	maxDate: '+0d',
				  	yearRange: '1920:2010',
				  	changeMonth: true,
				  	changeYear: true
				});
	    	}

	    });
	  	</script>

	  	<table id="repeatable-fieldset-one" width="100%">
	  	<tbody>
	    	<?php
	    	if ( $tmf_customdata_group ) :
	      		foreach ( $tmf_customdata_group as $field ) {
	    		?>
	    		<tr>
	      			<td width="15%">
	      				<label>Player Name</label><br>
	        			<input type="text"  placeholder="Title" name="tmf_player_name[]" value="<?php if($field['tmf_player_name'] != '') echo esc_attr( $field['tmf_player_name'] ); ?>" />
	        		</td> 
	        		<td>
			      		<label>Gender</label><br>			        	
			        	<select name="tmf_player_gender[]">
			        		<option  value="m" <?php if($field['tmf_player_gender'] != '' && $field['tmf_player_gender'] == 'm') echo 'selected'; ?>>Male</option>
			        		<option value="f" <?php if($field['tmf_player_gender'] != '' && $field['tmf_player_gender'] == 'f') echo 'selected'; ?>>Female</option>
			        	</select>
			        </td>
			        <td>
			        	<label>Birthdate</label><br>
			        	<input class="dob vis" type="text" name="tmf_player_dob[]" value="<?php if($field['tmf_player_dob'] != '') echo esc_attr( $field['tmf_player_dob'] ); ?>"/>					
			        </td>
			        <td>
			        	<label>Age</label><br>	
			        	<input class="age" type="text" name="tmf_player_age[]" value="<?php if($field['tmf_player_age'] != '') echo esc_attr( $field['tmf_player_age'] ); ?>"/>						
			        </td>
	      			<td>
	      				<label>Bio</label><br>
	      				<textarea placeholder="Description" maxlength="120" cols="55" rows="5" name="tmf_player_bio[]"><?php if ($field['tmf_player_bio'] != '') echo esc_attr( $field['tmf_player_bio'] ); ?></textarea>
	      			</td>
	      			<td><a class="button remove-row" href="#1">Remove</a></td>
	    		</tr>
	    	<?php
	    	}
		    else : ?>
			    <tr>
			      	<td> 
			      		<label>Player Name</label><br>
			        	<input type="text" placeholder="Title" title="Title" name="tmf_player_name[]" />
			        </td>
			      	<td>
			      		<label>Gender</label><br>			        	
			        	<select name="tmf_player_gender[]">
			        		<option  value="m">Male</option>
			        		<option value="f">Female</option>
			        	</select>
			        </td>
			        <td>
			        	<label>Birthdate</label><br>
			        	<input class="dob vis" type="text" name="tmf_player_dob[]"/>					
			        </td>
			        <td>
			        	<label>Age</label><br>		        	
						<input class="age" type="text" name="tmf_player_age[]"/>
			        </td>
			      	<td>
			      		<label>Bio</label><br>
			        	<textarea placeholder="Description" cols="55" maxlength="120" rows="5" name="tmf_player_bio[]"></textarea>
			        </td>	
			        <td><a class="button  cmb-remove-row-button button-disabled" href="#">Remove</a></td>		      	
			    </tr>

		    <?php endif; ?>

		    <!-- empty hidden one for jQuery -->
		    <tr class="empty-row screen-reader-text">
		      	<td>
		      		<label>Player Name</label><br>
		        	<input type="text" placeholder="Title" name="tmf_player_name[]"/>
		        </td>
		        <td>
		      		<label>Gender</label><br>		        	
		        	<select name="tmf_player_gender[]">
			        	<option  value="m">Male</option>
			        	<option value="f">Female</option>
			        </select>
		        </td>
		        <td>
		        	<label>Birthdate</label><br>
		        	<input class="dob hid" type="text" name="tmf_player_dob[]"/>					
		        </td>
		        <td>
		        	<label>Age</label><br>		        	
					<input class="age" type="text" name="tmf_player_age[]"/>
		        </td>
		      	<td>
		      		<label>Bio</label><br>
		        	<textarea placeholder="Description" cols="55" maxlength="120" rows="5" name="tmf_player_bio[]"></textarea>
		        </td>
		        <td><a class="button remove-row" href="#">Remove</a></td>
		    </tr>
	  	</tbody>
		</table>

		<p><a id="add-row" class="button" href="#">Add another</a></p>

	<?php
}

function tmf_teams_save_post()
{
    if(empty($_POST)) return; 
    global $post;
    $post_id = $post->ID;

    if ( !wp_verify_nonce( $_POST['tmf_team_nonce'], basename(__FILE__) ) ) {
		return $post_id;
	}
	// check autosave
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return $post_id;
	}
	// check permissions
	if ( 'teams' === $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) ) {
			return $post_id;
		} elseif ( !current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}
	}

    update_post_meta($post_id, "tmf_team_title", $_POST["tmf_team_title"]);
    update_post_meta($post_id, "tmf_team_logo", $_POST["tmf_team_logo"]);
    update_post_meta($post_id, "tmf_team_bio", $_POST["tmf_team_bio"]);

    // Team custom repeater fields.
    $old = get_post_meta($post_id, 'customdata_group', true);
    $new = array();
    $tmf_player_names  = $_POST['tmf_player_name'];
    $tmf_player_genders = $_POST['tmf_player_gender'];
    $tmf_player_dobs    = $_POST['tmf_player_dob'];
    $tmf_player_ages    = $_POST['tmf_player_age'];
    $tmf_player_bios   = $_POST['tmf_player_bio'];
    $count = count( $tmf_player_names );
    for ( $i = 0; $i < $count; $i++ ) {
        if ( $tmf_player_names[$i] != '' ) :
            $new[$i]['tmf_player_name'] = stripslashes( strip_tags( $tmf_player_names[$i] ) );
            $new[$i]['tmf_player_gender'] = $tmf_player_genders[$i];
            $new[$i]['tmf_player_dob'] = $tmf_player_dobs[$i];
            $new[$i]['tmf_player_age'] = stripslashes( strip_tags( $tmf_player_ages[$i] ) );
            $new[$i]['tmf_player_bio'] = stripslashes( $tmf_player_bios[$i] ); // and however you want to sanitize
        endif;
    }
    if ( !empty( $new ) && $new != $old )
        update_post_meta( $post_id, 'customdata_group', $new );
    elseif ( empty($new) && $old )
        delete_post_meta( $post_id, 'customdata_group', $old );

}   
add_action( 'save_post_teams', 'tmf_teams_save_post' ); 

/**
 * Team info shortcode.
 *
 **/

add_shortcode( 'Display', 'wpdocs_bartag_func' );
function wpdocs_bartag_func( $atts ) {
    $atts = shortcode_atts( array(
        'team' => 10,
    ), $atts, 'bartag' );

    ob_start(); ?>

    	<?php     	
    		$per_page = is_numeric( number_format($atts['team']) ) ? number_format($atts['team']) : 10;
    		$param    = is_numeric( number_format($atts['team']) ) ? false : $atts['team'];

    		if( $param ) {
	    		$args = array(  
			        'post_type' => 'teams',
			        'post_status' => 'publish',
			        'posts_per_page' => $per_page, 
			        'meta_query' => array(
						array(
							'key' => 'tmf_team_title',
							'value' => $param,						
							'compare' => 'LIKE'
						)
					)
			        
			    );
	    	}else{
	    		$args = array(  
			        'post_type' => 'teams',
			        'post_status' => 'publish',
			        'posts_per_page' => $per_page, 
			    );
	    	}

		    $loop = new WP_Query( $args );

		    echo '<div class="tmf-main">'; 
		        
		    while ( $loop->have_posts() ) : $loop->the_post(); 

		    	echo '<div class="tmf-row">';

		    	echo '<div class="tmf-data-header">';
			    	echo '<div class="tmf-header-left">';
				    	$logo = get_post_meta( get_the_ID(), 'tmf_team_logo', true );		        
				        echo '<p><img src="'.$logo['image'].'"></p>';
			        echo '</div>';
			        echo '<div class="tmf-header-right">';
				        echo '<h2>'.get_post_meta( get_the_ID(), 'tmf_team_title', true ).'</h2>';
				        echo '<p>'.get_post_meta( get_the_ID(), 'tmf_team_bio', true ).'</p>';
				    echo '</div>';
		        echo '</div>';

		        $tmf_customdata_group = get_post_meta( get_the_ID(), 'customdata_group', true);		        
		    	if ( $tmf_customdata_group ) :
		    		echo '<table>';
		    		echo '<tr><th>Player Name</th><th>Gender</th><th>Birthdate</th><th>Age</th><th>Bio</th></rt>';
		      		foreach ( $tmf_customdata_group as $field ) {
		    		?>
		    		<tr>
		      			<td>		      				
		      				<p><?php if($field['tmf_player_name'] != '') echo esc_attr( $field['tmf_player_name'] ); ?></p>
		        		</td> 
		        		<td>
			        		<p><?php if($field['tmf_player_gender'] != '' && $field['tmf_player_gender'] == 'm') echo 'Male'; ?></p>
			        		<p><?php if($field['tmf_player_gender'] != '' && $field['tmf_player_gender'] == 'f') echo 'Female'; ?></p>
				        </td>
				        <td>
				        	<p><?php if($field['tmf_player_dob'] != '') echo esc_attr( $field['tmf_player_dob'] ); ?></p>
				        </td>
				        <td>
				        	<p><?php if($field['tmf_player_age'] != '') echo esc_attr( $field['tmf_player_age'] ); ?></p>	
				        </td>
		      			<td>		      				
		      				<p><?php if ($field['tmf_player_bio'] != '') echo esc_attr( $field['tmf_player_bio'] ); ?></p>
		      			</td>		      			
		    		</tr>
		    		<?php
		    		}
		    		echo '</table>';
		    	endif;

		    	echo '</div>';

		    endwhile;

		    echo '</div>';

		    wp_reset_postdata(); 
    	?>
 	<?php
 	
    return ob_get_clean();
}