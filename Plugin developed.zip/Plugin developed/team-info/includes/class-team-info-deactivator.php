<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://wordpress.org/
 * @since      1.0.0
 *
 * @package    Team_Info
 * @subpackage Team_Info/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Team_Info
 * @subpackage Team_Info/includes
 * @author     Chirag <chiragrathod.crr@gmail.com>
 */
class Team_Info_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
