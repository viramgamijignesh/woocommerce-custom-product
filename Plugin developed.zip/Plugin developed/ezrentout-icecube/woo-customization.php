<?php

/*
 * Login for see price
 */

add_filter('woocommerce_get_price_html','ez_rentout_members_only_price');
function ez_rentout_members_only_price($price){
    global $product;
    $product_id = $product->id;
    $ez_available_for_sale = get_post_meta( $product_id, 'ez_available_for_sale', true );

    if($ez_available_for_sale == 'no'){        
        return get_woocommerce_currency_symbol(). $product->get_regular_price().'0'.' Selling Price';        
    }
    else{
        if(is_user_logged_in()){
            return $price;                   
        }else{
            return '<a href="' .get_permalink(woocommerce_get_page_id('myaccount')). '">Login</a> or <a href="' .get_permalink(woocommerce_get_page_id('myaccount')). '">Register</a> to view price!';
        }
    }
}

function skyverge_shop_display_skus() {

    global $product;
    $id             = $product->id;
    $ez_available_for_sale = get_post_meta( $product->id, 'ez_available_for_sale', true );
    $sequence_num   = get_post_meta($id, 'ez_sequence_num', true);      
    if($ez_available_for_sale == 'yes'){    

        echo $check_availibity_html = '<br><a id="ezr-cart-widget-item-' . $sequence_num . '" onclick="ezrLoadCalendarDialog(' . $sequence_num . ', this)" href="#_">Availability Calendar</a>';
    }
        
}
add_action( 'woocommerce_after_shop_loop_item_title', 'skyverge_shop_display_skus', 15 );

/*
 * Replace addtocart to Rent button
 */

add_filter('woocommerce_product_single_add_to_cart_text', 'ez_rentout_custom_add_to_cart_button_woocommerce');
function ez_rentout_custom_add_to_cart_button_woocommerce()
{
    $product = get_product();   
    $product_id = $product->id;
    $ez_available_for_sale = get_post_meta( $product_id, 'ez_available_for_sale', true );

    if($ez_available_for_sale == 'yes'){
        if(is_user_logged_in()){
            return __('Rent', 'woocommerce');         
        }else{    
            
           /* echo "<script type='text/javascript'>
            jQuery('.single-product-details .cart button').replaceWith(function() {
                return jQuery('<div/>', {
                    html: this.innerHTML
                });
            });
            jQuery('.single-product-details .cart button').removeClass('single_add_to_cart_button button ');
            
            </script>";*/

            //remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart');
            //add_filter( 'woocommerce_is_purchasable', '__return_false' );
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 50 );
            
            echo '<a href="' .get_permalink(woocommerce_get_page_id('myaccount')). '">Login</a> or <a href="' .get_permalink(woocommerce_get_page_id('myaccount')). '">Register</a> to rent this item!';  
        }
    }else{
        return __('Add to cart', 'woocommerce');    
    }
    
}



/*
 * Add datepicker before add to cart
 */

add_action('woocommerce_before_add_to_cart_button', 'ez_rentout_add_fields_before_add_to_cart',12);
function ez_rentout_add_fields_before_add_to_cart()
{
    global $product;
    $id             = $product->id;
    $ez_available_for_sale = get_post_meta( $product->id, 'ez_available_for_sale', true );
    if($ez_available_for_sale == 'yes' && is_user_logged_in()){
        $identifier     = get_post_meta($id, 'ez_identifier', true);    
        $sequence_num   = get_post_meta($id, 'ez_sequence_num', true);    
        //$data           = get_order_detail($identifier);   
        $booked_dates   = get_booked_dates($sequence_num); 
        
        if($booked_dates){
            foreach ($booked_dates as $key => $booked_date) {
                $dt = new \DateTime($booked_date['from']);
                $booked_from_date = $dt->format('Y/m/d');
                //$booked_date_arr[$key]['from'] = date('Y/m/d', strtotime($booked_from_date. ' - 2 days'));
                $booked_date_arr[$key]['from'] = date('Y/m/d', strtotime($booked_from_date));
                
                $dt2 = new \DateTime($booked_date['to']);
                $booked_to_date = $dt2->format('Y/m/d');
                $booked_date_arr[$key]['to'] = date('Y/m/d', strtotime($booked_to_date. ' + 4 days'));

                //exit;
           
            }
            
            $booked_date_array = json_encode($booked_date_arr); 
            if($booked_date_array){
            echo "<input type=hidden name=booked_date_array value='".stripslashes($booked_date_array)."'  class=booked_date_array id=booked_date_array>";
            }
        }
        
        echo $check_availibity_html = '<a id="ezr-cart-widget-item-' . $sequence_num . '" onclick="ezrLoadCalendarDialog(' . $sequence_num . ', this)" href="#_">Availability Calendar</a>';
        
        ?>
         <table>
            <tr>
              <td>
                <?php
            _e("From:", "aoim");
           
        ?>
             </td>
              <td>
                <input type = "text" name = "from_date" id = "from_date" class="date-picker" autocomplete="off" placeholder = "Select From Date" required>
              </td>
            </tr>
            <tr>
              <td>
                <?php
            _e("To:", "aoim");
        ?>
             </td>
              <td>
                <input type = "text" name = "to_date" id = "to_date" class="date-picker" autocomplete="off" placeholder = "Select To Date" required>
              </td>      
            </tr>    
          </table>
          <span class="note">Note : Minimum rent period is 7 days</span><br>
          <span class="note">Note : Please request a date that allows at least two days for shipping</span>
          
          <?php
    }
    
}
/**
 * Add data to cart item
 */
add_filter('woocommerce_add_cart_item_data', 'ez_rentout_add_cart_item_data', 25, 2);
function ez_rentout_add_cart_item_data($cart_item_meta, $product_id)
{
    if (isset($_POST['from_date']) && isset($_POST['to_date'])) {
        $custom_data                   = array();
        $custom_data['from_date']      = isset($_POST['from_date']) ? sanitize_text_field($_POST['from_date']) : "";
        $custom_data['to_date']        = isset($_POST['to_date']) ? sanitize_text_field($_POST['to_date']) : "";
        $cart_item_meta['custom_data'] = $custom_data;
    }
    
    return $cart_item_meta;
}
/**
 * Display the custom data on cart and checkout page
 */
add_filter('woocommerce_get_item_data', 'ez_rentout_get_item_data', 25, 2);
function ez_rentout_get_item_data($other_data, $cart_item)
{
    if (isset($cart_item['custom_data'])) {
        $custom_data = $cart_item['custom_data'];
        
        $other_data[] = array(
            'name' => 'Rent From Date',
            'display' => $custom_data['from_date']
        );
        $other_data[] = array(
            'name' => 'Rent To Date',
            'display' => $custom_data['to_date']
        );
    }
    
    return $other_data;
}

/**
 * Add custom meta to order
 */
function ez_rentout_text_to_order_items( $item, $cart_item_key, $values, $order ) {
    if ( empty( $values['from_date'] ) ) {
        return;
    }
    $item->add_meta_data( __( 'Rent From Date', '' ), $values['from_date'] );
    $item->add_meta_data( __( 'Rent To Date', '' ), $values['to_date'] ); 
    
}

add_action( 'woocommerce_checkout_create_order_line_item', 'ez_rentout_text_to_order_items', 10, 4 );

/**
 * Add order item meta
 */
add_action('woocommerce_add_order_item_meta', 'ez_rentout_add_order_item_meta', 10, 2);
function ez_rentout_add_order_item_meta($item_id, $values)
{
    if (isset($values['custom_data'])) {
        $custom_data = $values['custom_data'];
        $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );    
        $buffer_time = $wp_setting_ezrentout_settings['wp_setting_text_field_shipping_buffer_time']; 
        $datetimed = DateTime::createFromFormat('m/d/Y', $custom_data['from_date']);
        $from_date =  $datetimed->format('m/d/Y');
        $buffer_day = date('Y-m-d', strtotime($from_date. ' - '.$buffer_time.' days'));        
        $buffer_days = date("m/d/Y", strtotime($buffer_day));        
        
        
        wc_add_order_item_meta($item_id, 'Rent From Date', $custom_data['from_date']);
        wc_add_order_item_meta($item_id, 'Rent To Date', $custom_data['to_date']);
        wc_add_order_item_meta($item_id, 'Expected Ship Date', $buffer_days);       
        
    }
}


/**
 * Add a custom field (in an order) to the emails
 */


function ez_rentout_woocommerce_order_item_meta_end( $item_id, $item, $order ) { 
    $name = get_post_meta( $item_id, '_woo_ufdc_uploaded_file_name_', true ); 
    $uploaded_file_path = get_post_meta( $item_id, '_woo_ufdc_uploaded_file_path_', true );  
    $path = site_url().'/'.$uploaded_file_path; 
    $url = '<a href="'.$uploaded_file_path.'" target="_blank">'.$name.'</a>';
    echo $url;
    return $url;
}; 

// add the action 
add_action( 'woocommerce_order_item_meta_end', 'ez_rentout_woocommerce_order_item_meta_end', 10, 3 ); 

add_action( 'woocommerce_email_after_order_table', 'ez_rentout_order_item_meta_end', 10, 4 );
function ez_rentout_order_item_meta_end( $order, $sent_to_admin, $plain_text, $email ){    
     echo '<p><b>Included freight both ways and we will send a waybill for the return as well with the package.</p>';
    //if ( $email->id == 'new_order' ) {
        $name = get_post_meta( $order->get_id(), '_woo_ufdc_uploaded_file_name_1', true ); 
        $uploaded_file_path = get_post_meta( $order->get_id(), '_woo_ufdc_uploaded_file_path_1', true );  
        $path = site_url().'/'.$uploaded_file_path; 
        if($name){
            $url = '<a href="'.$path.'" target="_blank">'.$name.'</a>';
            echo "<strong>Driver's License :</strong><br>
            <p>".$url."</p>";
        }
    //}
    

}


/**
 * Add API Calendar in product detaila page
 */

add_action('woocommerce_single_product_summary', 'ez_rentout_display_product_custom_field', 25);
function ez_rentout_display_product_custom_field()
{
    global $product;
    $id                    = $product->id;    
    $value                 = get_post_meta($id, 'checkin_due_on', true);
    $availability_calendar = get_post_meta($id, 'availability_calendar', true);
    $date                  = explode(" ", $value);
    
    $createDate = $date['0'];    
    
    echo '<input type="hidden" name="checkin_due_on" value="' . $createDate . '" class="checkin_due_on" id="checkin_due_on">';
}


/**
 * Checkout page Popup
 */

add_action( 'woocommerce_review_order_before_submit', 'ez_rentout_review_order_before_submit', 10 );
function ez_rentout_review_order_before_submit(){
    
    echo '
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>          
        </div>
        <div class="modal-body">';
          $post_7 = get_post(33896); 
            $excerpt = $post_7->post_content;
            echo $excerpt;
            echo '</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    <p><a href="#myModal" data-toggle="modal" data-target="#myModal">Rental agreement Template</a></p>';
   

}
/**
 *  Add Refund amount hook
 */
add_action( 'woocommerce_cart_calculate_fees', 'ez_rentout_add_checkout_fee' );
function ez_rentout_add_checkout_fee() {
   // Edit "Fee" and "5" below to control Label and Amount
   WC()->cart->add_fee( 'Refundable Deposit', 250 );
}

add_action( 'woocommerce_review_order_before_payment', 'ez_rentout_review_order_after_shipping', 10 );
function ez_rentout_review_order_after_shipping(){
    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );       
    
    if($wp_setting_ezrentout_settings['wp_setting_text_field_shipping_buffer_time_msg_checkbox'] == 1){
        echo '<p><b>'.$wp_setting_ezrentout_settings['wp_setting_text_field_shipping_buffer_time_msg'].'</b></p>';
    }
     
}

/**
 * Create Order in Ezrent and Create customer
 */

add_filter( 'woocommerce_payment_complete_order_status', 'ez_rentout_update_order_status', 10, 2 );
 
function ez_rentout_update_order_status( $order_status, $order_id ) {
    
    
    $order = new WC_Order( $order_id );   

    $first_name = $order->get_billing_first_name(); 
    $last_name = $order->get_billing_last_name();
    $address = $order->get_billing_address_1();
    $address_line_2 =  $order->get_billing_address_2();
    $email = $order->get_billing_email();
    $phone_number = $order->get_billing_phone();
    $city =  $order->get_billing_city();
    $state =  $order->get_billing_state();
    $address_name = "Default Address";  

    $user = $first_name;
    $random_password = wp_generate_password();        
    $user_id = wp_create_user( $user, $random_password, $email );   

         
    //update_user_meta( $user_id, 'guest', 'yes' );    
    //user's billing data
    update_user_meta( $user_id, 'billing_address_1', $order->billing_address_1 );
    update_user_meta( $user_id, 'billing_address_2', $order->billing_address_2 );
    update_user_meta( $user_id, 'billing_city', $order->billing_city );
    update_user_meta( $user_id, 'billing_company', $order->billing_company );
    update_user_meta( $user_id, 'billing_country', $order->billing_country );
    update_user_meta( $user_id, 'billing_email', $order->billing_email );
    update_user_meta( $user_id, 'billing_first_name', $order->billing_first_name );
    update_user_meta( $user_id, 'billing_last_name', $order->billing_last_name );
    update_user_meta( $user_id, 'billing_phone', $order->billing_phone );
    update_user_meta( $user_id, 'billing_postcode', $order->billing_postcode );
    update_user_meta( $user_id, 'billing_state', $order->billing_state ); 
    // user's shipping data
    update_user_meta( $user_id, 'shipping_address_1', $order->shipping_address_1 );
    update_user_meta( $user_id, 'shipping_address_2', $order->shipping_address_2 );
    update_user_meta( $user_id, 'shipping_city', $order->shipping_city );
    update_user_meta( $user_id, 'shipping_company', $order->shipping_company );
    update_user_meta( $user_id, 'shipping_country', $order->shipping_country );
    update_user_meta( $user_id, 'shipping_first_name', $order->shipping_first_name );
    update_user_meta( $user_id, 'shipping_last_name', $order->shipping_last_name );
    update_user_meta( $user_id, 'shipping_method', $order->shipping_method );
    update_user_meta( $user_id, 'shipping_postcode', $order->shipping_postcode );
    update_user_meta( $user_id, 'shipping_state', $order->shipping_state );
    //wc_update_new_customer_past_orders( $user_id );
    
    //if('processing' == $order_status ||  'on-hold' == $order_status || 'wc-pending' == $order_status || 'failed' == $order_status || 'quote' == $order_status || 'partial-shipped' == $order_status || 'updated-tracking' == $order_status || 'delivered' == $order_status || 'cancelled' == $order_status || 'refunded' == $order_status){          
    if ( 'processing' == $order_status && ( 'on-hold' == $order->status || 'pending' == $order->status || 'failed' == $order->status ) ){
        // Create customer in Ezrent   
        $customer_api = create_customer_api($first_name,$last_name,$email,$address_name,$address,$address_line_2,$city,$state,$phone_number);    
        $i = 0;    
        /*echo "order status------".$order_status;
        echo '<br>';
        echo "customer_api------";
        print_r($customer_api);
        echo '<br>';*/
        
        
        foreach ( $order->get_items() as $item_id => $item ) {

            $from_dated = wc_get_order_item_meta( $item_id, 'Rent From Date', true ); 
            $to_dated = wc_get_order_item_meta( $item_id, 'Rent To Date', true );            
           

            $datetime = DateTime::createFromFormat('m/d/Y', $from_dated);
            $from_date =  $datetime->format('m/d/Y');
           /* echo '<br>';
            echo "from_date------";
            print_r($from_date);
            echo '<br>';*/
            
            $datetimed = DateTime::createFromFormat('m/d/Y', $to_dated);
            $to_date =  $datetimed->format('m/d/Y');
            
            // $bill_from_date = date('Y/m/d', strtotime($from_date. ' + 2 days'));
            // $bill_to_date = date('Y/m/d', strtotime($to_date. ' - 2 days'));
            $bill_from_date = date('m/d/Y', strtotime($from_date));
            $bill_to_date = date('m/d/Y', strtotime($to_date));
            $one_day_prior_date_of_order = date('m/d/Y', strtotime($to_date. ' -1 days'));
            /*echo '<br>';
            echo "one_day_prior_date_of_order------";
            print_r($one_day_prior_date_of_order);
            echo '<br>';
            exit;*/
            $asset_ids = get_post_meta($item['product_id'], 'ez_sequence_num', true);
            $current_user_id =  get_current_user_id();
            $customer_id = get_user_meta( $current_user_id , 'ez_id' , true );            

            if($customer_api['success'] == 1){                
                $api_customer_id = $customer_api['customer']['id'];
            }else{                
                $api_customer_id = $customer_id;
            }
           
            /*echo "api_customer_id------";
            print_r($api_customer_id);
            echo '<br>';
            echo "from_date------";
            print_r($from_date);
            echo '<br>';
            echo "expected_checkout_time------";
            print_r($expected_checkout_time);
            echo '<br>';
            echo "to_date------";
            print_r($to_date);
            echo '<br>';
            echo "start_time------";
            print_r($start_time);
            echo '<br>';
            echo "bill_from_date------";
            print_r($bill_from_date);
            echo '<br>';
            echo "asset_ids------";
            print_r($asset_ids);
            echo '<br>';*/
           
            // Order status Draft
            $api_orders = create_order_api($api_customer_id,$from_date,$expected_checkout_time,$to_date,$start_time,$bill_from_date,$bill_to_date,$asset_ids); 
            
            /*echo "api_orders------";
            print_r($api_orders);
            echo '<br>';
            exit;*/
            $api_order_id = $api_orders['sequence_num'];  
            $api_order_message = $api_orders['message'];  
                         
            if(!empty($api_order_id)){
                // Order status booked if status == 1 
                $order_book_status = order_book_api($api_order_id,$from_date,$to_date); 
                /*echo "order_book_status------";
                print_r($order_book_status);
                echo '<br>'; */
                // exit;
                update_post_meta($order_id, 'from_date', $from_date);
                update_post_meta($order_id, 'to_date', $to_date);
                update_post_meta($order_id, 'one_day_prior_date_of_order', $one_day_prior_date_of_order);
                if($order_book_status['status'] == 1){ 
                    return $order_status;    
                }/*else{
                   return $order_status = 'wc-failed'; 
                }*/
            }else{
                echo $api_order_message;
                
                return $order_status = 'wc-failed';
            }          
        }        
        //$i++;
        //echo $i;
    }
    return $order_status;
    //return $order_status = 'processing';
}


/*
* Add extra text near shipping label on cart page and checkout page
*/
add_filter( 'woocommerce_shipping_package_name', 'ez_rentout_shipping_package_name' );
function ez_rentout_shipping_package_name( $name ) {
  return 'Shipping <p class="shipping-small" style="font-size: 12px;color: #888;">Included freight both ways and we will send a waybill for the return as well with the package.</p>';
}

/*
* Update cart total base on week count
week_between_two_dates() this function in plugin fuction.php
*/
function ez_rentout_before_calculate_totals( $cart_object ) {    
    foreach ( $cart_object->cart_contents as $key => $value ) {
        
        if( isset( $value['product_id'] ) ) :
            
            $monthly_price=get_post_meta($value['product_id'],'monthly_price',true);            
            $from_date = $value['custom_data']['from_date'];
            $to_date = $value['custom_data']['to_date'];
            $weeks = week_between_two_dates($from_date, $to_date);
            //echo "Weeks....".$weeks.'<br>';
            
            if($weeks % 4 === 0){
              $months = $weeks/4;
              //echo "monthsss...".$months.'<br>';
              $price = $monthly_price * $months;
            }else{
              $month = $weeks/4;
              $week = fmod($weeks,4);

              $weekly_price = floatval( $value['data']->get_price() );

              $month_price = $monthly_price * (int)$month;
              $week_price = $weekly_price * $week;
              $price = $month_price + $week_price;
              // echo "month...".(int)$month.'<br>';
              // echo '<br>';
              // echo "week...".$week.'<br>';             
              
            }
            //$orgPrice = floatval( $value['data']->get_price() );
            //$discPrice = $orgPrice * $weeks;
            $value['data']->set_price($price);
            //$value['data']->set_price();
            global $woocommerce;
            $woocommerce->cart->set_session();
        endif;
    }

    remove_action( 'woocommerce_before_calculate_totals', 'ez_rentout_before_calculate_totals' ); 
}
add_action( 'woocommerce_before_calculate_totals', 'ez_rentout_before_calculate_totals' );


/*
* Add Monthly Price in backend
*/
add_action( 'woocommerce_product_options_pricing', 'ez_rentout_custom_price_field' );

function ez_rentout_custom_price_field() {
  
  $field = array(
    'id' => 'monthly_price',
    'label' => __( 'Monthly Price', 'textdomain' ),
    'data_type' => 'price' //Let WooCommerce formats our field as price field
  );
  
  woocommerce_wp_text_input( $field );
}

/*
* Add Per week after price
*/

/*function ez_rentout_change_product_price_display( $price ) {
    $price .= ' Per Week';
    return $price;
}
add_filter( 'woocommerce_get_price_html', 'ez_rentout_change_product_price_display' );
add_filter( 'woocommerce_cart_item_price', 'ez_rentout_change_product_price_display' );*/

/*
* Displaying the value on single product pages
*/
function ez_rentout_product_montly_price($product_id) {
    $product = get_product();   
    $product_id = $product->id;
    $ez_available_for_sale = get_post_meta( $product_id, 'ez_available_for_sale', true );

    if(is_user_logged_in() && $ez_available_for_sale == 'yes'){        
        $monthly_price = get_post_meta(get_the_ID(),'monthly_price', true);   
        $monthly_price = $monthly_price ? get_woocommerce_currency_symbol().$monthly_price.' Per Month' : '';
        echo '<p class="per_month">'.$monthly_price.'</p>';  
    }
    
}
add_action('woocommerce_single_product_summary', 'ez_rentout_product_montly_price',15);

add_action( 'woocommerce_single_product_summary', 'custom_text', 14 );
function custom_text() {
    $product = get_product();   
    $product_id = $product->id;
    $ez_available_for_sale = get_post_meta( $product_id, 'ez_available_for_sale', true );
    if(is_user_logged_in() && $ez_available_for_sale == 'yes'){        
        print '<p class="per_week">Per Week</p>';  
    }
}

add_filter( 'post_date_column_time' , 'woo_custom_post_date_column_time' );
function woo_custom_post_date_column_time( $post ) {
    $h_time = get_the_time( __( 'm/d/Y', 'woocommerce' ), $post );
    return $h_time;
}


/*function western_custom_buy_buttons(){

   $product = get_product();   
   $product_id = $product->id;
   $ez_available_for_sale = get_post_meta( $product_id, 'ez_available_for_sale', true );

   if ( $ez_available_for_sale == 'no') {

       // removing the purchase buttons

       remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );

       remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );

       remove_action( 'woocommerce_simple_add_to_cart', 'woocommerce_simple_add_to_cart', 30 );

       remove_action( 'woocommerce_grouped_add_to_cart', 'woocommerce_grouped_add_to_cart', 30 );

       remove_action( 'woocommerce_variable_add_to_cart', 'woocommerce_variable_add_to_cart', 30 );

       remove_action( 'woocommerce_external_add_to_cart', 'woocommerce_external_add_to_cart', 30 );

   }

}

add_action( 'wp', 'western_custom_buy_buttons' );*/