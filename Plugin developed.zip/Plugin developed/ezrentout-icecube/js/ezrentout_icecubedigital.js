jQuery(function() {    
    //var disabledArr = '[ { "from": "2/12/2019", "to": "8/12/2019" }, { "from": "11/12/2019", "to": "16/12/2019" } ]';
    //jQuery( ".single-product-details .woocommerce-Price-amount.amount" ).after( " Per Week" );
    var disabledArr = jQuery('.booked_date_array').val();    

    var disabledArr = jQuery.parseJSON(disabledArr);
    if(disabledArr != null && disabledArr !== undefined){

    jQuery("#from_date, #to_date, #admin_from_date, #admin_to_date").datepicker({
            numberOfMonths: 1,
            //minDate: 0,
            dateFormat: 'mm/dd/yy',
            // May be used to "force" the 12 months calendar to display 2016
            //minDate: new Date(2016, 1 -1, 1),
            //maxDate: new Date(2016, 12 -1, 31),
            
            beforeShowDay: function(date){
                //console.log(date);
                
                // For each calendar date, check if it is within a disabled range.
                for(i=0;i<disabledArr.length;i++){
                    // Get each from/to ranges                    
                    var From = disabledArr[i].from.split("/");
                    var To = disabledArr[i].to.split("/");
                    // Format them as dates : Year, Month (zero-based), Date
                    /*var FromDate = new Date(From[2],From[1]-1,From[0]);
                    var ToDate = new Date(To[2],To[1]-1,To[0]);*/

                    var FromDate = new Date(From[0],From[1]-1,From[2]);
                    var ToDate = new Date(To[0],To[1]-1,To[2]);

                    // Set a flag to be used when found
                    var found=false;
                    // Compare date
                    if(date>=FromDate && date<=ToDate){
                        found=true;
                        return [false, "red"]; // Return false (disabled) and the "red" class.
                    }
                }
                
                //At the end of the for loop, if the date wasn't found, return true.
                if(!found){
                    return [true, ""]; // Return true (Not disabled) and no class.
                }
            }
        });
    }else{
        
        jQuery("#from_date, #to_date, #admin_from_date, #admin_to_date").datepicker({
            numberOfMonths: 1,
            //minDate: 0,
            dateFormat: 'mm/dd/yy',
        });
    }

});