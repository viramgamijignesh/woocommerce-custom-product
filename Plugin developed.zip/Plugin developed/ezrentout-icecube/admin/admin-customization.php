<?php
add_action('woocommerce_order_actions', 'ez_rentout_wc_order_action', 10, 1);
function ez_rentout_wc_order_action($actions)
{
    
    if (is_array($actions)) {
        $actions['re_order_action'] = __('Re Order');
    }
    
    return $actions;
    
}

/**
 * Filter name is woocommerce_order_action_{$action_slug}
 */
add_action('woocommerce_order_action_re_order_action', 'ez_rentout_re_order_action');
function ez_rentout_re_order_action($order)
{
    
    
    if (isset($_POST)) {
        $admin_from_date = $_POST['admin_from_date'];
        $admin_to_date   = $_POST['admin_to_date'];

        
    } else {
        $admin_from_date = '';
        $admin_to_date   = '';
        $admin_expected_ship_date   = '';
    }
    
    $order_data = $order->get_data(); // The Order data
    
    $items = $order->get_items();
    
    //$order_id = $order_data['id'];
    $order_parent_id            = $order_data['parent_id'];
    $order_status               = $order_data['status'];
    $order_currency             = $order_data['currency'];
    $order_version              = $order_data['version'];
    $order_payment_method       = $order_data['payment_method'];
    $order_payment_method_title = $order_data['payment_method_title'];
    $order_payment_method       = $order_data['payment_method'];
    $order_payment_method       = $order_data['payment_method'];
    
    ## Creation and modified WC_DateTime Object date string ##
    
    // Using a formated date ( with php date() function as method)
    $order_date_created  = $order_data['date_created']->date('Y-m-d H:i:s');
    $order_date_modified = $order_data['date_modified']->date('Y-m-d H:i:s');
    
    // Using a timestamp ( with php getTimestamp() function as method)
    $order_timestamp_created  = $order_data['date_created']->getTimestamp();
    $order_timestamp_modified = $order_data['date_modified']->getTimestamp();
    
    $order_discount_total = $order_data['discount_total'];
    $order_discount_tax   = $order_data['discount_tax'];
    $order_shipping_total = $order_data['shipping_total'];
    $order_shipping_tax   = $order_data['shipping_tax'];
    $order_total          = $order_data['cart_tax'];
    $order_total_tax      = $order_data['total_tax'];
    $order_customer_id    = $order_data['customer_id']; // ... and so on
    
    ## BILLING INFORMATION:
    
    $order_billing_first_name = $order_data['billing']['first_name'];
    $order_billing_last_name  = $order_data['billing']['last_name'];
    $order_billing_company    = $order_data['billing']['company'];
    $order_billing_address_1  = $order_data['billing']['address_1'];
    $order_billing_address_2  = $order_data['billing']['address_2'];
    $order_billing_city       = $order_data['billing']['city'];
    $order_billing_state      = $order_data['billing']['state'];
    $order_billing_postcode   = $order_data['billing']['postcode'];
    $order_billing_country    = $order_data['billing']['country'];
    $order_billing_email      = $order_data['billing']['email'];
    $order_billing_phone      = $order_data['billing']['phone'];
    
    ## SHIPPING INFORMATION:
    
    $order_shipping_first_name = $order_data['shipping']['first_name'];
    $order_shipping_last_name  = $order_data['shipping']['last_name'];
    $order_shipping_company    = $order_data['shipping']['company'];
    $order_shipping_address_1  = $order_data['shipping']['address_1'];
    $order_shipping_address_2  = $order_data['shipping']['address_2'];
    $order_shipping_city       = $order_data['shipping']['city'];
    $order_shipping_state      = $order_data['shipping']['state'];
    $order_shipping_postcode   = $order_data['shipping']['postcode'];
    $order_shipping_country    = $order_data['shipping']['country'];
    
    
    ## ORDER META FIELDS
    
    
    $parent_id      = $order_data['parent_id'];
    $status         = $order_data['status'];
    $currency       = $order_data['currency'];
    $discount_total = $order_data['discount_total'];
    $discount_tax   = $order_data['discount_tax'];
    $cart_hash      = $order_data['cart_hash'];
    $cart_hash      = $order_data['cart_hash'];
    
    $_payment_method       = $order_data['payment_method'];
    $_payment_method_title = $order_data['payment_method_title'];
    $cart_hash             = $order_data['cart_hash'];
    $customer_ip_address   = $order_data['customer_ip_address'];
    $customer_user_agent   = $order_data['customer_user_agent'];
    $created_via           = $order_data['created_via'];
    $customer_note         = $order_data['customer_note'];
    $date_completed        = $order_data['date_completed'];
    $date_paid             = $order_data['date_paid'];
    $_cart_hash            = $order_data['cart_hash'];
    $payment_method        = $order_data['payment_method'];
    $_created_via          = $order_data['_created_via'];
    
    $current_order_id = $order_data['id'];
    
    $rent_from_date                         = get_post_meta($current_order_id, 'Rent From Date', true);
    $rent_to_date                           = get_post_meta($current_order_id, 'Rent To Date', true);
    $_customer_signature                    = get_post_meta($current_order_id, '_customer-signature', true);
    $_woo_ufdc_uploaded_file_path_1         = get_post_meta($current_order_id, '_woo_ufdc_uploaded_file_path_1', true);
    $_woo_ufdc_uploaded_file_name_1         = get_post_meta($current_order_id, '_woo_ufdc_uploaded_file_name_1', true);
    $_woo_ufdc_uploaded_product_name_1      = get_post_meta($current_order_id, '_woo_ufdc_uploaded_product_name_1', true);
    $_customer_signature_custom_field_title = get_post_meta($current_order_id, '_customer-signature-custom-field-title', true);
    $to_date                                = get_post_meta($current_order_id, 'to_date', true);
    $one_day_prior_date_of_order            = get_post_meta($current_order_id, 'one_day_prior_date_of_order', true);
    $_wcpdf_invoice_settings                = get_post_meta($current_order_id, '_wcpdf_invoice_settings', true);
    $_wcpdf_invoice_date                    = get_post_meta($current_order_id, '_wcpdf_invoice_date', true);
    $_wcpdf_invoice_date_formatted          = get_post_meta($current_order_id, '_wcpdf_invoice_date_formatted', true);
    $_wcpdf_invoice_number                  = get_post_meta($current_order_id, '_wcpdf_invoice_number', true);
    $_wcpdf_invoice_number_data             = get_post_meta($current_order_id, '_wcpdf_invoice_number_data', true);
    $_woo_ufdc_uploaded_product_name_1      = get_post_meta($current_order_id, '_woo_ufdc_uploaded_product_name_1', true);  
    
    
    $billing_address = array(
        'first_name' => $order_billing_first_name,
        'last_name' => $order_billing_last_name,
        'company' => $order_billing_company,
        'email' => $order_billing_email,
        'phone' => $order_billing_phone,
        'address_1' => $order_billing_address_1,
        'address_2' => $order_billing_address_2,
        'city' => $order_billing_city,
        'state' => $order_shipping_state,
        'postcode' => $order_billing_postcode,
        'country' => $order_billing_country
    );
    
    $shipping_address = array(
        'first_name' => $order_shipping_first_name,
        'last_name' => $order_shipping_last_name,
        'company' => $order_shipping_company,        
        'address_1' => $order_shipping_address_1,
        'address_2' => $order_shipping_address_2,
        'city' => $order_shipping_city,
        'state' => $order_shipping_state,
        'postcode' => $order_shipping_postcode,
        'country' => $order_shipping_country
    );
    
    // Now we create the order
    $order = wc_create_order();

    foreach ($items as $item) {
        
        $product = wc_get_product($item['product_id']);
        $item_id = $item['item_id'];
        $product_id = $product->get_id();        
        $from_dated                  = $admin_from_date;
        $to_dated                    = $admin_to_date;
        $datetime                    = DateTime::createFromFormat('m/d/Y', $from_dated);
        $from_date                   = $datetime->format('m/d/Y');
        $datetimed                   = DateTime::createFromFormat('m/d/Y', $to_dated);
        $to_date                     = $datetimed->format('m/d/Y');
        $bill_from_date              = date('m/d/Y', strtotime($from_date));
        $bill_to_date                = date('m/d/Y', strtotime($to_date));
        $one_day_prior_date_of_order = date('m/d/Y', strtotime($to_date . ' -1 days'));
        $asset_ids                   = get_post_meta($item['product_id'], 'ez_sequence_num', true);        
        $customer_id                 = get_user_meta($order_customer_id, 'ez_id', true);        
        $api_customer_id = $customer_id;
        $quantity = 1;
        $product->get_price();
        $monthly_price = get_post_meta($product_id, 'monthly_price', true);
        $from_date     = $admin_from_date;
        $to_date       = $admin_to_date;
        $weeks         = week_between_two_dates($from_date, $to_date);

        if ($weeks % 4 === 0) {
            $months = $weeks / 4;
            $price  = $monthly_price * $months;
        } else {
            $month = $weeks / 4;
            $week  = fmod($weeks, 4);
            
            $weekly_price = floatval($product->get_price());
            $month_price  = $monthly_price * (int) $month;
            $week_price   = $weekly_price * $week;
            $price        = $month_price + $week_price;
            
        }
        $args = array(
            'subtotal' => $price, // e.g. 32.95
            'total' => $price // e.g. 32.95
        );
        $order->add_product(get_product($product_id), $quantity, $args);
        $order->calculate_totals($price);
        $order->update_status("wc-processing", 'Imported order', TRUE);
        $order->set_address($billing_address, 'billing');
        $order->set_address($shipping_address, 'shipping');
        // Order status Draft
        $api_orders = create_order_api($api_customer_id, $from_date, $expected_checkout_time, $to_date, $start_time, $bill_from_date, $bill_to_date, $asset_ids);
        
        
        $api_order_id      = $api_orders['sequence_num'];
        $api_order_message = $api_orders['message'];
        
        if (!empty($api_order_id)) {
            // Order status booked if status == 1 
            $order_book_status = order_book_api($api_order_id, $from_date, $to_date);
            update_post_meta($order_id, 'from_date', $from_date);
            update_post_meta($order_id, 'to_date', $to_date);
            update_post_meta($order_id, 'one_day_prior_date_of_order', $one_day_prior_date_of_order);
            if ($order_book_status['status'] == 1) {
                return $order_status;
            }
        }
    }
    
    update_post_meta($order->id, '_customer_user', $order_customer_id);
    update_post_meta($order->id, '_woo_ufdc_uploaded_file_name_1', $_woo_ufdc_uploaded_file_name_1);
    update_post_meta($order->id, '_woo_ufdc_uploaded_file_path_1', $_woo_ufdc_uploaded_file_path_1);
    update_post_meta($order->id, '_woo_ufdc_uploaded_product_name_1', $_woo_ufdc_uploaded_product_name_1);
    update_post_meta($order->id, '_payment_method', $_payment_method);
    update_post_meta($order->id, '_payment_method_title', $_payment_method_title);
    update_post_meta($order->id, '_cart_hash', $_cart_hash);
    update_post_meta($order->id, '_customer-signature', $_customer_signature);
    update_post_meta($order->id, '_customer-signature-custom-field-title', $_customer_signature_custom_field_title);
    update_post_meta($order->id, '_created_via', $_created_via);
    update_post_meta($order->id, '_wcpdf_invoice_settings', $_wcpdf_invoice_settings);
    update_post_meta($order->id, '_wcpdf_invoice_date', $_wcpdf_invoice_date);
    update_post_meta($order->id, '_wcpdf_invoice_date_formatted ', $_wcpdf_invoice_date_formatted);
    update_post_meta($order->id, '_wcpdf_invoice_number', $_wcpdf_invoice_number);
    update_post_meta($order->id, '_wcpdf_invoice_number_data', $_wcpdf_invoice_number_data);
    update_post_meta($order->id, '_woo_ufdc_uploaded_product_name_1', $_woo_ufdc_uploaded_product_name_1);    

}

function make_orders_editable($is_editable, $order)
{
    // Allow only for admin and moderators
    if (current_user_can("manage_options")) {
        return true;
    }
}
//add_filter( 'wc_order_is_editable', 'make_orders_editable', 10, 2 );

function add_order_item_meta($item_id, $values)
{
    if (isset($_POST)) {
        $admin_from_date = $_POST['admin_from_date'];
        $admin_to_date   = $_POST['admin_to_date'];
    } else {
        $admin_from_date = '';
        $admin_to_date   = '';
    }
    $key   = 'Rent From Date'; // Define your key here
    $value = $admin_from_date; // Get your value here
    woocommerce_add_order_item_meta($item_id, $key, $value);
}
add_action('woocommerce_add_order_item_meta', 'add_order_item_meta', 10, 2);

function add_order_item_meta_2($item_id, $values)
{
    if (isset($_POST)) {
        $admin_from_date = $_POST['admin_from_date'];
        $admin_to_date   = $_POST['admin_to_date'];
    } else {
        $admin_from_date = '';
        $admin_to_date   = '';
    }
    $key   = 'Rent To Date'; // Define your key here
    $value = $admin_to_date; // Get your value here
    woocommerce_add_order_item_meta($item_id, $key, $value);
}
add_action('woocommerce_add_order_item_meta', 'add_order_item_meta_2', 10, 2);

function add_order_item_meta_3($item_id, $values)
{
    if (isset($_POST)) {
    	$wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );    
        $buffer_time = $wp_setting_ezrentout_settings['wp_setting_text_field_shipping_buffer_time'];
        $buffer_day = date('Y-m-d', strtotime($admin_from_date. ' - '.$buffer_time.' days'));        
        $buffer_days = date("m/d/Y", strtotime($buffer_day));   
        $admin_expected_ship_date   = $buffer_days;  
    } else {
        $admin_expected_ship_date = '';        
    }
    $key   = 'Expected Ship Date'; // Define your key here
    $value = $admin_expected_ship_date; // Get your value here
    woocommerce_add_order_item_meta($item_id, $key, $value);
}
//add_action('woocommerce_add_order_item_meta', 'add_order_item_meta_3', 10, 2);


add_action('woocommerce_before_order_itemmeta', 'so_32457241_before_order_itemmeta', 10, 3);
function so_32457241_before_order_itemmeta($item_id, $item, $product)
{
    
    //global $product;
    $id           = $product->id;
    $identifier   = get_post_meta($id, 'ez_identifier', true);
    $sequence_num = get_post_meta($id, 'ez_sequence_num', true);
    //$data           = get_order_detail($identifier);   
    $booked_dates = get_booked_dates($sequence_num);
    
    
    if ($booked_dates) {
        foreach ($booked_dates as $key => $booked_date) {
            $dt                            = new \DateTime($booked_date['from']);
            $booked_from_date              = $dt->format('Y/m/d');
            //$booked_date_arr[$key]['from'] = date('Y/m/d', strtotime($booked_from_date. ' - 2 days'));
            $booked_date_arr[$key]['from'] = date('Y/m/d', strtotime($booked_from_date));
            
            $dt2                         = new \DateTime($booked_date['to']);
            $booked_to_date              = $dt2->format('Y/m/d');
            $booked_date_arr[$key]['to'] = date('Y/m/d', strtotime($booked_to_date . ' + 4 days'));
            
            //exit;
            
        }
        
        $booked_date_array = json_encode($booked_date_arr);
        if ($booked_date_array) {
            echo "<input type=hidden name=booked_date_array value='" . stripslashes($booked_date_array) . "'  class=booked_date_array id=booked_date_array>";
        }
        //echo $check_availibity_html = '<a id="ezr-cart-widget-item-' . $sequence_num . '" onclick="ezrLoadCalendarDialog(' . $sequence_num . ', this)" href="#_">Availability Calendar</a>';
    }
    //woocommerce_add_order_item_meta($item_id, 'admin_from_date', $admin_from_date);
    //woocommerce_add_order_item_meta($item_id, 'admin_to_date', $to_from_date);
?>
    <table class="booked_dates">
    <tr>
      <td>
        <?php
    _e("From:", "aoim");
    
?>
     </td>
      <td>
        <input type = "text" name = "admin_from_date" id = "admin_from_date" class="datepicker" autocomplete="off" placeholder = "Select From Date" >
      </td>
    </tr>
    <tr>
      <td>
        <?php
    _e("To:", "aoim");
?>
     </td>
      <td>
        <input type = "text" name = "admin_to_date" id = "admin_to_date" class="datepicker" autocomplete="off" placeholder = "Select To Date" >
        <input type = "hidden" name = "admin_expected_ship_date" id = "admin_expected_ship_date" class="datepicker" autocomplete="off" placeholder = "Select To Date" >
      </td>      
    </tr>    
  </table>
    <?php
    remove_action('woocommerce_before_order_itemmeta', 'so_32457241_before_order_itemmeta', 10, 3);
}

/*// Display Fields
add_action('woocommerce_product_options_general_product_data', 'woocommerce_product_custom_fields');
// Save Fields
add_action('woocommerce_process_product_meta', 'woocommerce_product_custom_fields_save');
function woocommerce_product_custom_fields()
{
    global $woocommerce, $post;
    echo '<div class="product_custom_field">';
    // Custom Product Text Field
    woocommerce_wp_text_input(
        array(
            'id' => '_custom_product_text_field',
            'placeholder' => 'Custom Product Text Field',
            'label' => __('Custom Product Text Field', 'woocommerce'),
            'desc_tip' => 'true'
        )
    );
    //Custom Product Number Field
    woocommerce_wp_text_input(
        array(
            'id' => '_custom_product_number_field',
            'placeholder' => 'Custom Product Number Field',
            'label' => __('Custom Product Number Field', 'woocommerce'),
            'type' => 'number',
            'custom_attributes' => array(
                'step' => 'any',
                'min' => '0'
            )
        )
    );
    //Custom Product  Textarea
    woocommerce_wp_textarea_input(
        array(
            'id' => '_custom_product_textarea',
            'placeholder' => 'Custom Product Textarea',
            'label' => __('Custom Product Textarea', 'woocommerce')
        )
    );
    echo '</div>';
}

// Following code Saves  WooCommerce Product Custom Fields
add_action( 'woocommerce_process_product_meta', 'woocommerce_product_custom_fields_save' );

function woocommerce_product_custom_fields_save($post_id)
{
    // Custom Product Text Field
    $woocommerce_custom_product_text_field = $_POST['_custom_product_text_field'];
    if (!empty($woocommerce_custom_product_text_field))
        update_post_meta($post_id, '_custom_product_text_field', esc_attr($woocommerce_custom_product_text_field));
// Custom Product Number Field
    $woocommerce_custom_product_number_field = $_POST['_custom_product_number_field'];
    if (!empty($woocommerce_custom_product_number_field))
        update_post_meta($post_id, '_custom_product_number_field', esc_attr($woocommerce_custom_product_number_field));
// Custom Product Textarea Field
    $woocommerce_custom_procut_textarea = $_POST['_custom_product_textarea'];
    if (!empty($woocommerce_custom_procut_textarea))
        update_post_meta($post_id, '_custom_product_textarea', esc_html($woocommerce_custom_procut_textarea));
}*/

function woocommerce_product_custom_fields()
{
  

    woocommerce_wp_checkbox( 
    array( 
        'id'            => 'ez_available_for_sale', 
        'wrapper_class' => 'show_if_simple', 
        'label'         => __('Available for Rent', 'woocommerce' ), 
        'description'   => __( 'Check me!', 'woocommerce' ) 
        )
    );
}
 
add_action('woocommerce_product_options_general_product_data', 'woocommerce_product_custom_fields');

function save_woocommerce_product_custom_fields($post_id)
{
    $product = wc_get_product($post_id);
    //$custom_fields_woocommerce_title = update_post_meta( $post_id, 'ez_available_for_sale', true );

    $custom_fields_woocommerce_title = isset($_POST['ez_available_for_sale']) ? $_POST['ez_available_for_sale'] : '';   
    // if($custom_fields_woocommerce_title == 'yes' || $custom_fields_woocommerce_title == '1'){
    //     echo 'yes';
    // }else{
    //     echo 'no';
    // }
    $product->update_meta_data('ez_available_for_sale', sanitize_text_field($custom_fields_woocommerce_title));
    $product->save();
}
add_action('woocommerce_process_product_meta', 'save_woocommerce_product_custom_fields');

function woocommerce_custom_fields_display()
{
  global $post;
  $product = wc_get_product($post->ID);
    $custom_fields_woocommerce_title = $product->get_meta('ez_available_for_sale');
  if ($custom_fields_woocommerce_title) {
      printf(
            '<div><label>%s</label><input type="text" id="woocommerce_product_custom_fields_title" name="woocommerce_product_custom_fields_title" value=""></div>',
            esc_html($custom_fields_woocommerce_title)
      );
  }
}
 
//add_action('woocommerce_before_add_to_cart_button', 'woocommerce_custom_fields_display');



// New order notification only for "Pending" Order status
// New order notification only for "Pending" Order status
/*add_action( 'woocommerce_checkout_order_processing', 'pending_new_order_notification', 20, 1 );
function pending_new_order_notification( $order_id ) {

    // Get an instance of the WC_Order object
    $order = wc_get_order( $order_id );

    // Only for "pending" order status
    if( ! $order->has_status( 'pending' ) ) return;

    // Send "New Email" notification (to admin)
    WC()->mailer()->get_emails()['WC_Email_New_Order']->trigger( $order_id );
}*/


//add_action( 'woocommerce_order_status_processing', 'bbloomer_status_custom_notification', 20, 2 );
  
function bbloomer_status_custom_notification( $order_id, $order ) {
      
    $heading = 'Order Custom Processing';
    $subject = 'Order Custom Processing';
  
    // Get WooCommerce email objects
    $mailer = WC()->mailer()->get_emails();
  
    // Use one of the active emails e.g. "Customer_Completed_Order"
    // Wont work if you choose an object that is not active
    // Assign heading & subject to chosen object
    $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
    $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
  
    // Send the email with custom heading & subject
    $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_id );
  
    // To add email content use https://businessbloomer.com/woocommerce-add-extra-content-order-email/
    // You have to use the email ID chosen above and also that $order->get_status() == "refused"
      
}

//add_action( 'woocommerce_order_actions', 'ulmh_resend1' );
function ulmh_resend1( $actions ) {
    $actions['ulmh_resend'] = __( 'Resend Email', 'text_domain' );
    return $actions;
}

//add_action( 'woocommerce_order_action_ulmh_resend', 'ulmh_resend2' );
function ulmh_resend2( $order ) {
    $wc_emails = WC()->mailer()->get_emails();
    if( empty( $wc_emails ) ) return;

    if ($order->has_status( 'on-hold' ))
        $email_id = 'customer_on_hold_order';
    elseif ($order->has_status( 'processing' ))
        $email_id = 'customer_processing_order';
    elseif ($order->has_status( 'completed' ))
        $email_id = 'customer_completed_order';
    else
        $email_id = "nothing";

    foreach ( $wc_emails as $wc_mail )
        if ( $wc_mail->id == $email_id )
            $wc_mail->trigger( $order->get_id() );
}

//add_filter( 'woocommerce_resend_order_emails_available', 'ulmh_resend3' );
function ulmh_resend3( $order_emails ) {
    $remove = array( 'new_order', 'cancelled_order', 'customer_processing_order', 'customer_completed_order', 'customer_invoice' );
    $order_emails = array_diff( $order_emails, $remove );
    return $order_emails;
}