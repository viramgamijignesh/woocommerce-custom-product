<?php
/**
 * Plugin Name: Ezrentout Icecubedigital
 * Plugin URI: https://www.icecubedigital.com/
 * Description: Import product from Exrentout to woocommerce [https://leaseml.com/]
 * Version: 1.0
 * Author: Icecubedigital WordPress Team
 * Author URI: https://www.icecubedigital.com/
 */

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once(ABSPATH . "wp-includes/pluggable.php"); // fix login error when run this script
require_once ABSPATH . 'wp-admin/includes/import.php';


require_once 'wp-admin-setting-api.php';
require_once 'function.php';
require_once 'woo-customization.php';
require_once 'admin/admin-customization.php';
     
add_action('wc_ezrent_out_import_all_product_action_hook', 'wc_ezrent_out_import_all_product_function');
function wc_ezrent_out_import_all_product_function(){
    // it will run    
    require_once 'all-api.php';
    wc_insert_term_product();

}

add_action('wp_enqueue_scripts','ezrentout_icecubedigital_front_script');

function ezrentout_icecubedigital_front_script() {
    
    wp_enqueue_style( 'ezrentout-icecubedigital-css', plugins_url( 'css/ezrentout_icecubedigital.css', __FILE__ ));     
    wp_enqueue_style( 'ezrentout-icecubedigital-jquery-ui-css', plugins_url( 'css/jquery-ui.css', __FILE__ ));      
    
    wp_enqueue_script('ezrentout-icecubedigital-js', plugins_url('js/ezrentout_icecubedigital.js', __FILE__), array('jquery'), '1.1.0', true ); 
    wp_enqueue_script('ezrentout-icecubedigital-jquery-ui', plugins_url('js/jquery-ui.js', __FILE__), array('jquery'), '1.0.0', true );    
    
}

add_action( 'wp_loaded', 'register_all_scripts' );

add_action( 'admin_enqueue_scripts', 'ezrentout_icecubedigital_admin_script' );
function ezrentout_icecubedigital_admin_script() {
    
    wp_enqueue_style( 'ezrentout-icecubedigital-css', plugins_url( 'css/ezrentout_icecubedigital.css', __FILE__ ));     
    wp_enqueue_style( 'ezrentout-icecubedigital-jquery-ui-css', plugins_url( 'css/jquery-ui.css', __FILE__ ));      
    
    wp_enqueue_script('ezrentout-icecubedigital-js', plugins_url('js/ezrentout_icecubedigital.js', __FILE__), array('jquery'), '1.1.0', true ); 
    wp_enqueue_script('ezrentout-icecubedigital-jquery-ui', plugins_url('js/jquery-ui.js', __FILE__), array('jquery'), '1.0.0', true );    
    
}
/*
* Custom Confirmation email to include expected ship date
*/
add_action( 'woocommerce_order_status_processing', 'ezrentout_status_custom_notification', 20, 2 );
  
function ezrentout_status_custom_notification( $order_id, $order ) {
      
    $heading = 'Order expected ship date';
    $subject = 'Order expected ship date';
    //add_action( 'woocommerce_email_order_meta', 'ts_email', 10, 4 );   
    $mailer = WC()->mailer()->get_emails();
    $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
    $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
    $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_id );   

}

//add_action( 'wc_ezrent_out_one_day_prior_cron_send_email_hook', 'wc_ezrent_out_one_day_prior_cron_send_email_action',20, 2 );

function wc_ezrent_out_one_day_prior_cron_send_email_action( $order_id, $order ){
    
    
    wp_mail( 'jignesh@icecubedigital.com', 'email_subject', "test" );
    $filters = array(
        'post_status' => 'wc-delivered', // change oerder status
        'post_type' => 'shop_order'
    );

    $loop = new WP_Query($filters);

    while ($loop->have_posts()) {
        $loop->the_post();
        $order = new WC_Order($loop->post->ID);
        wp_mail( 'jignesh@icecubedigital.com', 'email_subject', $loop->post->ID );
        $order_data = $order->get_data();            
        $_billing_email = $order_data['billing']['email'];        
        foreach ($order->get_items() as $item_id => $lineItem) {
            $_to_date = wc_get_order_item_meta( $item_id, '_to_date', true ); 
            $_product_id = wc_get_order_item_meta( $item_id, '_product_id', true );             
            $_before_one_day = date('Y/m/d',strtotime("-1 days"));            
            //if (strtotime($_before_one_day) == strtotime($_to_date)){                                  
                $heading = 'Reminder email 1 day prior to return date';
                $subject = 'Reminder email 1 day prior to return date';                
                $mailer = WC()->mailer()->get_emails();
                $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
                $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
                $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
                $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
                $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_id );   
            //}
        }
    }
}

add_action( 'ez_rentout_remainder_email_hook', 'ez_rentout_remainder_email_function' );
//add_action( 'init', 'ez_rentout_remainder_email_function' );
function ez_rentout_remainder_email_function() {      
    //wp_mail( 'jignesh@icecubedigital.com', 'email_subject', 'email_subject' );
    global $wpdb;
    $_current_date = date('Y/m/d'); 
    $result = $wpdb->get_results( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='one_day_prior_date_of_order' AND meta_value='%s'", $_current_date ) );


    foreach ($result as $key => $value) {
        $order_id =  $value->post_id;
        if ( $order_id ) {        
            $email_subject = "Reminder email 1 day prior to return date";
            $email_content = "Order IDs: " . $order_id;
            //wp_mail( 'jignesh@icecubedigital.com', $email_subject, $email_content );
            $heading = 'Reminder email 1 day prior to return date';
            $subject = 'Reminder email 1 day prior to return date';  
            $mailer = WC()->mailer()->get_emails();
            $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
            $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
            $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
            $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
            $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_id ); 
        }
        delete_post_meta($order_id, 'one_day_prior_date_of_order', $_current_date);  
    }  
}