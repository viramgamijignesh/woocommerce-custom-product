<?php
add_action( 'admin_menu', 'wp_setting_add_admin_menu' );
add_action( 'admin_init', 'wp_setting_ezrentout_init' );


function wp_setting_add_admin_menu(  ) { 

    add_menu_page( 'Ezrentout Setting ', 'Ezrentout Setting ', 'manage_options', 'wp_setting_', 'wp_setting_options_page' );

}


function wp_setting_ezrentout_init(  ) { 

    register_setting( 'pluginPage', 'wp_setting_ezrentout' );

    add_settings_section(
        'wp_setting_pluginPage_section', 
        __( '', 'wp setting' ), 
        'wp_setting_ezrentout_section_callback', 
        'pluginPage'
    );

    add_settings_field( 
        'wp_setting_text_field_tokken', 
        __( 'Ezrentout Token', 'wp setting' ), 
        'wp_setting_text_field_tokken_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_url', 
        __( 'Ezrentout Url', 'wp setting' ), 
        'wp_setting_text_field_url_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_insert_product_category', 
        __( 'Insert Product Category URL', 'wp setting' ), 
        'wp_setting_text_field_insert_product_category_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_insert_product', 
        __( 'Insert Product URL', 'wp setting' ), 
        'wp_setting_text_field_insert_product_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_insert_customer', 
        __( 'Insert Customer URL', 'wp setting' ), 
        'wp_setting_text_field_insert_customer_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_shipping_buffer_time', 
        __( 'Shipping Buffer Time[in Days]', 'wp setting' ), 
        'wp_setting_text_field_shipping_buffer_time_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_shipping_buffer_time_msg_checkbox', 
        __( 'Shipping Buffer Message Enable', 'wp setting' ), 
        'wp_setting_text_field_shipping_buffer_time_msg_checkobx_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );

    add_settings_field( 
        'wp_setting_text_field_shipping_buffer_time_msg', 
        __( 'Shipping Buffer Message', 'wp setting' ), 
        'wp_setting_text_field_shipping_buffer_time_msg_render', 
        'pluginPage', 
        'wp_setting_pluginPage_section' 
    );



    


}


function wp_setting_text_field_tokken_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_tokken = $options['wp_setting_text_field_tokken'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_tokken]' value='<?php echo $options['wp_setting_text_field_tokken']; ?>'>
    
    <?php

}

function wp_setting_text_field_url_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_tokken = $options['wp_setting_text_field_url'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_url]' value='<?php echo $options['wp_setting_text_field_url']; ?>'>
    
    <?php

}

function wp_setting_text_field_insert_product_category_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_insert_product_category = $options['wp_setting_text_field_insert_product_category'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_insert_product_category]' value='<?php echo $options['wp_setting_text_field_insert_product_category']; ?>'>
    <?php

}

function wp_setting_text_field_insert_product_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_insert_product = $options['wp_setting_text_field_insert_product'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_insert_product]' value='<?php echo $options['wp_setting_text_field_insert_product']; ?>'>
    <?php

}

function wp_setting_text_field_insert_customer_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_insert_customer = $options['wp_setting_text_field_insert_customer'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_insert_customer]' value='<?php echo $options['wp_setting_text_field_insert_customer']; ?>'>
    <?php

}

function wp_setting_text_field_shipping_buffer_time_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_shipping_buffer_time = $options['wp_setting_text_field_shipping_buffer_time'];
    ?>
    <input class="" type='number' style="width: 50%;" min="0" max="31" name='wp_setting_ezrentout[wp_setting_text_field_shipping_buffer_time]' value='<?php echo $options['wp_setting_text_field_shipping_buffer_time']; ?>'>
    <?php

}

function wp_setting_text_field_shipping_buffer_time_msg_checkobx_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_shipping_buffer_time_msg_checkbox = $options['wp_setting_text_field_shipping_buffer_time_msg_checkbox'];
    ?>
    
   
    <input class="" type="checkbox" name="wp_setting_ezrentout[wp_setting_text_field_shipping_buffer_time_msg_checkbox]" value="1"<?php checked( 1 == $options['wp_setting_text_field_shipping_buffer_time_msg_checkbox'] ); ?> />
    <?php

}

function wp_setting_text_field_shipping_buffer_time_msg_render(  ) { 

    $options = get_option( 'wp_setting_ezrentout' );
    $wp_setting_text_field_shipping_buffer_time_msg = $options['wp_setting_text_field_shipping_buffer_time_msg'];
    ?>
    <input class="setting-text-width" style="width: 50%;" type='text' name='wp_setting_ezrentout[wp_setting_text_field_shipping_buffer_time_msg]' value='<?php echo $options['wp_setting_text_field_shipping_buffer_time_msg']; ?>'>

    <?php

}

function wp_setting_ezrentout_section_callback(  ) { 

    echo __( '', 'wp setting' );

}


function wp_setting_options_page(  ) { 

        ?>
        <form action='options.php' method='post'>

            <h2>Ezrentout Setting </h2>

            <?php
            settings_fields( 'pluginPage' );
            do_settings_sections( 'pluginPage' );
            submit_button();
            ?>

        </form>
        <?php

}