<?php

function get_booked_dates($sequence_num){

    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );  
    $token = $wp_setting_ezrentout_settings['wp_setting_text_field_tokken'];
    $url = $wp_setting_ezrentout_settings['wp_setting_text_field_url'];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url.
        "assets/".$sequence_num."/booked_dates.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => array(
            "token: ".$token
        )
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:".$err;
    } else {
        $booked_dates_json_response = json_decode($response, true);       
        $booked_dates = $booked_dates_json_response['booked_dates'];        
    }
    return $booked_dates;
}
function create_customer_api($first_name,$last_name,$email,$address_name,$address,$address_line_2,$city,$state,$phone_number) {
    $curl = curl_init();

    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );  
    $token = $wp_setting_ezrentout_settings['wp_setting_text_field_tokken'];
    $url = $wp_setting_ezrentout_settings['wp_setting_text_field_url'];

    //$token = '1cb6e0b6954cc2d486321815552aaae9';
    $address_line_2 = $address;

    $POSTFIELDS = array('customer[first_name]' => $first_name, 'customer[last_name]' => $last_name, 'customer[email]' => $email, 'customer[address_name]' => $address_name, 'customer[address]' => $address, 'customer[address_line_2]' => $address_line_2, 'customer[city]' => $city, 'customer[state]' => $state, 'customer[phone_number]' => $phone_number);

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url."customers.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $POSTFIELDS,
        CURLOPT_HTTPHEADER => array(
            "token: ".$token
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:".$err;
    } else {
        //echo $response;
        $customer_api = json_decode($response, true);        
        $customers = $customer_api['customer'];  
        global $user;     

        foreach ($customer_api as $key => $value) {          
            $email = $value['email'];           
            $first_name = $value['first_name'];
            $last_name = $value['last_name'];
            $email = $value['email'];
            $email = get_user_by( 'email', $email );            
            $password = wp_generate_password();    
            if( ! $email ) {
                $user_id = wp_create_user( $first_name, $password, $email );
                foreach ($value as $key => $values) {
                    update_user_meta( $user->ID, "ez_".$key, $values );
                }                  
            }else{   
                
                foreach ($value as $key => $values) {
                    update_user_meta( get_current_user_id(), "ez_".$key, $values );
                }
            }
        }
        
        return $customer_api;

    }
}
function create_order_api($customer_id, $from_date, $expected_checkout_time = "23:59", $to_date, $start_time = "23:59", $bill_from_date, $bill_to_date, $asset_ids) {

    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );  
    $token = $wp_setting_ezrentout_settings['wp_setting_text_field_tokken'];
    $url = $wp_setting_ezrentout_settings['wp_setting_text_field_url'];

    //$url = 'https://millenniumleasing.ezrentout.com/';
    //$token = '1cb6e0b6954cc2d486321815552aaae9';
    $from_date = date("m/d/Y", strtotime($from_date));
    $to_date = date("m/d/Y", strtotime($to_date));

    $bill_from_date = date("m/d/Y", strtotime($bill_from_date));
    $bill_to_date = date("m/d/Y", strtotime($bill_to_date));
    // echo "from_date------";
    // print_r($from_date);
    // echo '<br>';
    // echo "to_date------";
    // print_r($to_date);
    // echo '<br>';
    
    $curl = curl_init();
    $POSTFIELDS = array('basket[customer_id]' => $customer_id, 'expected_checkout_date' => $from_date, 'expected_checkout_time' => '', 'due_date' => $to_date, 'start_time' => '', 'bill_from' => $bill_from_date, 'bill_to' => $bill_to_date, 'asset_ids' => $asset_ids);
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url."baskets.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $POSTFIELDS,
        CURLOPT_HTTPHEADER => array(
            "token: ".$token
        ),
    ));

    $order_response = curl_exec($curl);
    $err = curl_error($curl);
    /*echo '<pre>';
    print_r($order_response);
    echo '</pre>';*/
    curl_close($curl);

    if ($err) {
        echo "cURL Error #:".$err;
    } else {
        //echo $order_response;
         
        $order_response_json = json_decode($order_response, true);
        $order_crete_arry = $order_response_json['basket'];        
        return $order_crete_arry;
        /*$order_response_json = json_decode($order_response, true);
        $order_crete_arry = isset($order_response_json['success']) ? false : true; 
        if( $order_crete_arry ){
            $order_crete_arry = $order_response_json['basket'];                   
        }else{
            $order_crete_arry = $order_response_json['message'];          
        }
        return $order_crete_arry;*/

    }
}

function order_book_api($order_id, $from_date, $to_date) {
    $curl = curl_init();

    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );  
    $token = $wp_setting_ezrentout_settings['wp_setting_text_field_tokken'];
    $url = $wp_setting_ezrentout_settings['wp_setting_text_field_url'];

    //$url = 'https://millenniumleasing.ezrentout.com/';
    //$token = '1cb6e0b6954cc2d486321815552aaae9';
    $from_date = date("m/d/Y", strtotime($from_date));
    $to_date = date("m/d/Y", strtotime($to_date));
    $POSTFIELDS = array('from' => $from_date, 'to_date' => $to_date);

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url.
        "baskets/".$order_id.
        "/reservation.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PATCH",
        CURLOPT_POSTFIELDS => $POSTFIELDS,
        CURLOPT_HTTPHEADER => array(
            "token: ".$token
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:".$err;
    } else {
        //echo $response;
        $order_book_api_json = json_decode($response, true);
        return $order_book_api_json;
    }

}

function week_between_two_dates($date1, $date2)
{
    $first = DateTime::createFromFormat('m/d/Y', $date1);
    $second = DateTime::createFromFormat('m/d/Y', $date2);    
    $diff=date_diff($first,$second);
    $days= $diff->format("%a")+1;
    $week = $days/7;
    $week_diff = $week > ceil($week) ? ceil($week)+1 : ceil($week);
    return $week_diff;
}