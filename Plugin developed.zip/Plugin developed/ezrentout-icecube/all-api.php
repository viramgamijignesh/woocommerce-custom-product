<?php
   


add_action('wp_footer', 'wc_insert_term_product');

function wc_insert_term_product()
{ 

    // $url   = 'https://millenniumleasing.ezrentout.com/';
    // $token = '1cb6e0b6954cc2d486321815552aaae9';
    $wp_setting_ezrentout_settings = get_option( 'wp_setting_ezrentout' );  
    $token = $wp_setting_ezrentout_settings['wp_setting_text_field_tokken'];
    $url = $wp_setting_ezrentout_settings['wp_setting_text_field_url'];
    
    /* get all category api */
    
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url . "assets/classification_view.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "token: " . $token
        )
    ));
    
    $all_category_list = curl_exec($curl);
    $err              = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "assets/classification_view.api cURL Error #:" . $err;
    } else {
        $all_category_list_arr = json_decode($all_category_list, true);        
        $term_meta_key = array();
        $term_meta_value = array();
        foreach ($all_category_list_arr['groups'] as $keys => $groups) {
            
            foreach ($groups as $key => $category) {                
                $term_id[] = $category['id'];
                $tern_name[] = $category['name'];
                $category_name = $category['name'];
                $category_description = $category['description'];
                $category_slug   = sanitize_title($category_name);
                $parent_term = term_exists($category_name, 'product_cat');

                    if ($parent_term !== 0 && $parent_term !== null) {
                        wp_update_term($parent_term['term_id'], 'product_cat', array(
                            'name' => $category_name,
                            'slug' => $category_slug,
                            'description' => $groups['group']['description']
                        ));
                    } else {
                        
                        wp_insert_term($category_name, // the term 
                            'product_cat', // the taxonomy
                            array(
                            'description' => $category_description,
                            'slug' => $category_slug
                            //'parent'=> $parent_term['term_id']
                        ));
                    }
                    foreach ($category as $key => $value) {
                        update_term_meta($parent_term['term_id'],"ez_".$key,$value);
                    }
            }
            
        }
    }

    
    
    /*$url   = 'https://millenniumleasing.ezrentout.com/';
    $token = '1cb6e0b6954cc2d486321815552aaae9';*/
    
    $curl = curl_init();
    
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url . "assets.api",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 3000,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => array(
            "token: " . $token
        )
    ));
    
    $all_product_list = curl_exec($curl);
    $err      = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "assets cURL Error #:" . $err;
    } else {
        $all_product_list_arr = json_decode($all_product_list,true);
        
        foreach ($all_product_list_arr['assets'] as $keys => $product_list) {            
            $product_name = $product_list['name'];
            $product_description = $product_list['description'];
            $sku = $product_list['product_model_number'];
            $qty = $product_list['net_quantity'];
            $price = $product_list['price'];
            $product_image = $product_list['display_image'];
            $sequence_num  = $product_list['sequence_num'];
            $rental_prices = $product_list['rental_prices'];
            $per_minute = $rental_prices['per_minute'];
            $hourly = $rental_prices['hourly'];
            $daily = $rental_prices['daily'];
            $weekly = $rental_prices['weekly'];
            $monthly = $rental_prices['monthly'].'0';
            $hidden_on_web_store = $product_list['hidden_on_web_store'];
            $ez_available_for_sale  = $product_list['available_for_sale'];
            /*if($available_for_sale == 'yes'){
                echo 'yes';
            }else{
                echo 'no';
            }*/
            $available_for_sale = $ez_available_for_sale ? 'yes' : 'no';
            $check_availibity_html = '<a id="ezr-cart-widget-item-' . $sequence_num . '" onclick="ezrLoadCalendarDialog(' . $sequence_num . ', this)" href="#_">Availability Calendar</a>';
           
            global $wpdb;

            $product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $sku ) );   
            
            

            //$mypost = get_page_by_title($product_name, OBJECT, 'product');
            if (!$product_id) {

                $post = array(
                    'post_author' => 1,
                    //'post_content' => $product_description,
                    'post_excerpt' => $product_description,
                    'post_status' => "publish",
                    'post_title' => $product_name,
                    'post_parent' => '',
                    'post_type' => "product"
                );
                $post_id = wp_insert_post($post, $wp_error);
                if ($post_id) {
                    $image_url  = $product_image;
                    $upload_dir = wp_upload_dir();
                    $imgname    = basename($image_url);
                    if (strpos($imgname, '?') !== false) {
                        $t       = explode('?', $imgname);
                        $imgname = $t[0];
                    }
                    if (wp_mkdir_p($upload_dir['path'])) {
                        $file = $upload_dir['path'] . '/' . $imgname;
                    } else {
                        $file = $upload_dir['basedir'] . '/' . $imgname;
                    }
                    $contents = file_get_contents($image_url);
                    $savefile = fopen($file, 'w');
                    fwrite($savefile, $contents);
                    fclose($savefile);
                    
                    $filename   = $upload_dir['path'] . '/' . $imgname;
                    $filetype   = wp_check_filetype(basename($filename), null);
                    $attachment = array(
                        'guid' => $upload_dir['url'] . '/' . basename($imgname),
                        'post_mime_type' => $filetype['type'],
                        'post_title' => preg_replace('/\.[^.]+$/', '', basename($imgname)),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    );
                    $attach_id  = wp_insert_attachment($attachment, $filename, $post_id);
                    
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attach_data = wp_generate_attachment_metadata($attach_id, $filename);
                    wp_update_attachment_metadata($attach_id, $attach_data);
                    set_post_thumbnail($post_id, $attach_id);
                }
                $ez_rental_prices = get_post_meta( $post_id, 'ez_rental_prices');
                

                add_post_meta($post_id, '_visibility', 'visible',true);
                add_post_meta($post_id, '_stock_status', 'instock',true);
                add_post_meta($post_id, 'total_sales', '0',true);
                add_post_meta($post_id, '_downloadable', 'no',true); //
                add_post_meta($post_id, '_virtual', 'no',true); //
                add_post_meta($post_id, '_regular_price', $price,true);
                add_post_meta($post_id, '_sale_price', "",true);
                add_post_meta($post_id, '_price', $weekly,true);
                add_post_meta($post_id, '_purchase_note', "",true);
                add_post_meta($post_id, '_featured', "no",true);
                add_post_meta($post_id, '_weight', "",true);
                add_post_meta($post_id, '_length', "",true);
                add_post_meta($post_id, '_width', "",true);
                add_post_meta($post_id, '_height', "",true);
                add_post_meta($post_id, '_sku', $sku,true);
                add_post_meta($post_id, '_product_attrfibutes', array(),true);
                add_post_meta($post_id, '_sale_price_dates_from', "",true);
                add_post_meta($post_id, '_sale_price_dates_to', "",true);
                add_post_meta($post_id, '_sold_individually', "",true);
                add_post_meta($post_id, '_manage_stock', "yes",true);
                add_post_meta($post_id, '_backorders', "no",true);
                add_post_meta($post_id, '_stock', $qty,true);
                add_post_meta($post_id, 'monthly_price', $monthly,true);
                //

                /*update_post_meta($post_id, '_visibility', 'visible');
                update_post_meta($post_id, '_stock_status', 'instock');
                update_post_meta($post_id, 'total_sales', '0');
                update_post_meta($post_id, '_downloadable', 'no'); //
                update_post_meta($post_id, '_virtual', 'no'); //
                update_post_meta($post_id, '_regular_price', $price);
                update_post_meta($post_id, '_sale_price', "");
                update_post_meta($post_id, '_price', $weekly);
                update_post_meta($post_id, '_purchase_note', "");
                update_post_meta($post_id, '_featured', "no");
                update_post_meta($post_id, '_weight', "");
                update_post_meta($post_id, '_length', "");
                update_post_meta($post_id, '_width', "");
                update_post_meta($post_id, '_height', "");
                update_post_meta($post_id, '_sku', $sku);
                update_post_meta($post_id, '_product_attrfibutes', array());
                update_post_meta($post_id, '_sale_price_dates_from', "");
                update_post_meta($post_id, '_sale_price_dates_to', "");
                update_post_meta($post_id, '_sold_individually', "");
                update_post_meta($post_id, '_manage_stock', "no");
                update_post_meta($post_id, '_backorders', "no");
                update_post_meta($post_id, '_stock', "");*/

                foreach ($product_list as $key => $value) {
                    add_post_meta($post_id, "ez_".$key, $value,true);
                }
                delete_post_meta($post_id, 'ez_available_for_sale', $available_for_sale);
                add_post_meta($post_id, 'ez_available_for_sale', $available_for_sale);
                $category_id = $product_list['group_id'];

                $categories = get_terms( 'product_cat','hide_empty=0');              
                foreach ($categories as $key => $value) {       
                    $term_id = $value->term_id;        
                    $term_name = $value->name;                
                    $term_id_arr = get_term_meta( $term_id, 'ez_id',true);                       
                    if($category_id == $term_id_arr){
                        $term = get_term_by('name', $term_name, 'product_cat');
                        wp_set_object_terms($post_id, $term->term_id, 'product_cat');
                        break;
                    }                    
                    
                }

            }else{
                

                $my_post = array(
                    'ID' => $product_id,//$mypost->ID,
                    'post_title' => $product_name,
                    //'post_content' => $product_description,
                    'post_excerpt' => $product_description,
                    'post_author' => 1,
                    'post_status' => "publish",
                    'post_parent' => ''
                );
                $post_id = $product_id;//$mypost->ID;

                wp_update_post( $my_post );

                if ($post_id) {
                    $image_url  = $product_image;
                    $upload_dir = wp_upload_dir();
                    $imgname    = basename($image_url);
                    if (strpos($imgname, '?') !== false) {
                        $t       = explode('?', $imgname);
                        $imgname = $t[0];
                    }
                    if (wp_mkdir_p($upload_dir['path'])) {
                        $file = $upload_dir['path'] . '/' . $imgname;
                    } else {
                        $file = $upload_dir['basedir'] . '/' . $imgname;
                    }
                    $contents = file_get_contents($image_url);
                    $savefile = fopen($file, 'w');
                    fwrite($savefile, $contents);
                    fclose($savefile);
                    
                    $filename   = $upload_dir['path'] . '/' . $imgname;
                    $filetype   = wp_check_filetype(basename($filename), null);
                    $attachment = array(
                        'guid' => $upload_dir['url'] . '/' . basename($imgname),
                        'post_mime_type' => $filetype['type'],
                        'post_title' => preg_replace('/\.[^.]+$/', '', basename($imgname)),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    );
                    $attach_id  = wp_insert_attachment($attachment, $filename, $post_id);
                    
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attach_data = wp_generate_attachment_metadata($attach_id, $filename);
                    wp_update_attachment_metadata($attach_id, $attach_data);
                    set_post_thumbnail($post_id, $attach_id);
                }
                $ez_rental_prices = get_post_meta( $post_id, 'ez_rental_prices');
                
                
                
                update_field('availability_calendar', $check_availibity_html, $post_id);               

                update_post_meta($post_id, '_visibility', 'visible');
                update_post_meta($post_id, '_stock_status', 'instock');
                update_post_meta($post_id, 'total_sales', '0');
                update_post_meta($post_id, '_downloadable', 'no'); //
                update_post_meta($post_id, '_virtual', 'no'); //
                update_post_meta($post_id, '_regular_price', $price);
                update_post_meta($post_id, '_sale_price', "");
                update_post_meta($post_id, '_price', $weekly);
                update_post_meta($post_id, '_purchase_note', "");
                update_post_meta($post_id, '_featured', "no");
                update_post_meta($post_id, '_weight', "");
                update_post_meta($post_id, '_length', "");
                update_post_meta($post_id, '_width', "");
                update_post_meta($post_id, '_height', "");
                update_post_meta($post_id, '_sku', $sku);
                update_post_meta($post_id, '_product_attrfibutes', array());
                update_post_meta($post_id, '_sale_price_dates_from', "");
                update_post_meta($post_id, '_sale_price_dates_to', "");
                update_post_meta($post_id, '_sold_individually', "");
                update_post_meta($post_id, '_manage_stock', "yes");
                update_post_meta($post_id, '_backorders', "no");
                update_post_meta($post_id, '_stock', $qty);
                update_post_meta($post_id, 'monthly_price', $monthly);
                //

                foreach ($product_list as $key => $value) {
                    update_post_meta($post_id, "ez_".$key, $value);
                }
                delete_post_meta($post_id, 'ez_available_for_sale', $available_for_sale);
                update_post_meta($post_id, 'ez_available_for_sale', $available_for_sale);
                $category_id = $product_list['group_id'];

                $categories = get_terms( 'product_cat','hide_empty=0');              
                foreach ($categories as $key => $value) {       
                    $term_id = $value->term_id;        
                    $term_name = $value->name;                
                    $term_id_arr = get_term_meta( $term_id, 'ez_id',true);                       
                    if($category_id == $term_id_arr){
                        $term = get_term_by('name', $term_name, 'product_cat');
                        wp_set_object_terms($post_id, $term->term_id, 'product_cat');
                        break;
                    }                    
                    
                }
                
            }
            
        }
    }


    // user create
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => $url . "customers.api",      
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 300,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
            "token: " . $token
        )
    ));

    $customer_response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
      echo "customers cURL Error #:" . $err;
    } else {
        global $user;     
        $customer_response_json = json_decode($customer_response, true);      
        $customers = $customer_response_json['customers'];      
        foreach ($customers as $key => $value) {          
            $email = $value['email'];
            $first_name = $value['first_name'];
            $last_name = $value['last_name'];
            $email = $value['email'];
            $user = get_user_by( 'email', $email );
            $password = wp_generate_password();            
            if( ! $user ) {
                $user_id = wp_create_user( $first_name, $password, $email );
                update_user_meta($user_id, 'first_name', $first_name);
                update_user_meta($user_id, 'last_name', $last_name);
                update_user_meta($user_id, "ez_".$key, $value);
            }else{
                       
                foreach ($value as $key => $values) {
                    update_user_meta($user->ID, 'first_name', $first_name);
                    update_user_meta($user->ID, 'last_name', $last_name);
                    update_user_meta( $user->ID, "ez_".$key, $values );
                }
            }
        }
    }


}


?>
