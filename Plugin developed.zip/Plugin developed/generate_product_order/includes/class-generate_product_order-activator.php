<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wordpress.com
 * @since      1.0.0
 *
 * @package    Generate_product_order
 * @subpackage Generate_product_order/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Generate_product_order
 * @subpackage Generate_product_order/includes
 * @author     Chirag R <test@mail.com>
 */
class Generate_product_order_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
