<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wordpress.com
 * @since      1.0.0
 *
 * @package    Generate_product_order
 * @subpackage Generate_product_order/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Generate_product_order
 * @subpackage Generate_product_order/admin
 * @author     Chirag R <test@mail.com>
 */
class Generate_product_order_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		add_action( 'admin_menu', array( $this, 'generate_product_order_menu_page' ) );
		add_action( 'wp_ajax_my_action', array( $this, 'my_callback') );
	}

	/**
	 * Add Menu Pages for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function generate_product_order_menu_page() {
          add_menu_page( 
          	'Generate Product Order', 
          	'Generate Product Order', 
          	'manage_options', 
          	'generate_product_order', 
          	array(
                $this,
                'bpo_menu_page_load'
            ), 
          	'dashicons-welcome-widgets-menus', 90 );
    }

    /**
	 * Admin main page or setting page.
	 *
	 * @since    1.0.0
	 */
    public function bpo_menu_page_load() {

        ?>
        <div class="gpo_main">			
			<h1 id="settings_gpo_title"><?php _e('Generate Products & Orders','generate_product_order'); ?></h1>			
			<div id="tabs">
			    <ul>
				    <li><a href="#gpo_how-1"><span class="dashicons dashicons-welcome-view-site"></span>&nbsp;<?php _e('Run Now','generate_product_order'); ?></a></li>
				    <li><a href="#gpo_help-2"><span class="dashicons dashicons-editor-help"></span>&nbsp;<?php _e('Help','generate_product_order'); ?></a></li>
			    </ul>
			  	<div class="gpo_tab-wrapper">

				  <div id="gpo_how-1">
				  	<h3><?php _e('Click below button and generate products & orders.','generate_product_order'); ?></h3>				  	
				  	<a id="gpo_btn" class="button">Generate Now</a>

				  	<div style=" padding: 15px 0; "><div class="loader"></div></div>
				  		
				  	<div id="gpo_list" style="padding: 10px;">
				  		
				  	</div>
				  	
				  </div>

				  <div id="gpo_help-2">
				  	<h2><?php _e('Plugin Feature:','generate_product_order'); ?></h2>
				  	<h4><span class="dashicons dashicons-yes"></span> <?php _e('Plugin will generate 10 products','generate_product_order'); ?></h4>
				  	<h4><span class="dashicons dashicons-yes"></span> <?php _e('Plugin will generate 10 orders.','generate_product_order'); ?></h4>
				  </div>

			  	</div>
			</div>
		</div>
        <?php
    }

    /**
	 * Admin ajax call.
	 *
	 * @since    1.0.0
	 */
    public function my_callback() {
    	
    	if( isset($_POST['gpo_run']) ) {

    		$products = $orders = $order_links = [];

    		for( $i=1; $i<11; $i++ ) {
    			$post = array(				    
				    'post_content' => '',
				    'post_status' => "publish",
				    'post_title' => "Title ".$i,
				    'post_parent' => '',
				    'post_type' => "product",
				);



    			$post_id = wp_insert_post( $post, $wp_error );

    			$cat = array("Red1","Green2","Blue3","Yellow4","Brown5");
    			$random_cat = array_rand($cat);

    			$price = array(25,28,32,40,45);
    			$random_price = array_rand($price);

				if($post_id) {
					wp_set_object_terms( $post_id, $cat[$random_cat], 'product_cat' );
					update_post_meta( $post_id, '_regular_price', $price[$random_price] );

					$products[] = get_the_title( $post_id );
				}

				// Now we create the order
				$address = array(
			      'first_name' => '111Joe',
			      'last_name'  => 'Conlin',
			      'company'    => 'Speed Society',
			      'email'      => 'joe@testing.com',
			      'phone'      => '760-555-1212',
			      'address_1'  => '123 Main st.',
			      'address_2'  => '104',
			      'city'       => 'San Diego',
			      'state'      => 'Ca',
			      'postcode'   => '92121',
			      'country'    => 'US'
				);

				$order = wc_create_order();

				$order->add_product( get_product($post_id), 1); // This is an existing SIMPLE product
				$order->set_address( $address, 'billing' );
				  
				$order->calculate_totals();
				$order->update_status("Completed", 'Imported order', TRUE); 

				$order_links[] = '<a href="'. admin_url( 'post.php?post=' . absint( $order->id ) . '&action=edit' ) .'" >Edit</a>';

				$orders[] = $order->get_id();
    		}

    	}

    	echo "
    		<table style='width:100%;text-align:left;'>
			  <tr>
			    <th>Product</th>
			    <th>Order</th>
			    <th>Edit</th>
			  </tr>";

    	for( $i=1; $i<11; $i++ ) {

    		echo "
			  <tr>
			    <td>".$products[$i]."</td>
			    <td>".$orders[$i]."</td>
			    <td>".$order_links[$i]."</td>
			  </tr>";
    	}

    	echo "</table>";
		
		wp_die();
    }

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Generate_product_order_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Generate_product_order_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/generate_product_order-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Generate_product_order_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Generate_product_order_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/generate_product_order-admin.js', array( 'jquery' ), $this->version, false );
		wp_localize_script( $this->plugin_name, 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
		wp_enqueue_script( 'jquery-ui-widget' );
	}

}
