<?php
/*
Plugin Name: Icecube Import Order
Plugin URI: https://www.icecubedigital.com/
Description: Import Order From SFTP [https://devsite.americanguncraft.com/]
Version: 1.0.0
Author: Icecube Digital WordPress Team
Author URI: https://www.icecubedigital.com/
*/


register_activation_hook(__FILE__, 'ice_add_admin_menu');

add_action('admin_menu', 'ice_add_admin_menu');
add_action('admin_init', 'ice_settings_init');

function ice_add_admin_menu()
{
    
    add_menu_page('Import Order Setting', 'Import Order CSV Setting', 'manage_options', 'icecube_import_order', 'ice_options_page');
    
}


function ice_settings_init()
{
    
    register_setting('pluginPage', 'ice_settings');
    
    add_settings_section('ice_pluginPage_section', __('', 'icecube'), 'ice_settings_section_callback', 'pluginPage');
    
    add_settings_field('sftp_host', __('SFTP HOST', 'icecube'), 'sftp_host_render', 'pluginPage', 'ice_pluginPage_section');
    
    add_settings_field('sftp_user', __('SFTP USER', 'icecube'), 'sftp_user_render', 'pluginPage', 'ice_pluginPage_section');
    
    add_settings_field('sftp_pass', __('SFTP PASS', 'icecube'), 'sftp_pass_render', 'pluginPage', 'ice_pluginPage_section');
    
    
}


function sftp_host_render()
{
    
    $options = get_option('ice_settings');
?>
  <input type='text' name='ice_settings[sftp_host]' value='<?php
    echo $options['sftp_host'];
?>'>
  <?php
    
}


function sftp_user_render()
{
    
    $options = get_option('ice_settings');
?>
  <input type='text' name='ice_settings[sftp_user]' value='<?php
    echo $options['sftp_user'];
?>'>
  <?php
    
}


function sftp_pass_render()
{
    
    $options = get_option('ice_settings');
?>
  <input type='text' name='ice_settings[sftp_pass]' value='<?php
    echo $options['sftp_pass'];
?>'>
  <?php
    
}


function ice_settings_section_callback()
{
    
    echo __('This Plugin for the import order from SFTP', 'icecube');
    
}


function ice_options_page()
{
    
?>
    <form action='options.php' method='post'>

      <h2>Import Order CSV SFTP Setting</h2>

      <?php
    settings_fields('pluginPage');
    do_settings_sections('pluginPage');
    submit_button();
?>

    </form>
    <?php
    
}

add_action('cron_icecube_import_order', 'cron_icecube_import_order_function');
function cron_icecube_import_order_function()
{
    
    global $woocommerce;
    global $wpdb;
    $retrive_single_setting_array = get_option('wcos_setting_array');
    $retrive_single_setting_array = json_decode($retrive_single_setting_array, true);
    $WCOS_status_list             = explode(',', $retrive_single_setting_array['wcosp_status_list']);

    $sftp_setting_arr = get_option('ice_settings');
    $sftp_host        = $sftp_setting_arr['sftp_host']; //sftp.pmci.com
    $sftp_user        = $sftp_setting_arr['sftp_user']; //agc_12377
    $sftp_pass        = $sftp_setting_arr['sftp_pass']; //ZvjSaVtqUm41OFN0g4NL

    $connection = ssh2_connect($sftp_host, 22);
    ssh2_auth_password($connection, $sftp_user, $sftp_pass);
    $sftp          = ssh2_sftp($connection);    
    $dir           = 'ssh2.sftp://' . intval($sftp) . '/agc_12377/outgoing/';
    $dir_processed = '/agc_12377/outgoing/processed/';
    ssh2_sftp_mkdir($sftp, $dir_processed, 0700, true);
    $dir1 = opendir($dir);
    while ($file = readdir($dir1)) {

        if ($file == '.' || $file == '..' || strpos($file, 'csv') == false ) {
            // hidden files
            continue;
        }        

        $data = array();
        $count = $k = $j = 0;
        $tracking_id = 0;
        $_wc_shipment_tracking_items_data = $_wc_shipment_tracking_items = array();

        if (($handle = fopen($dir . $file, "r")) !== FALSE) {
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $count++;
                $length = count($data);

                if ($count == 1) {
                    continue;
                }

                $orderid   = $data['0'];
                $order_idd = (int) $orderid;
                
                $query         = "SELECT order_item_id FROM `wp_woocommerce_order_items` WHERE `order_id` = '$order_idd'";
                $order_item_id = $wpdb->get_results($query, ARRAY_A);
                $item_id = $order_item_id[$j]['order_item_id'];

                $order_detail_id = $data['1'];
                $item_status     = $data['2'];
                $item_status_key = array_search($item_status, $WCOS_status_list);
                if (isset($item_status_key)) {                  
                    $item_status = update_post_meta($order_idd, 'item_status_' . $item_id, $item_status_key);                    
                }
                
                $status_dates = (int) $data['3'];
                $date         = date_create($status_dates);
                $date_formate = get_option('date_format');
                $time_formate = get_option('time_format');                
                $status_date = date_format($date,"F j, Y g:i:a");
                
                if (isset($status_date)) {
                    $item_status_date = update_post_meta($order_idd, 'item_status_date_' . $item_id, $status_date);                
                }
                               
                $ship_via = $data['4'];
                $tracking_num = $data['5'];
                $tracking_provider = $ship_via;
				$tracking_number = $tracking_num;
				$tracking_product_code = "";
				$date_shipped = $status_dates;
				
				
                if ( class_exists( 'WC_Advanced_Shipment_Tracking_Actions' ) && $order_idd ) {
                   
                    
                    $order_id = $order_idd; //Replace with your order id
                    $tracking_provider = $tracking_provider; //Replace with your shipping provider
                    $tracking_number = $tracking_number; //Replace with your tracking number
                    $date_shipped = $date_shipped; ////Replace with your shipped date
                    $status_shipped = 1; // 0=no,1=shipped,2=partial shipped(if partial shipped order status is enabled)
                    
                   if ( function_exists( 'ast_insert_tracking_number' ) ) {                      
                        update_post_meta($order_idd, '_wc_shipment_tracking_items', '');
                        ast_insert_tracking_number($order_id, $tracking_number, $tracking_provider, $date_shipped, $status_shipped);
                        
                    }
                    $_wc_shipment_tracking_items_data = array();
                    $_wc_shipment_tracking_items_data = get_post_meta($order_idd, '_wc_shipment_tracking_items');
                }

                $product_list_arr = [];
                $query = "SELECT product_id,product_qty FROM `wp_wc_order_product_lookup` WHERE `order_id` = '$order_idd'";
                $product_details = $wpdb->get_results($query, ARRAY_A);
                $product_id = $product_details[$j]['product_id'];
                $product_qty = $product_details[$j]['product_qty'];

                $product_list_arr[] = (object) [
                                        'product' => $product_id ,
                                        'qty' => $product_qty,                      
                                        ];

                if( !empty($_wc_shipment_tracking_items_data) ){
                    $tracking_id = $_wc_shipment_tracking_items_data[0][0]['tracking_id'];
                }

                $_wc_shipment_tracking_items[] = 
                array(
                    "tracking_provider"=>$tracking_provider,
                    "tracking_number"=>$tracking_number,
                    "tracking_product_code"=>$tracking_product_code,
                    "date_shipped"=>$date_shipped,
                    "products_list"=>array_filter($product_list_arr),
                    "tracking_id"=>$tracking_id,
                );    

                $j++;              
                
                
            }

            $update_wc_shipment_tracking_items = update_post_meta($order_idd, '_wc_shipment_tracking_items', $_wc_shipment_tracking_items);

            $fromSftpUrl = '/agc_12377/outgoing/' . $file;
            $toSftpUrl   = '/agc_12377/outgoing/processed/' . $file;           
            // move file in process folder after read
            $success     = ssh2_sftp_rename($sftp, $fromSftpUrl, $toSftpUrl);
            if($update_wc_shipment_tracking_items == true){
                $order = new WC_Order($order_idd);
                $order->update_status('wc-completed'); //wc-completed
                    $heading = 'Order Complete';
                    $subject = 'Order Complete';
                    $mailer = WC()->mailer()->get_emails();
                    $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
                    $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
                    $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
                    $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
                    $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_idd );
            }
            
        }   
        fclose($handle);
    }
    closedir($dir1);
}
